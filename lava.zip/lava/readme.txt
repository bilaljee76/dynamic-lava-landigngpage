databasename: lava
open this link
http://localhost/phpmyadmin/
create new database
import lava.sql file
	>> wordpress <<
http://localhost/lava/wp-admin/
username: admin
password: nb4194236

