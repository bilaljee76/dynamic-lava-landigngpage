-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 12, 2021 at 09:20 AM
-- Server version: 10.4.19-MariaDB
-- PHP Version: 8.0.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `lava`
--

-- --------------------------------------------------------

--
-- Table structure for table `wp_commentmeta`
--

CREATE TABLE `wp_commentmeta` (
  `meta_id` bigint(20) UNSIGNED NOT NULL,
  `comment_id` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_comments`
--

CREATE TABLE `wp_comments` (
  `comment_ID` bigint(20) UNSIGNED NOT NULL,
  `comment_post_ID` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `comment_author` tinytext COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT 0,
  `comment_approved` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'comment',
  `comment_parent` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `user_id` bigint(20) UNSIGNED NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_comments`
--

INSERT INTO `wp_comments` (`comment_ID`, `comment_post_ID`, `comment_author`, `comment_author_email`, `comment_author_url`, `comment_author_IP`, `comment_date`, `comment_date_gmt`, `comment_content`, `comment_karma`, `comment_approved`, `comment_agent`, `comment_type`, `comment_parent`, `user_id`) VALUES
(1, 1, 'A WordPress Commenter', 'wapuu@wordpress.example', 'https://wordpress.org/', '', '2021-06-05 16:18:30', '2021-06-05 16:18:30', 'Hi, this is a comment.\nTo get started with moderating, editing, and deleting comments, please visit the Comments screen in the dashboard.\nCommenter avatars come from <a href=\"https://gravatar.com\">Gravatar</a>.', 0, '1', '', 'comment', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `wp_links`
--

CREATE TABLE `wp_links` (
  `link_id` bigint(20) UNSIGNED NOT NULL,
  `link_url` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) UNSIGNED NOT NULL DEFAULT 1,
  `link_rating` int(11) NOT NULL DEFAULT 0,
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_options`
--

CREATE TABLE `wp_options` (
  `option_id` bigint(20) UNSIGNED NOT NULL,
  `option_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `option_value` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'yes'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_options`
--

INSERT INTO `wp_options` (`option_id`, `option_name`, `option_value`, `autoload`) VALUES
(1, 'siteurl', 'http://localhost/lava', 'yes'),
(2, 'home', 'http://localhost/lava', 'yes'),
(3, 'blogname', 'System Zones', 'yes'),
(4, 'blogdescription', 'Life Inspire', 'yes'),
(5, 'users_can_register', '1', 'yes'),
(6, 'admin_email', 'bilal.asghar.chuadhary@gmail.com', 'yes'),
(7, 'start_of_week', '1', 'yes'),
(8, 'use_balanceTags', '0', 'yes'),
(9, 'use_smilies', '1', 'yes'),
(10, 'require_name_email', '1', 'yes'),
(11, 'comments_notify', '1', 'yes'),
(12, 'posts_per_rss', '10', 'yes'),
(13, 'rss_use_excerpt', '0', 'yes'),
(14, 'mailserver_url', 'mail.example.com', 'yes'),
(15, 'mailserver_login', 'login@example.com', 'yes'),
(16, 'mailserver_pass', 'password', 'yes'),
(17, 'mailserver_port', '110', 'yes'),
(18, 'default_category', '1', 'yes'),
(19, 'default_comment_status', 'open', 'yes'),
(20, 'default_ping_status', 'open', 'yes'),
(21, 'default_pingback_flag', '0', 'yes'),
(22, 'posts_per_page', '10', 'yes'),
(23, 'date_format', 'F j, Y', 'yes'),
(24, 'time_format', 'g:i a', 'yes'),
(25, 'links_updated_date_format', 'F j, Y g:i a', 'yes'),
(26, 'comment_moderation', '0', 'yes'),
(27, 'moderation_notify', '1', 'yes'),
(28, 'permalink_structure', '/%postname%/', 'yes'),
(29, 'rewrite_rules', 'a:138:{s:11:\"^wp-json/?$\";s:22:\"index.php?rest_route=/\";s:14:\"^wp-json/(.*)?\";s:33:\"index.php?rest_route=/$matches[1]\";s:21:\"^index.php/wp-json/?$\";s:22:\"index.php?rest_route=/\";s:24:\"^index.php/wp-json/(.*)?\";s:33:\"index.php?rest_route=/$matches[1]\";s:17:\"^wp-sitemap\\.xml$\";s:23:\"index.php?sitemap=index\";s:17:\"^wp-sitemap\\.xsl$\";s:36:\"index.php?sitemap-stylesheet=sitemap\";s:23:\"^wp-sitemap-index\\.xsl$\";s:34:\"index.php?sitemap-stylesheet=index\";s:48:\"^wp-sitemap-([a-z]+?)-([a-z\\d_-]+?)-(\\d+?)\\.xml$\";s:75:\"index.php?sitemap=$matches[1]&sitemap-subtype=$matches[2]&paged=$matches[3]\";s:34:\"^wp-sitemap-([a-z]+?)-(\\d+?)\\.xml$\";s:47:\"index.php?sitemap=$matches[1]&paged=$matches[2]\";s:10:\"service/?$\";s:27:\"index.php?post_type=service\";s:40:\"service/feed/(feed|rdf|rss|rss2|atom)/?$\";s:44:\"index.php?post_type=service&feed=$matches[1]\";s:35:\"service/(feed|rdf|rss|rss2|atom)/?$\";s:44:\"index.php?post_type=service&feed=$matches[1]\";s:27:\"service/page/([0-9]{1,})/?$\";s:45:\"index.php?post_type=service&paged=$matches[1]\";s:12:\"promotion/?$\";s:29:\"index.php?post_type=promotion\";s:42:\"promotion/feed/(feed|rdf|rss|rss2|atom)/?$\";s:46:\"index.php?post_type=promotion&feed=$matches[1]\";s:37:\"promotion/(feed|rdf|rss|rss2|atom)/?$\";s:46:\"index.php?post_type=promotion&feed=$matches[1]\";s:29:\"promotion/page/([0-9]{1,})/?$\";s:47:\"index.php?post_type=promotion&paged=$matches[1]\";s:47:\"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:42:\"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:23:\"category/(.+?)/embed/?$\";s:46:\"index.php?category_name=$matches[1]&embed=true\";s:35:\"category/(.+?)/page/?([0-9]{1,})/?$\";s:53:\"index.php?category_name=$matches[1]&paged=$matches[2]\";s:17:\"category/(.+?)/?$\";s:35:\"index.php?category_name=$matches[1]\";s:44:\"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?tag=$matches[1]&feed=$matches[2]\";s:39:\"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?tag=$matches[1]&feed=$matches[2]\";s:20:\"tag/([^/]+)/embed/?$\";s:36:\"index.php?tag=$matches[1]&embed=true\";s:32:\"tag/([^/]+)/page/?([0-9]{1,})/?$\";s:43:\"index.php?tag=$matches[1]&paged=$matches[2]\";s:14:\"tag/([^/]+)/?$\";s:25:\"index.php?tag=$matches[1]\";s:45:\"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?post_format=$matches[1]&feed=$matches[2]\";s:40:\"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?post_format=$matches[1]&feed=$matches[2]\";s:21:\"type/([^/]+)/embed/?$\";s:44:\"index.php?post_format=$matches[1]&embed=true\";s:33:\"type/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?post_format=$matches[1]&paged=$matches[2]\";s:15:\"type/([^/]+)/?$\";s:33:\"index.php?post_format=$matches[1]\";s:35:\"service/[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:45:\"service/[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:65:\"service/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:60:\"service/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:60:\"service/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:41:\"service/[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:24:\"service/([^/]+)/embed/?$\";s:40:\"index.php?service=$matches[1]&embed=true\";s:28:\"service/([^/]+)/trackback/?$\";s:34:\"index.php?service=$matches[1]&tb=1\";s:48:\"service/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:46:\"index.php?service=$matches[1]&feed=$matches[2]\";s:43:\"service/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:46:\"index.php?service=$matches[1]&feed=$matches[2]\";s:36:\"service/([^/]+)/page/?([0-9]{1,})/?$\";s:47:\"index.php?service=$matches[1]&paged=$matches[2]\";s:43:\"service/([^/]+)/comment-page-([0-9]{1,})/?$\";s:47:\"index.php?service=$matches[1]&cpage=$matches[2]\";s:32:\"service/([^/]+)(?:/([0-9]+))?/?$\";s:46:\"index.php?service=$matches[1]&page=$matches[2]\";s:24:\"service/[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:34:\"service/[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:54:\"service/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:49:\"service/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:49:\"service/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:30:\"service/[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:37:\"promotion/[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:47:\"promotion/[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:67:\"promotion/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:62:\"promotion/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:62:\"promotion/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:43:\"promotion/[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:26:\"promotion/([^/]+)/embed/?$\";s:42:\"index.php?promotion=$matches[1]&embed=true\";s:30:\"promotion/([^/]+)/trackback/?$\";s:36:\"index.php?promotion=$matches[1]&tb=1\";s:50:\"promotion/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:48:\"index.php?promotion=$matches[1]&feed=$matches[2]\";s:45:\"promotion/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:48:\"index.php?promotion=$matches[1]&feed=$matches[2]\";s:38:\"promotion/([^/]+)/page/?([0-9]{1,})/?$\";s:49:\"index.php?promotion=$matches[1]&paged=$matches[2]\";s:45:\"promotion/([^/]+)/comment-page-([0-9]{1,})/?$\";s:49:\"index.php?promotion=$matches[1]&cpage=$matches[2]\";s:34:\"promotion/([^/]+)(?:/([0-9]+))?/?$\";s:48:\"index.php?promotion=$matches[1]&page=$matches[2]\";s:26:\"promotion/[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:36:\"promotion/[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:56:\"promotion/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:51:\"promotion/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:51:\"promotion/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:32:\"promotion/[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:48:\".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$\";s:18:\"index.php?feed=old\";s:20:\".*wp-app\\.php(/.*)?$\";s:19:\"index.php?error=403\";s:18:\".*wp-register.php$\";s:23:\"index.php?register=true\";s:32:\"feed/(feed|rdf|rss|rss2|atom)/?$\";s:27:\"index.php?&feed=$matches[1]\";s:27:\"(feed|rdf|rss|rss2|atom)/?$\";s:27:\"index.php?&feed=$matches[1]\";s:8:\"embed/?$\";s:21:\"index.php?&embed=true\";s:20:\"page/?([0-9]{1,})/?$\";s:28:\"index.php?&paged=$matches[1]\";s:27:\"comment-page-([0-9]{1,})/?$\";s:39:\"index.php?&page_id=63&cpage=$matches[1]\";s:41:\"comments/feed/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?&feed=$matches[1]&withcomments=1\";s:36:\"comments/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?&feed=$matches[1]&withcomments=1\";s:17:\"comments/embed/?$\";s:21:\"index.php?&embed=true\";s:44:\"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:40:\"index.php?s=$matches[1]&feed=$matches[2]\";s:39:\"search/(.+)/(feed|rdf|rss|rss2|atom)/?$\";s:40:\"index.php?s=$matches[1]&feed=$matches[2]\";s:20:\"search/(.+)/embed/?$\";s:34:\"index.php?s=$matches[1]&embed=true\";s:32:\"search/(.+)/page/?([0-9]{1,})/?$\";s:41:\"index.php?s=$matches[1]&paged=$matches[2]\";s:14:\"search/(.+)/?$\";s:23:\"index.php?s=$matches[1]\";s:47:\"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?author_name=$matches[1]&feed=$matches[2]\";s:42:\"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?author_name=$matches[1]&feed=$matches[2]\";s:23:\"author/([^/]+)/embed/?$\";s:44:\"index.php?author_name=$matches[1]&embed=true\";s:35:\"author/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?author_name=$matches[1]&paged=$matches[2]\";s:17:\"author/([^/]+)/?$\";s:33:\"index.php?author_name=$matches[1]\";s:69:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:80:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]\";s:64:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:80:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]\";s:45:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$\";s:74:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&embed=true\";s:57:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:81:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]\";s:39:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$\";s:63:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]\";s:56:\"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:64:\"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]\";s:51:\"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:64:\"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]\";s:32:\"([0-9]{4})/([0-9]{1,2})/embed/?$\";s:58:\"index.php?year=$matches[1]&monthnum=$matches[2]&embed=true\";s:44:\"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:65:\"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]\";s:26:\"([0-9]{4})/([0-9]{1,2})/?$\";s:47:\"index.php?year=$matches[1]&monthnum=$matches[2]\";s:43:\"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?year=$matches[1]&feed=$matches[2]\";s:38:\"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?year=$matches[1]&feed=$matches[2]\";s:19:\"([0-9]{4})/embed/?$\";s:37:\"index.php?year=$matches[1]&embed=true\";s:31:\"([0-9]{4})/page/?([0-9]{1,})/?$\";s:44:\"index.php?year=$matches[1]&paged=$matches[2]\";s:13:\"([0-9]{4})/?$\";s:26:\"index.php?year=$matches[1]\";s:27:\".?.+?/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:37:\".?.+?/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:57:\".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:33:\".?.+?/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:16:\"(.?.+?)/embed/?$\";s:41:\"index.php?pagename=$matches[1]&embed=true\";s:20:\"(.?.+?)/trackback/?$\";s:35:\"index.php?pagename=$matches[1]&tb=1\";s:40:\"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?pagename=$matches[1]&feed=$matches[2]\";s:35:\"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?pagename=$matches[1]&feed=$matches[2]\";s:28:\"(.?.+?)/page/?([0-9]{1,})/?$\";s:48:\"index.php?pagename=$matches[1]&paged=$matches[2]\";s:35:\"(.?.+?)/comment-page-([0-9]{1,})/?$\";s:48:\"index.php?pagename=$matches[1]&cpage=$matches[2]\";s:24:\"(.?.+?)(?:/([0-9]+))?/?$\";s:47:\"index.php?pagename=$matches[1]&page=$matches[2]\";s:27:\"[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:37:\"[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:57:\"[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\"[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\"[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:33:\"[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:16:\"([^/]+)/embed/?$\";s:37:\"index.php?name=$matches[1]&embed=true\";s:20:\"([^/]+)/trackback/?$\";s:31:\"index.php?name=$matches[1]&tb=1\";s:40:\"([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?name=$matches[1]&feed=$matches[2]\";s:35:\"([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?name=$matches[1]&feed=$matches[2]\";s:28:\"([^/]+)/page/?([0-9]{1,})/?$\";s:44:\"index.php?name=$matches[1]&paged=$matches[2]\";s:35:\"([^/]+)/comment-page-([0-9]{1,})/?$\";s:44:\"index.php?name=$matches[1]&cpage=$matches[2]\";s:24:\"([^/]+)(?:/([0-9]+))?/?$\";s:43:\"index.php?name=$matches[1]&page=$matches[2]\";s:16:\"[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:26:\"[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:46:\"[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:41:\"[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:41:\"[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:22:\"[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";}', 'yes'),
(30, 'hack_file', '0', 'yes'),
(31, 'blog_charset', 'UTF-8', 'yes'),
(32, 'moderation_keys', '', 'no'),
(33, 'active_plugins', 'a:5:{i:0;s:54:\"acf-star-rating-field-master/acf-star_rating_field.php\";i:1;s:30:\"advanced-custom-fields/acf.php\";i:2;s:27:\"autoptimize/autoptimize.php\";i:3;s:33:\"classic-editor/classic-editor.php\";i:4;s:36:\"contact-form-7/wp-contact-form-7.php\";}', 'yes'),
(34, 'category_base', '', 'yes'),
(35, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes'),
(36, 'comment_max_links', '2', 'yes'),
(37, 'gmt_offset', '0', 'yes'),
(38, 'default_email_category', '1', 'yes'),
(39, 'recently_edited', '', 'no'),
(40, 'template', 'lava', 'yes'),
(41, 'stylesheet', 'lava', 'yes'),
(42, 'comment_registration', '0', 'yes'),
(43, 'html_type', 'text/html', 'yes'),
(44, 'use_trackback', '0', 'yes'),
(45, 'default_role', 'subscriber', 'yes'),
(46, 'db_version', '49752', 'yes'),
(47, 'uploads_use_yearmonth_folders', '1', 'yes'),
(48, 'upload_path', '', 'yes'),
(49, 'blog_public', '0', 'yes'),
(50, 'default_link_category', '2', 'yes'),
(51, 'show_on_front', 'page', 'yes'),
(52, 'tag_base', '', 'yes'),
(53, 'show_avatars', '1', 'yes'),
(54, 'avatar_rating', 'G', 'yes'),
(55, 'upload_url_path', '', 'yes'),
(56, 'thumbnail_size_w', '150', 'yes'),
(57, 'thumbnail_size_h', '150', 'yes'),
(58, 'thumbnail_crop', '1', 'yes'),
(59, 'medium_size_w', '300', 'yes'),
(60, 'medium_size_h', '300', 'yes'),
(61, 'avatar_default', 'mystery', 'yes'),
(62, 'large_size_w', '1024', 'yes'),
(63, 'large_size_h', '1024', 'yes'),
(64, 'image_default_link_type', 'none', 'yes'),
(65, 'image_default_size', '', 'yes'),
(66, 'image_default_align', '', 'yes'),
(67, 'close_comments_for_old_posts', '0', 'yes'),
(68, 'close_comments_days_old', '14', 'yes'),
(69, 'thread_comments', '1', 'yes'),
(70, 'thread_comments_depth', '5', 'yes'),
(71, 'page_comments', '0', 'yes'),
(72, 'comments_per_page', '50', 'yes'),
(73, 'default_comments_page', 'newest', 'yes'),
(74, 'comment_order', 'asc', 'yes'),
(75, 'sticky_posts', 'a:0:{}', 'yes'),
(76, 'widget_categories', 'a:2:{i:2;a:4:{s:5:\"title\";s:0:\"\";s:5:\"count\";i:0;s:12:\"hierarchical\";i:0;s:8:\"dropdown\";i:0;}s:12:\"_multiwidget\";i:1;}', 'yes'),
(77, 'widget_text', 'a:2:{i:1;a:0:{}s:12:\"_multiwidget\";i:1;}', 'yes'),
(78, 'widget_rss', 'a:2:{i:1;a:0:{}s:12:\"_multiwidget\";i:1;}', 'yes'),
(79, 'uninstall_plugins', 'a:2:{s:27:\"autoptimize/autoptimize.php\";s:29:\"autoptimizeMain::on_uninstall\";s:32:\"acf-duplicate-repeater/index.php\";a:2:{i:0;s:32:\"ACFDuplicateRepeater\\Core\\Plugin\";i:1;s:9:\"uninstall\";}}', 'no'),
(80, 'timezone_string', '', 'yes'),
(81, 'page_for_posts', '0', 'yes'),
(82, 'page_on_front', '63', 'yes'),
(83, 'default_post_format', '0', 'yes'),
(84, 'link_manager_enabled', '0', 'yes'),
(85, 'finished_splitting_shared_terms', '1', 'yes'),
(86, 'site_icon', '0', 'yes'),
(87, 'medium_large_size_w', '768', 'yes'),
(88, 'medium_large_size_h', '0', 'yes'),
(89, 'wp_page_for_privacy_policy', '3', 'yes'),
(90, 'show_comments_cookies_opt_in', '1', 'yes'),
(91, 'admin_email_lifespan', '1638461910', 'yes'),
(92, 'disallowed_keys', '', 'no'),
(93, 'comment_previously_approved', '1', 'yes'),
(94, 'auto_plugin_theme_update_emails', 'a:0:{}', 'no'),
(95, 'auto_update_core_dev', 'enabled', 'yes'),
(96, 'auto_update_core_minor', 'enabled', 'yes'),
(97, 'auto_update_core_major', 'enabled', 'yes'),
(98, 'initial_db_version', '49752', 'yes'),
(99, 'wp_user_roles', 'a:5:{s:13:\"administrator\";a:2:{s:4:\"name\";s:13:\"Administrator\";s:12:\"capabilities\";a:62:{s:13:\"switch_themes\";b:1;s:11:\"edit_themes\";b:1;s:16:\"activate_plugins\";b:1;s:12:\"edit_plugins\";b:1;s:10:\"edit_users\";b:1;s:10:\"edit_files\";b:1;s:14:\"manage_options\";b:1;s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:6:\"import\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:8:\"level_10\";b:1;s:7:\"level_9\";b:1;s:7:\"level_8\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;s:12:\"delete_users\";b:1;s:12:\"create_users\";b:1;s:17:\"unfiltered_upload\";b:1;s:14:\"edit_dashboard\";b:1;s:14:\"update_plugins\";b:1;s:14:\"delete_plugins\";b:1;s:15:\"install_plugins\";b:1;s:13:\"update_themes\";b:1;s:14:\"install_themes\";b:1;s:11:\"update_core\";b:1;s:10:\"list_users\";b:1;s:12:\"remove_users\";b:1;s:13:\"promote_users\";b:1;s:18:\"edit_theme_options\";b:1;s:13:\"delete_themes\";b:1;s:6:\"export\";b:1;s:14:\"manage_ratings\";b:1;}}s:6:\"editor\";a:2:{s:4:\"name\";s:6:\"Editor\";s:12:\"capabilities\";a:34:{s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;}}s:6:\"author\";a:2:{s:4:\"name\";s:6:\"Author\";s:12:\"capabilities\";a:10:{s:12:\"upload_files\";b:1;s:10:\"edit_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;s:22:\"delete_published_posts\";b:1;}}s:11:\"contributor\";a:2:{s:4:\"name\";s:11:\"Contributor\";s:12:\"capabilities\";a:5:{s:10:\"edit_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;}}s:10:\"subscriber\";a:2:{s:4:\"name\";s:10:\"Subscriber\";s:12:\"capabilities\";a:2:{s:4:\"read\";b:1;s:7:\"level_0\";b:1;}}}', 'yes'),
(100, 'fresh_site', '0', 'yes'),
(101, 'widget_search', 'a:2:{i:2;a:1:{s:5:\"title\";s:0:\"\";}s:12:\"_multiwidget\";i:1;}', 'yes'),
(102, 'widget_recent-posts', 'a:2:{i:2;a:2:{s:5:\"title\";s:0:\"\";s:6:\"number\";i:5;}s:12:\"_multiwidget\";i:1;}', 'yes'),
(103, 'widget_recent-comments', 'a:2:{i:2;a:2:{s:5:\"title\";s:0:\"\";s:6:\"number\";i:5;}s:12:\"_multiwidget\";i:1;}', 'yes'),
(104, 'widget_archives', 'a:2:{i:2;a:3:{s:5:\"title\";s:0:\"\";s:5:\"count\";i:0;s:8:\"dropdown\";i:0;}s:12:\"_multiwidget\";i:1;}', 'yes'),
(105, 'widget_meta', 'a:2:{i:2;a:1:{s:5:\"title\";s:0:\"\";}s:12:\"_multiwidget\";i:1;}', 'yes'),
(106, 'sidebars_widgets', 'a:4:{s:25:\"testimonial_slider_widget\";a:1:{i:0;s:35:\"ratingwidgetplugin_topratedwidget-2\";}s:19:\"wp_inactive_widgets\";a:6:{i:0;s:8:\"search-2\";i:1;s:14:\"recent-posts-2\";i:2;s:17:\"recent-comments-2\";i:3;s:10:\"archives-2\";i:4;s:12:\"categories-2\";i:5;s:6:\"meta-2\";}s:25:\"testimonial-slider-widget\";a:0:{}s:13:\"array_version\";i:3;}', 'yes'),
(107, 'cron', 'a:7:{i:1623485911;a:1:{s:34:\"wp_privacy_delete_old_export_files\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"hourly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:3600;}}}i:1623490694;a:1:{s:15:\"ao_cachechecker\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}}i:1623514711;a:5:{s:32:\"recovery_mode_clean_expired_keys\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}s:18:\"wp_https_detection\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:16:\"wp_version_check\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:17:\"wp_update_plugins\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:16:\"wp_update_themes\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}}i:1623514731;a:2:{s:19:\"wp_scheduled_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}s:25:\"delete_expired_transients\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1623514738;a:1:{s:30:\"wp_scheduled_auto_draft_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1623601111;a:1:{s:30:\"wp_site_health_scheduled_check\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"weekly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:604800;}}}s:7:\"version\";i:2;}', 'yes'),
(108, 'widget_pages', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(109, 'widget_calendar', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(110, 'widget_media_audio', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(111, 'widget_media_image', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(112, 'widget_media_gallery', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(113, 'widget_media_video', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(114, 'widget_tag_cloud', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(115, 'widget_nav_menu', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(116, 'widget_custom_html', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(118, 'recovery_keys', 'a:1:{s:22:\"Vb0NBWcPDawPvlKH1sI30n\";a:2:{s:10:\"hashed_key\";s:34:\"$P$B0eOwc5/rkwC4pRqxYnnFmzW6RZvLl.\";s:10:\"created_at\";i:1623480688;}}', 'yes'),
(119, 'theme_mods_twentytwentyone', 'a:3:{s:18:\"custom_css_post_id\";i:-1;s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1623048294;s:4:\"data\";a:3:{s:19:\"wp_inactive_widgets\";a:0:{}s:9:\"sidebar-1\";a:3:{i:0;s:8:\"search-2\";i:1;s:14:\"recent-posts-2\";i:2;s:17:\"recent-comments-2\";}s:9:\"sidebar-2\";a:3:{i:0;s:10:\"archives-2\";i:1;s:12:\"categories-2\";i:2;s:6:\"meta-2\";}}}s:18:\"nav_menu_locations\";a:0:{}}', 'yes'),
(120, 'https_detection_errors', 'a:1:{s:23:\"ssl_verification_failed\";a:1:{i:0;s:24:\"SSL verification failed.\";}}', 'yes'),
(121, '_site_transient_update_core', 'O:8:\"stdClass\":4:{s:7:\"updates\";a:1:{i:0;O:8:\"stdClass\":10:{s:8:\"response\";s:6:\"latest\";s:8:\"download\";s:59:\"https://downloads.wordpress.org/release/wordpress-5.7.2.zip\";s:6:\"locale\";s:5:\"en_US\";s:8:\"packages\";O:8:\"stdClass\":5:{s:4:\"full\";s:59:\"https://downloads.wordpress.org/release/wordpress-5.7.2.zip\";s:10:\"no_content\";s:70:\"https://downloads.wordpress.org/release/wordpress-5.7.2-no-content.zip\";s:11:\"new_bundled\";s:71:\"https://downloads.wordpress.org/release/wordpress-5.7.2-new-bundled.zip\";s:7:\"partial\";s:0:\"\";s:8:\"rollback\";s:0:\"\";}s:7:\"current\";s:5:\"5.7.2\";s:7:\"version\";s:5:\"5.7.2\";s:11:\"php_version\";s:6:\"5.6.20\";s:13:\"mysql_version\";s:3:\"5.0\";s:11:\"new_bundled\";s:3:\"5.6\";s:15:\"partial_version\";s:0:\"\";}}s:12:\"last_checked\";i:1623471603;s:15:\"version_checked\";s:5:\"5.7.2\";s:12:\"translations\";a:0:{}}', 'no'),
(127, '_site_transient_update_themes', 'O:8:\"stdClass\":5:{s:12:\"last_checked\";i:1623468291;s:7:\"checked\";a:1:{s:4:\"lava\";s:5:\"1.0.0\";}s:8:\"response\";a:0:{}s:9:\"no_update\";a:0:{}s:12:\"translations\";a:0:{}}', 'no'),
(128, '_site_transient_timeout_browser_3a19c5b2ea764b667094aa0ea89035cb', '1623514734', 'no'),
(129, '_site_transient_browser_3a19c5b2ea764b667094aa0ea89035cb', 'a:10:{s:4:\"name\";s:6:\"Chrome\";s:7:\"version\";s:12:\"91.0.4472.77\";s:8:\"platform\";s:7:\"Windows\";s:10:\"update_url\";s:29:\"https://www.google.com/chrome\";s:7:\"img_src\";s:43:\"http://s.w.org/images/browsers/chrome.png?1\";s:11:\"img_src_ssl\";s:44:\"https://s.w.org/images/browsers/chrome.png?1\";s:15:\"current_version\";s:2:\"18\";s:7:\"upgrade\";b:0;s:8:\"insecure\";b:0;s:6:\"mobile\";b:0;}', 'no'),
(130, '_site_transient_timeout_php_check_4fc3448ce51aace1ce89be1213761296', '1623514737', 'no'),
(131, '_site_transient_php_check_4fc3448ce51aace1ce89be1213761296', 'a:5:{s:19:\"recommended_version\";s:3:\"7.4\";s:15:\"minimum_version\";s:6:\"5.6.20\";s:12:\"is_supported\";b:1;s:9:\"is_secure\";b:1;s:13:\"is_acceptable\";b:1;}', 'no'),
(133, 'can_compress_scripts', '1', 'no'),
(140, 'finished_updating_comment_type', '1', 'yes'),
(145, '_transient_health-check-site-status-result', '{\"good\":\"13\",\"recommended\":\"5\",\"critical\":\"2\"}', 'yes'),
(155, 'current_theme', '', 'yes'),
(157, 'theme_mods_lava_theme', 'a:3:{i:0;b:0;s:18:\"nav_menu_locations\";a:0:{}s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1623048292;s:4:\"data\";a:1:{s:19:\"wp_inactive_widgets\";a:6:{i:0;s:8:\"search-2\";i:1;s:14:\"recent-posts-2\";i:2;s:17:\"recent-comments-2\";i:3;s:10:\"archives-2\";i:4;s:12:\"categories-2\";i:5;s:6:\"meta-2\";}}}}', 'yes'),
(158, 'theme_switched', '', 'yes'),
(163, 'theme_mods_lava', 'a:4:{i:0;b:0;s:18:\"nav_menu_locations\";a:1:{s:12:\"primary_menu\";i:2;}s:18:\"custom_css_post_id\";i:25;s:11:\"custom_logo\";i:32;}', 'yes'),
(193, 'recently_activated', 'a:7:{s:40:\"acf-starrating-master/acf-starrating.php\";i:1623403087;s:33:\"acf-starrating/acf-starrating.php\";i:1623402646;s:41:\"advanced-custom-fields-pro-master/acf.php\";i:1623313944;s:32:\"acf-duplicate-repeater/index.php\";i:1623313496;s:29:\"easy-wp-smtp/easy-wp-smtp.php\";i:1623214138;s:47:\"wp-jquery-update-test/wp-jquery-update-test.php\";i:1623132506;s:19:\"akismet/akismet.php\";i:1623127561;}', 'yes'),
(194, 'autoptimize_version', '2.8.4', 'yes'),
(195, 'autoptimize_service_availablity', 'a:2:{s:12:\"extra_imgopt\";a:3:{s:6:\"status\";s:2:\"up\";s:5:\"hosts\";a:1:{i:1;s:26:\"https://cdn.shortpixel.ai/\";}s:16:\"launch-threshold\";s:4:\"4096\";}s:7:\"critcss\";a:2:{s:6:\"status\";s:2:\"up\";s:5:\"hosts\";a:1:{i:1;s:24:\"https://criticalcss.com/\";}}}', 'yes'),
(196, 'autoptimize_ccss_version', 'AO_2.8.4', 'yes'),
(198, 'autoptimize_imgopt_launched', 'on', 'yes'),
(200, 'widget_akismet_widget', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(201, '_transient_timeout_autoptimize_banner', '1623732375', 'no'),
(202, '_transient_autoptimize_banner', '<li><a href=\"https://misc.optimizingmatters.com/partners/?from=ticker&amp;partner=rapidload\" target=\"_blank\">Remove up to 90% unused CSS</a> for even better performance with <a href=\"https://misc.optimizingmatters.com/partners/?from=ticker&amp;partner=rapidload\" target=\"_blank\">Rapidload</a></li>\n<li>Big images? <a href=\"https://misc.optimizingmatters.com/partners/?from=ticker&amp;partner=shortpixel\" target=\"_blank\">Optimize with Shortpixel</a> and get <strong>50% free</strong> forever!</li>\n<li>Money-back guaranteed <a href=\"https://misc.optimizingmatters.com/partners/?from=ticker&amp;partner=autoptimizepro\" target=\"_blank\"><strong>web performance optimization</strong></a> for only &euro;799!</li>\n<li><a href=\"https://twitter.com/optimatters\" target=\"_blank\">Follow Autoptimize on Twitter @optimatters</a></li>\n', 'no'),
(215, 'autoptimize_html', '', 'yes'),
(216, 'autoptimize_html_keepcomments', '', 'yes'),
(217, 'autoptimize_enable_site_config', 'on', 'yes'),
(218, 'autoptimize_js', 'on', 'yes'),
(219, 'autoptimize_js_aggregate', 'on', 'yes'),
(220, 'autoptimize_js_defer_not_aggregate', '', 'yes'),
(221, 'autoptimize_js_exclude', 'wp-includes/js/dist/, wp-includes/js/tinymce/, js/jquery/jquery.js, js/jquery/jquery.min.js', 'yes'),
(222, 'autoptimize_js_trycatch', '', 'yes'),
(223, 'autoptimize_js_justhead', '', 'yes'),
(224, 'autoptimize_js_forcehead', '', 'yes'),
(225, 'autoptimize_js_include_inline', '', 'yes'),
(226, 'autoptimize_css', 'on', 'yes'),
(227, 'autoptimize_css_aggregate', 'on', 'yes'),
(228, 'autoptimize_css_exclude', 'wp-content/cache/, wp-content/uploads/, admin-bar.min.css, dashicons.min.css', 'yes'),
(229, 'autoptimize_css_justhead', '', 'yes'),
(230, 'autoptimize_css_datauris', '', 'yes'),
(231, 'autoptimize_css_defer', '', 'yes'),
(232, 'autoptimize_css_defer_inline', '', 'yes'),
(233, 'autoptimize_css_inline', '', 'yes'),
(234, 'autoptimize_css_include_inline', 'on', 'yes'),
(235, 'autoptimize_cdn_url', '', 'yes'),
(236, 'autoptimize_cache_clean', '0', 'yes'),
(237, 'autoptimize_cache_nogzip', 'on', 'yes'),
(238, 'autoptimize_optimize_logged', 'on', 'yes'),
(239, 'autoptimize_optimize_checkout', '', 'yes'),
(240, 'autoptimize_minify_excluded', 'on', 'yes'),
(241, 'autoptimize_cache_fallback', 'on', 'yes'),
(246, 'autoptimize_imgopt_settings', 'a:4:{s:31:\"autoptimize_imgopt_text_field_6\";s:0:\"\";s:33:\"autoptimize_imgopt_select_field_2\";s:1:\"2\";s:31:\"autoptimize_imgopt_text_field_5\";s:0:\"\";s:33:\"autoptimize_imgopt_number_field_7\";s:1:\"0\";}', 'yes'),
(249, '_transient_timeout_ao_ccss_explain', '1623732431', 'no'),
(250, '_transient_ao_ccss_explain', '<div class=\'ao_i18n\' id=\'default\'>\n    <h2>Improve first paint times by removing render-blocking CSS</h2>\n    <div style=\"width:100%;overflow:hidden\">\n    <div style=\"width:68%;float:left\">\n      <p>Is Google Pagespeed Insights complaining about <strong>render-blocking CSS</strong>? Are your <strong>first paint times</strong> sub-optimal because of that render-blocking CSS?</p>\n      <p><strong>Above the fold CSS</strong> (as part of Autoptimize\'s \"Inline &amp; defer CSS\") can help you improve, but <strong>most sites need different critical CSS for different types of pages</strong> and generating the correct code can be hard!</p>\n      <p>The solution? <strong>Sign up at <a href=\"https://criticalcss.com/?aff=1\" target=\"_blank\">https://criticalcss.com</a></strong> (premium service, price 2 GBP/month for membership and 5 GBP/month per domain) <strong>and get the API key from <a href=\"https://criticalcss.com/account/api-keys?aff=1\" target=\"_blank\">the API-keys page</a></strong> and paste that key below.</p>\n      <p>If you have any questions or need support, head on over to <a href=\"https://wordpress.org/support/plugin/autoptimize\" target=\"_blank\">our support forum</a> and we\'ll help you get up and running in no time!</p>\n    </div>\n    <div style=\"width:28%;float:right\"><img src=\"https://criticalcss.com/images/criticalcss-optimised-website-illustration.svg\" width=\"350px\"></div>\n    </div>\n</div>\n<div class=\'ao_i18n\' id=\'nl\'>\n    <h2>Verbeter de eerste weergave-tijd door blokkerende CSS te verwijderen</h2>\n    <div style=\"width:100%;overflow:hidden\">\n    <div style=\"width:68%;float:left\">\n      <p>Klaagt Google Pagespeed Insights over <strong>CSS die de weergave blokkeert</strong>? Zijn je <strong>eerste weergave-tijden</strong> niet optimaal vanwege die blokkerende CSS?</p>\n      <p><strong>\"Kritische\" CSS</strong> (als onderdeel van Autoptimize\'s \"Belangrijke CSS in HTML voegen, de rest uitstellen?\" optie) kan helpen dat te verbeteren, maar de meeste sites hebben <strong>verschillende \"kritische CSS\" nodig voor verschillende soorten pagina\'s</strong> en het genereren van de juiste code kan moeilijk zijn!</p>\n      <p>De oplossing? Meld je aan op <a href=\"https://criticalcss.com/?aff=1\" target=\"_blank\">https://criticalcss.com</a> (premium service, prijs 2 GBP / maand voor lidmaatschap en 5 GBP / maand per domein) en haal de API-sleutel op van <a href=\"https://criticalcss.com/account/api-keys?aff=1\" target=\"_blank\">de API-sleutels-pagina</a> en plak die sleutel hieronder.</p>\n      <p>Als je vragen hebt of ondersteuning nodig hebt, ga dan naar ons <a href=\"https://wordpress.org/support/plugin/autoptimize\" target=\"_blank\">support forum</a> en we helpen je snel aan de slag!</p>\n    </div>\n    <div style=\"width:28%;float:right\"><img src=\"https://criticalcss.com/images/criticalcss-optimised-website-illustration.svg\" width=\"350px\"></div>\n    </div>\n</div>\n<div class=\'ao_i18n\' id=\'fr\'> \n  <h2>Am&eacute;liorer la vitesse du premier rendu (first paint) en supprimant les CSS bloquants</h2>\n    <div style=\"width:100%;overflow:hidden\">\n    <div style=\"width:68%;float:left\">\n      <p>Google Pagespeed Insights se plaint du <strong>CSS bloque le rendu</strong>? Votre <strong>vitesse de premier rendu d\'affichage</strong> est-elle ralentie par le CSS qui bloque le rendu ?</p>\n      <p><strong>Le CSS situ&eacute; au-dessus de la ligne de flottaison</strong> (la fonction \"Mettre en ligne et reporter le CSS\" d\'Autoptimize) peuvent &ecirc;tre b&eacute;n&eacute;fiques, mais la plupart des sites ont besoin de <strong>diff&eacute;rents CSS critiques pour diff&eacute;rents types de pages</strong>. G&eacute;n&eacute;rer le code correct peut &ecirc;tre difficile !</p>\n      <p>La solution? <strong>Inscrivez-vous sur <a href=\"https://criticalcss.com/?aff=1\" target=\"_blank\">https://criticalcss.com</a></strong> (service premium, prix 2 GBP / mois pour l\'adh&eacute;sion et 5 GBP / mois par domaine) <strong>et obtenez la cl&eacute; API <a href=\"https://criticalcss.com/account/api-keys?aff=1\" target=\"_blank\">&aacute; partir de la page des cl&eacute;s API</a></strong> et collez cette cl&eacute; ci-dessous.</p>\n      <p>Si vous avez des questions ou si vous avez besoin d\'assistance, rendez-vous sur <a href=\"https://wordpress.org/support/plugin/autoptimize\" target=\"_blank\">notre forum d\'assistance</a> et nous vous aiderons &aacute; vous mettre en route en un rien de temps !</p>\n    </div>\n    <div style=\"width:28%;float:right\"><img src=\"https://criticalcss.com/images/criticalcss-optimised-website-illustration.svg\" width=\"350px\"></div>\n    </div>\n</div>\n<div class=\'ao_i18n\' id=\'pt\'>\n	<h2>Melhore os tempos de primeira pintura ao remover o CSS que bloqueia renderiza&ccedil;&atilde;o</h2>\n  <div style=\"width:100%;overflow:hidden\">\n  	<div style=\"width:68%;float:left\">\n      <p>O Google Pagespeed Insights est&aacute; reclamando do <strong>CSS que bloqueia renderiza&ccedil;&atilde;o</strong>? Os <strong>tempos de primeira pintura</strong> est&aacute; abaixo do esperado por causa do CSS que bloqueia renderiza&ccedil;&atilde;o?</p>\n      <p>O <strong>CSS acima do scroll</strong> (como parte do CSS &quot;Adiado &amp; em Linha&quot; do Autoptimize) pode ajudar a resolver, mas a maior parte dos sites precisam de <strong>CSS cr&iacute;tico diferente para cada tipo de p&aacute;gina</strong> e gerar o c&oacute;digo correto pode ser dif&iacute;cil!</p>\n      <p>A solu&ccedil;&atilde;o? <strong>Assine <a href=\"https://criticalcss.com/?aff=1\" target=\"_blank\">https://criticalcss.com</a></strong> (servi&ccedil;o premium, pre&ccedil;o de 2 Libras/m&ecirc;s no modo assinatura e 5 Libras/m&ecirc;s por dom&iacute;nio), <a href=\"https://criticalcss.com/account/api-keys?aff=1\" target=\"_blank\">copia a chave API da p&aacute;ginas API-keys</a> e cole no campo abaixo.</p>\n      <p>Se voc&ecirc; tem alguma d&uacute;vida ou precisa de suporte, v&aacute; ao <a href=\"https://wordpress.org/support/plugin/autoptimize\" target=\"_blank\">nosso f&oacute;rum de suporte</a> e n&oacute;s vamos ajud&aacute;-lo a colocar para funcionar em pouco tempo!</p>\n    </div>\n  	<div style=\"width:28%;float:right\"><img src=\"https://criticalcss.com/images/criticalcss-optimised-website-illustration.svg\" width=\"350px\"></div>\n  </div>\n</div> \n\n', 'no'),
(251, 'nav_menu_options', 'a:2:{i:0;b:0;s:8:\"auto_add\";a:0:{}}', 'yes'),
(260, 'custom_js', '$( document ).ready(function() {\n    console.log( \"ready!\" );\n});', 'yes'),
(267, 'wpcf7', 'a:2:{s:7:\"version\";s:5:\"5.4.1\";s:13:\"bulk_validate\";a:4:{s:9:\"timestamp\";i:1623134304;s:7:\"version\";s:5:\"5.4.1\";s:11:\"count_valid\";i:1;s:13:\"count_invalid\";i:0;}}', 'yes'),
(281, 'secret_key', 'xV(D#lDfR.rFnxx)TQz/6bAr_N8W}E=cdX?{adgL4{}$(o?2^M/y|G7=^[$70{7I', 'no'),
(297, 'WPLANG', '', 'yes'),
(298, 'new_admin_email', 'bilal.asghar.chuadhary@gmail.com', 'yes'),
(299, 'adminhash', 'a:2:{s:4:\"hash\";s:32:\"ce4861a34bdd02bd717d70382ffb2c61\";s:8:\"newemail\";s:18:\"bilal@truishop.com\";}', 'yes'),
(311, '_site_transient_update_plugins', 'O:8:\"stdClass\":5:{s:12:\"last_checked\";i:1623481139;s:7:\"checked\";a:5:{s:30:\"advanced-custom-fields/acf.php\";s:5:\"5.9.6\";s:54:\"acf-star-rating-field-master/acf-star_rating_field.php\";s:5:\"1.0.2\";s:27:\"autoptimize/autoptimize.php\";s:5:\"2.8.4\";s:33:\"classic-editor/classic-editor.php\";s:3:\"1.6\";s:36:\"contact-form-7/wp-contact-form-7.php\";s:5:\"5.4.1\";}s:8:\"response\";a:0:{}s:12:\"translations\";a:0:{}s:9:\"no_update\";a:4:{s:30:\"advanced-custom-fields/acf.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:36:\"w.org/plugins/advanced-custom-fields\";s:4:\"slug\";s:22:\"advanced-custom-fields\";s:6:\"plugin\";s:30:\"advanced-custom-fields/acf.php\";s:11:\"new_version\";s:5:\"5.9.6\";s:3:\"url\";s:53:\"https://wordpress.org/plugins/advanced-custom-fields/\";s:7:\"package\";s:71:\"https://downloads.wordpress.org/plugin/advanced-custom-fields.5.9.6.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:75:\"https://ps.w.org/advanced-custom-fields/assets/icon-256x256.png?rev=1082746\";s:2:\"1x\";s:75:\"https://ps.w.org/advanced-custom-fields/assets/icon-128x128.png?rev=1082746\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:78:\"https://ps.w.org/advanced-custom-fields/assets/banner-1544x500.jpg?rev=1729099\";s:2:\"1x\";s:77:\"https://ps.w.org/advanced-custom-fields/assets/banner-772x250.jpg?rev=1729102\";}s:11:\"banners_rtl\";a:0:{}}s:27:\"autoptimize/autoptimize.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:25:\"w.org/plugins/autoptimize\";s:4:\"slug\";s:11:\"autoptimize\";s:6:\"plugin\";s:27:\"autoptimize/autoptimize.php\";s:11:\"new_version\";s:5:\"2.8.4\";s:3:\"url\";s:42:\"https://wordpress.org/plugins/autoptimize/\";s:7:\"package\";s:60:\"https://downloads.wordpress.org/plugin/autoptimize.2.8.4.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:64:\"https://ps.w.org/autoptimize/assets/icon-256X256.png?rev=2211608\";s:2:\"1x\";s:64:\"https://ps.w.org/autoptimize/assets/icon-128x128.png?rev=1864142\";}s:7:\"banners\";a:1:{s:2:\"1x\";s:66:\"https://ps.w.org/autoptimize/assets/banner-772x250.jpg?rev=1315920\";}s:11:\"banners_rtl\";a:0:{}}s:33:\"classic-editor/classic-editor.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:28:\"w.org/plugins/classic-editor\";s:4:\"slug\";s:14:\"classic-editor\";s:6:\"plugin\";s:33:\"classic-editor/classic-editor.php\";s:11:\"new_version\";s:3:\"1.6\";s:3:\"url\";s:45:\"https://wordpress.org/plugins/classic-editor/\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/plugin/classic-editor.1.6.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:67:\"https://ps.w.org/classic-editor/assets/icon-256x256.png?rev=1998671\";s:2:\"1x\";s:67:\"https://ps.w.org/classic-editor/assets/icon-128x128.png?rev=1998671\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:70:\"https://ps.w.org/classic-editor/assets/banner-1544x500.png?rev=1998671\";s:2:\"1x\";s:69:\"https://ps.w.org/classic-editor/assets/banner-772x250.png?rev=1998676\";}s:11:\"banners_rtl\";a:0:{}}s:36:\"contact-form-7/wp-contact-form-7.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:28:\"w.org/plugins/contact-form-7\";s:4:\"slug\";s:14:\"contact-form-7\";s:6:\"plugin\";s:36:\"contact-form-7/wp-contact-form-7.php\";s:11:\"new_version\";s:5:\"5.4.1\";s:3:\"url\";s:45:\"https://wordpress.org/plugins/contact-form-7/\";s:7:\"package\";s:63:\"https://downloads.wordpress.org/plugin/contact-form-7.5.4.1.zip\";s:5:\"icons\";a:3:{s:2:\"2x\";s:67:\"https://ps.w.org/contact-form-7/assets/icon-256x256.png?rev=2279696\";s:2:\"1x\";s:59:\"https://ps.w.org/contact-form-7/assets/icon.svg?rev=2339255\";s:3:\"svg\";s:59:\"https://ps.w.org/contact-form-7/assets/icon.svg?rev=2339255\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:69:\"https://ps.w.org/contact-form-7/assets/banner-1544x500.png?rev=860901\";s:2:\"1x\";s:68:\"https://ps.w.org/contact-form-7/assets/banner-772x250.png?rev=880427\";}s:11:\"banners_rtl\";a:0:{}}}}', 'no'),
(312, 'swpsmtp_options', 'a:6:{s:16:\"from_email_field\";s:0:\"\";s:15:\"from_name_field\";s:0:\"\";s:23:\"force_from_name_replace\";i:0;s:8:\"sub_mode\";i:0;s:13:\"smtp_settings\";a:7:{s:4:\"host\";s:16:\"smtp.example.com\";s:15:\"type_encryption\";s:4:\"none\";s:4:\"port\";i:25;s:13:\"autentication\";s:3:\"yes\";s:8:\"username\";s:0:\"\";s:8:\"password\";s:0:\"\";s:13:\"log_file_name\";s:33:\"logs\\.60c0483a34da35.13785084.txt\";}s:15:\"allowed_domains\";s:12:\"bG9jYWxob3N0\";}', 'yes'),
(319, 'acf_version', '5.9.6', 'yes'),
(357, 'acf_duplicate_repeater_version', '2.0.2', 'no'),
(406, 'category_children', 'a:0:{}', 'yes'),
(407, 'fs_active_plugins', 'O:8:\"stdClass\":3:{s:7:\"plugins\";a:1:{s:22:\"rating-widget/freemius\";O:8:\"stdClass\":4:{s:7:\"version\";s:5:\"2.4.2\";s:4:\"type\";s:6:\"plugin\";s:9:\"timestamp\";i:1623469811;s:11:\"plugin_path\";s:31:\"rating-widget/rating-widget.php\";}}s:7:\"abspath\";s:21:\"E:\\XAMPP\\htdocs\\lava/\";s:6:\"newest\";O:8:\"stdClass\":5:{s:11:\"plugin_path\";s:31:\"rating-widget/rating-widget.php\";s:8:\"sdk_path\";s:22:\"rating-widget/freemius\";s:7:\"version\";s:5:\"2.4.2\";s:13:\"in_activation\";b:0;s:9:\"timestamp\";i:1623469811;}}', 'yes'),
(408, 'fs_debug_mode', '', 'yes');
INSERT INTO `wp_options` (`option_id`, `option_name`, `option_value`, `autoload`) VALUES
(409, 'fs_accounts', 'a:7:{s:21:\"id_slug_type_path_map\";a:1:{i:56;a:3:{s:4:\"slug\";s:13:\"rating-widget\";s:4:\"type\";s:6:\"plugin\";s:4:\"path\";s:31:\"rating-widget/rating-widget.php\";}}s:11:\"plugin_data\";a:1:{s:13:\"rating-widget\";a:17:{s:16:\"plugin_main_file\";O:8:\"stdClass\":1:{s:4:\"path\";s:31:\"rating-widget/rating-widget.php\";}s:20:\"is_network_activated\";b:0;s:17:\"install_timestamp\";i:1623469811;s:17:\"was_plugin_loaded\";b:1;s:21:\"is_plugin_new_install\";b:1;s:16:\"sdk_last_version\";N;s:11:\"sdk_version\";s:5:\"2.4.2\";s:16:\"sdk_upgrade_mode\";b:1;s:18:\"sdk_downgrade_mode\";b:0;s:19:\"plugin_last_version\";N;s:14:\"plugin_version\";s:5:\"3.1.2\";s:19:\"plugin_upgrade_mode\";b:0;s:21:\"plugin_downgrade_mode\";b:0;s:17:\"connectivity_test\";a:6:{s:12:\"is_connected\";b:1;s:4:\"host\";s:9:\"localhost\";s:9:\"server_ip\";s:3:\"::1\";s:9:\"is_active\";b:1;s:9:\"timestamp\";i:1623469811;s:7:\"version\";s:5:\"3.1.2\";}s:15:\"prev_is_premium\";b:0;s:17:\"license_migration\";a:1:{s:12:\"is_migrating\";b:0;}s:21:\"is_pending_activation\";b:1;}}s:13:\"file_slug_map\";a:1:{s:31:\"rating-widget/rating-widget.php\";s:13:\"rating-widget\";}s:7:\"plugins\";a:1:{s:13:\"rating-widget\";O:9:\"FS_Plugin\":23:{s:16:\"parent_plugin_id\";N;s:5:\"title\";s:33:\"Rating-Widget: Star Review System\";s:4:\"slug\";s:13:\"rating-widget\";s:12:\"premium_slug\";s:21:\"rating-widget-premium\";s:4:\"type\";s:6:\"plugin\";s:20:\"affiliate_moderation\";s:8:\"selected\";s:19:\"is_wp_org_compliant\";b:1;s:22:\"premium_releases_count\";N;s:4:\"file\";s:31:\"rating-widget/rating-widget.php\";s:7:\"version\";s:5:\"3.1.2\";s:11:\"auto_update\";N;s:4:\"info\";N;s:10:\"is_premium\";b:0;s:14:\"premium_suffix\";s:9:\"(Premium)\";s:7:\"is_live\";b:1;s:9:\"bundle_id\";N;s:17:\"bundle_public_key\";N;s:10:\"public_key\";s:32:\"pk_74be465babd9d3d6d5ff578d56745\";s:10:\"secret_key\";N;s:2:\"id\";s:2:\"56\";s:7:\"updated\";N;s:7:\"created\";N;s:22:\"\0FS_Entity\0_is_updated\";b:0;}}s:9:\"unique_id\";s:32:\"3f49be76a740ae9c45385d3b1d54047f\";s:13:\"admin_notices\";a:1:{s:13:\"rating-widget\";a:0:{}}s:6:\"addons\";a:1:{i:56;a:3:{i:0;O:9:\"FS_Plugin\":23:{s:16:\"parent_plugin_id\";s:2:\"56\";s:5:\"title\";s:6:\"Tweets\";s:4:\"slug\";s:15:\"rw-addon-tweets\";s:12:\"premium_slug\";s:23:\"rw-addon-tweets-premium\";s:4:\"type\";s:6:\"plugin\";s:20:\"affiliate_moderation\";N;s:19:\"is_wp_org_compliant\";b:1;s:22:\"premium_releases_count\";i:1;s:4:\"file\";N;s:7:\"version\";N;s:11:\"auto_update\";N;s:4:\"info\";O:14:\"FS_Plugin_Info\":13:{s:9:\"plugin_id\";s:2:\"68\";s:11:\"description\";s:478:\"<h3>How it works?</h3>\n<p>After a visitor will rate your content with a 4-star or 5-star rating, the <b>Tweets Add-On</b> will automatically open a window and suggest the visitor to share the rated content on Twitter.</p>\n<h3>Why it\'s great?</h3>\n<p>Readers that dig your content and made the effort to rate it with a high rating are the most qualified & engaged users for a follow-up action. They are the best visitors to ask to Tweet the content they just enjoyed reading.</p>\";s:17:\"short_description\";s:90:\"Get more Twitter shares by asking your visitors to Tweet the post after submitting a vote.\";s:10:\"banner_url\";s:40:\"//img.freemius.com/plugins/68/banner.jpg\";s:15:\"card_banner_url\";s:45:\"//img.freemius.com/plugins/68/card_banner.jpg\";s:15:\"selling_point_0\";s:36:\"Increase social traffic to your site\";s:15:\"selling_point_1\";s:47:\"Generate more shares of your content on Twitter\";s:15:\"selling_point_2\";s:41:\"Works out of the Box - Zero Configuration\";s:11:\"screenshots\";O:8:\"stdClass\":3:{s:12:\"screenshot_0\";s:66:\"//s3-us-west-2.amazonaws.com/freemius/plugins/68/screenshots/0.png\";s:12:\"screenshot_1\";s:66:\"//s3-us-west-2.amazonaws.com/freemius/plugins/68/screenshots/1.png\";s:12:\"screenshot_2\";s:66:\"//s3-us-west-2.amazonaws.com/freemius/plugins/68/screenshots/2.png\";}s:2:\"id\";s:1:\"7\";s:7:\"updated\";s:19:\"2016-03-16 16:14:18\";s:7:\"created\";s:19:\"2015-10-01 01:31:34\";s:22:\"\0FS_Entity\0_is_updated\";b:0;}s:10:\"is_premium\";b:0;s:14:\"premium_suffix\";s:9:\"(Premium)\";s:7:\"is_live\";b:1;s:9:\"bundle_id\";N;s:17:\"bundle_public_key\";N;s:10:\"public_key\";s:32:\"pk_848c598339c16b8d03c344185d6d9\";s:10:\"secret_key\";N;s:2:\"id\";s:2:\"68\";s:7:\"updated\";s:19:\"2021-05-18 05:54:46\";s:7:\"created\";s:19:\"2015-10-01 01:27:33\";s:22:\"\0FS_Entity\0_is_updated\";b:0;}i:1;O:9:\"FS_Plugin\":23:{s:16:\"parent_plugin_id\";s:2:\"56\";s:5:\"title\";s:6:\"Shares\";s:4:\"slug\";s:15:\"rw-addon-shares\";s:12:\"premium_slug\";s:23:\"rw-addon-shares-premium\";s:4:\"type\";s:6:\"plugin\";s:20:\"affiliate_moderation\";N;s:19:\"is_wp_org_compliant\";b:1;s:22:\"premium_releases_count\";i:3;s:4:\"file\";N;s:7:\"version\";N;s:11:\"auto_update\";N;s:4:\"info\";O:14:\"FS_Plugin_Info\":13:{s:9:\"plugin_id\";s:2:\"90\";s:11:\"description\";s:479:\"<h3>How it works?</h3>\n<p>After a visitor will rate your content with a 4-star or 5-star rating, the <b>Shares Add-On</b> will automatically open a window and suggest the visitor to share the rated content on Facebook.</p>\n<h3>Why it\'s great?</h3>\n<p>Readers that dig your content and made the effort to rate it with a high rating are the most qualified & engaged users for a follow-up action. They are the best visitors to ask to share the content they just enjoyed reading.</p>\";s:17:\"short_description\";s:91:\"Get more Facebook shares by asking your visitors to share the post after submitting a vote.\";s:10:\"banner_url\";s:40:\"//img.freemius.com/plugins/90/banner.jpg\";s:15:\"card_banner_url\";s:45:\"//img.freemius.com/plugins/90/card_banner.jpg\";s:15:\"selling_point_0\";s:36:\"Increase social traffic to your site\";s:15:\"selling_point_1\";s:48:\"Generate more shares of your content on Facebook\";s:15:\"selling_point_2\";s:41:\"Works out of the Box - Zero Configuration\";s:11:\"screenshots\";O:8:\"stdClass\":3:{s:12:\"screenshot_0\";s:47:\"//img.freemius.com/plugins/90/screenshots/0.png\";s:12:\"screenshot_1\";s:47:\"//img.freemius.com/plugins/90/screenshots/1.png\";s:12:\"screenshot_2\";s:47:\"//img.freemius.com/plugins/90/screenshots/2.png\";}s:2:\"id\";s:2:\"10\";s:7:\"updated\";s:19:\"2015-11-16 17:02:43\";s:7:\"created\";s:19:\"2015-11-15 04:02:01\";s:22:\"\0FS_Entity\0_is_updated\";b:0;}s:10:\"is_premium\";b:0;s:14:\"premium_suffix\";s:9:\"(Premium)\";s:7:\"is_live\";b:1;s:9:\"bundle_id\";N;s:17:\"bundle_public_key\";N;s:10:\"public_key\";s:32:\"pk_57b6749889e37d6a9fd103afc68ee\";s:10:\"secret_key\";N;s:2:\"id\";s:2:\"90\";s:7:\"updated\";s:19:\"2021-05-18 05:54:46\";s:7:\"created\";s:19:\"2015-11-15 03:55:26\";s:22:\"\0FS_Entity\0_is_updated\";b:0;}i:2;O:9:\"FS_Plugin\":23:{s:16:\"parent_plugin_id\";s:2:\"56\";s:5:\"title\";s:7:\"Reviews\";s:4:\"slug\";s:16:\"rw-addon-reviews\";s:12:\"premium_slug\";s:24:\"rw-addon-reviews-premium\";s:4:\"type\";s:6:\"plugin\";s:20:\"affiliate_moderation\";N;s:19:\"is_wp_org_compliant\";b:1;s:22:\"premium_releases_count\";i:1;s:4:\"file\";N;s:7:\"version\";N;s:11:\"auto_update\";N;s:4:\"info\";O:14:\"FS_Plugin_Info\":13:{s:9:\"plugin_id\";s:3:\"156\";s:11:\"description\";s:399:\"<h3>How it works?</h3>\n<p>After a visitor rates your content with a 5-star rating, the <b>Reviews Add-On</b> will automatically open a comment form and ask the visitor for a textual feedback.</p>\n<h3>Why it\'s great?</h3>\n<p>Whether you are writing an article or selling products, giving your visitors a chance to express their interests and concerns via text review is crucial for your business.</p>\";s:17:\"short_description\";s:122:\"Get valuable insights for your content & products by capturing a textual review from your visitors, right after they vote.\";s:10:\"banner_url\";s:41:\"//img.freemius.com/plugins/156/banner.jpg\";s:15:\"card_banner_url\";s:46:\"//img.freemius.com/plugins/156/card_banner.jpg\";s:15:\"selling_point_0\";s:86:\"Attract more traffic to your site by improving your content based on readers\' reviews!\";s:15:\"selling_point_1\";s:93:\"Get valuable insights for your site by asking the readers what they think about your content.\";s:15:\"selling_point_2\";s:41:\"Works out of the Box - Zero Configuration\";s:11:\"screenshots\";O:8:\"stdClass\":3:{s:12:\"screenshot_0\";s:48:\"//img.freemius.com/plugins/156/screenshots/0.png\";s:12:\"screenshot_1\";s:48:\"//img.freemius.com/plugins/156/screenshots/1.png\";s:12:\"screenshot_2\";s:48:\"//img.freemius.com/plugins/156/screenshots/2.png\";}s:2:\"id\";s:2:\"13\";s:7:\"updated\";s:19:\"2016-02-06 23:05:31\";s:7:\"created\";s:19:\"2015-12-28 15:08:40\";s:22:\"\0FS_Entity\0_is_updated\";b:0;}s:10:\"is_premium\";b:0;s:14:\"premium_suffix\";s:9:\"(Premium)\";s:7:\"is_live\";b:1;s:9:\"bundle_id\";N;s:17:\"bundle_public_key\";N;s:10:\"public_key\";s:32:\"pk_3ff7921741d1f83c76d1f99c21d17\";s:10:\"secret_key\";N;s:2:\"id\";s:3:\"156\";s:7:\"updated\";s:19:\"2021-06-08 07:33:18\";s:7:\"created\";s:19:\"2015-12-28 15:06:19\";s:22:\"\0FS_Entity\0_is_updated\";b:0;}}}}', 'yes'),
(410, 'fs_gdpr', 'a:1:{s:2:\"u1\";a:1:{s:8:\"required\";b:0;}}', 'yes'),
(411, 'fs_api_cache', 'a:1:{s:53:\"get:/v1/plugins/56/addons.json?enriched=true&count=50\";O:8:\"stdClass\":3:{s:6:\"result\";O:8:\"stdClass\":1:{s:7:\"plugins\";a:3:{i:0;O:8:\"stdClass\":39:{s:16:\"parent_plugin_id\";s:2:\"56\";s:12:\"developer_id\";s:3:\"478\";s:8:\"store_id\";s:1:\"3\";s:10:\"install_id\";s:6:\"441348\";s:4:\"slug\";s:15:\"rw-addon-tweets\";s:5:\"title\";s:6:\"Tweets\";s:11:\"environment\";i:0;s:4:\"icon\";s:41:\"https://wimg.freemius.com/plugin-icon.png\";s:15:\"default_plan_id\";s:3:\"123\";s:5:\"plans\";i:123;s:8:\"features\";s:15:\"264,266,265,267\";s:17:\"money_back_period\";N;s:13:\"refund_policy\";N;s:24:\"annual_renewals_discount\";N;s:22:\"renewals_discount_type\";s:10:\"percentage\";s:11:\"is_released\";b:1;s:15:\"is_sdk_required\";b:1;s:18:\"is_pricing_visible\";b:1;s:19:\"is_wp_org_compliant\";b:1;s:6:\"is_off\";b:0;s:24:\"is_only_for_new_installs\";b:0;s:14:\"installs_limit\";N;s:14:\"installs_count\";i:36;s:21:\"active_installs_count\";i:20;s:19:\"free_releases_count\";i:0;s:22:\"premium_releases_count\";i:1;s:15:\"total_purchases\";i:0;s:19:\"total_subscriptions\";i:9;s:14:\"total_renewals\";i:7;s:8:\"earnings\";d:259.85;s:10:\"commission\";s:14:\"{\"above\": 0.3}\";s:17:\"accepted_payments\";i:0;s:7:\"plan_id\";s:3:\"377\";s:4:\"type\";s:6:\"plugin\";s:10:\"public_key\";s:32:\"pk_848c598339c16b8d03c344185d6d9\";s:2:\"id\";s:2:\"68\";s:7:\"created\";s:19:\"2015-10-01 01:27:33\";s:7:\"updated\";s:19:\"2021-05-18 05:54:46\";s:4:\"info\";O:8:\"stdClass\":13:{s:9:\"plugin_id\";s:2:\"68\";s:3:\"url\";N;s:11:\"description\";s:478:\"<h3>How it works?</h3>\n<p>After a visitor will rate your content with a 4-star or 5-star rating, the <b>Tweets Add-On</b> will automatically open a window and suggest the visitor to share the rated content on Twitter.</p>\n<h3>Why it\'s great?</h3>\n<p>Readers that dig your content and made the effort to rate it with a high rating are the most qualified & engaged users for a follow-up action. They are the best visitors to ask to Tweet the content they just enjoyed reading.</p>\";s:17:\"short_description\";s:90:\"Get more Twitter shares by asking your visitors to Tweet the post after submitting a vote.\";s:10:\"banner_url\";s:40:\"//img.freemius.com/plugins/68/banner.jpg\";s:15:\"card_banner_url\";s:45:\"//img.freemius.com/plugins/68/card_banner.jpg\";s:15:\"selling_point_0\";s:36:\"Increase social traffic to your site\";s:15:\"selling_point_1\";s:47:\"Generate more shares of your content on Twitter\";s:15:\"selling_point_2\";s:41:\"Works out of the Box - Zero Configuration\";s:11:\"screenshots\";O:8:\"stdClass\":3:{s:12:\"screenshot_0\";s:66:\"//s3-us-west-2.amazonaws.com/freemius/plugins/68/screenshots/0.png\";s:12:\"screenshot_1\";s:66:\"//s3-us-west-2.amazonaws.com/freemius/plugins/68/screenshots/1.png\";s:12:\"screenshot_2\";s:66:\"//s3-us-west-2.amazonaws.com/freemius/plugins/68/screenshots/2.png\";}s:2:\"id\";s:1:\"7\";s:7:\"created\";s:19:\"2015-10-01 01:31:34\";s:7:\"updated\";s:19:\"2016-03-16 16:14:18\";}}i:1;O:8:\"stdClass\":39:{s:16:\"parent_plugin_id\";s:2:\"56\";s:12:\"developer_id\";s:3:\"478\";s:8:\"store_id\";s:1:\"3\";s:10:\"install_id\";s:6:\"441364\";s:4:\"slug\";s:15:\"rw-addon-shares\";s:5:\"title\";s:6:\"Shares\";s:11:\"environment\";i:0;s:4:\"icon\";s:41:\"https://wimg.freemius.com/plugin-icon.png\";s:15:\"default_plan_id\";s:3:\"142\";s:5:\"plans\";i:142;s:8:\"features\";s:11:\"270,271,272\";s:17:\"money_back_period\";N;s:13:\"refund_policy\";N;s:24:\"annual_renewals_discount\";N;s:22:\"renewals_discount_type\";s:10:\"percentage\";s:11:\"is_released\";b:1;s:15:\"is_sdk_required\";b:1;s:18:\"is_pricing_visible\";b:1;s:19:\"is_wp_org_compliant\";b:1;s:6:\"is_off\";b:0;s:24:\"is_only_for_new_installs\";b:0;s:14:\"installs_limit\";N;s:14:\"installs_count\";i:34;s:21:\"active_installs_count\";i:18;s:19:\"free_releases_count\";i:0;s:22:\"premium_releases_count\";i:3;s:15:\"total_purchases\";i:0;s:19:\"total_subscriptions\";i:23;s:14:\"total_renewals\";i:27;s:8:\"earnings\";d:565.36;s:10:\"commission\";s:14:\"{\"above\": 0.3}\";s:17:\"accepted_payments\";i:0;s:7:\"plan_id\";s:3:\"377\";s:4:\"type\";s:6:\"plugin\";s:10:\"public_key\";s:32:\"pk_57b6749889e37d6a9fd103afc68ee\";s:2:\"id\";s:2:\"90\";s:7:\"created\";s:19:\"2015-11-15 03:55:26\";s:7:\"updated\";s:19:\"2021-05-18 05:54:46\";s:4:\"info\";O:8:\"stdClass\":13:{s:9:\"plugin_id\";s:2:\"90\";s:3:\"url\";N;s:11:\"description\";s:479:\"<h3>How it works?</h3>\n<p>After a visitor will rate your content with a 4-star or 5-star rating, the <b>Shares Add-On</b> will automatically open a window and suggest the visitor to share the rated content on Facebook.</p>\n<h3>Why it\'s great?</h3>\n<p>Readers that dig your content and made the effort to rate it with a high rating are the most qualified & engaged users for a follow-up action. They are the best visitors to ask to share the content they just enjoyed reading.</p>\";s:17:\"short_description\";s:91:\"Get more Facebook shares by asking your visitors to share the post after submitting a vote.\";s:10:\"banner_url\";s:40:\"//img.freemius.com/plugins/90/banner.jpg\";s:15:\"card_banner_url\";s:45:\"//img.freemius.com/plugins/90/card_banner.jpg\";s:15:\"selling_point_0\";s:36:\"Increase social traffic to your site\";s:15:\"selling_point_1\";s:48:\"Generate more shares of your content on Facebook\";s:15:\"selling_point_2\";s:41:\"Works out of the Box - Zero Configuration\";s:11:\"screenshots\";O:8:\"stdClass\":3:{s:12:\"screenshot_0\";s:47:\"//img.freemius.com/plugins/90/screenshots/0.png\";s:12:\"screenshot_1\";s:47:\"//img.freemius.com/plugins/90/screenshots/1.png\";s:12:\"screenshot_2\";s:47:\"//img.freemius.com/plugins/90/screenshots/2.png\";}s:2:\"id\";s:2:\"10\";s:7:\"created\";s:19:\"2015-11-15 04:02:01\";s:7:\"updated\";s:19:\"2015-11-16 17:02:43\";}}i:2;O:8:\"stdClass\":40:{s:16:\"parent_plugin_id\";s:2:\"56\";s:12:\"developer_id\";s:3:\"478\";s:8:\"store_id\";s:1:\"3\";s:10:\"install_id\";s:6:\"441739\";s:4:\"slug\";s:16:\"rw-addon-reviews\";s:5:\"title\";s:7:\"Reviews\";s:11:\"environment\";i:0;s:4:\"icon\";s:41:\"https://wimg.freemius.com/plugin-icon.png\";s:15:\"default_plan_id\";s:3:\"212\";s:5:\"plans\";i:212;s:8:\"features\";s:11:\"290,291,292\";s:17:\"money_back_period\";N;s:13:\"refund_policy\";N;s:24:\"annual_renewals_discount\";N;s:22:\"renewals_discount_type\";s:10:\"percentage\";s:11:\"is_released\";b:1;s:15:\"is_sdk_required\";b:1;s:18:\"is_pricing_visible\";b:1;s:19:\"is_wp_org_compliant\";b:1;s:6:\"is_off\";b:0;s:24:\"is_only_for_new_installs\";b:0;s:14:\"installs_limit\";N;s:14:\"installs_count\";i:335;s:21:\"active_installs_count\";i:280;s:19:\"free_releases_count\";i:0;s:22:\"premium_releases_count\";i:1;s:15:\"total_purchases\";i:0;s:19:\"total_subscriptions\";i:62;s:14:\"total_renewals\";i:128;s:8:\"earnings\";d:2049.04;s:10:\"commission\";s:14:\"{\"above\": 0.3}\";s:17:\"accepted_payments\";i:0;s:7:\"plan_id\";s:1:\"3\";s:4:\"type\";s:6:\"plugin\";s:10:\"public_key\";s:32:\"pk_3ff7921741d1f83c76d1f99c21d17\";s:2:\"id\";s:3:\"156\";s:7:\"created\";s:19:\"2015-12-28 15:06:19\";s:7:\"updated\";s:19:\"2021-06-08 07:33:18\";s:4:\"info\";O:8:\"stdClass\":13:{s:9:\"plugin_id\";s:3:\"156\";s:3:\"url\";N;s:11:\"description\";s:399:\"<h3>How it works?</h3>\n<p>After a visitor rates your content with a 5-star rating, the <b>Reviews Add-On</b> will automatically open a comment form and ask the visitor for a textual feedback.</p>\n<h3>Why it\'s great?</h3>\n<p>Whether you are writing an article or selling products, giving your visitors a chance to express their interests and concerns via text review is crucial for your business.</p>\";s:17:\"short_description\";s:122:\"Get valuable insights for your content & products by capturing a textual review from your visitors, right after they vote.\";s:10:\"banner_url\";s:41:\"//img.freemius.com/plugins/156/banner.jpg\";s:15:\"card_banner_url\";s:46:\"//img.freemius.com/plugins/156/card_banner.jpg\";s:15:\"selling_point_0\";s:86:\"Attract more traffic to your site by improving your content based on readers\' reviews!\";s:15:\"selling_point_1\";s:93:\"Get valuable insights for your site by asking the readers what they think about your content.\";s:15:\"selling_point_2\";s:41:\"Works out of the Box - Zero Configuration\";s:11:\"screenshots\";O:8:\"stdClass\":3:{s:12:\"screenshot_0\";s:48:\"//img.freemius.com/plugins/156/screenshots/0.png\";s:12:\"screenshot_1\";s:48:\"//img.freemius.com/plugins/156/screenshots/1.png\";s:12:\"screenshot_2\";s:48:\"//img.freemius.com/plugins/156/screenshots/2.png\";}s:2:\"id\";s:2:\"13\";s:7:\"created\";s:19:\"2015-12-28 15:08:40\";s:7:\"updated\";s:19:\"2016-02-06 23:05:31\";}s:12:\"premium_slug\";s:24:\"rw-addon-reviews-premium\";}}}s:7:\"created\";i:1623469840;s:9:\"timestamp\";i:1623556240;}}', 'no'),
(414, 'widget_ratingwidgetplugin_topratedwidget', 'a:2:{i:2;a:29:{s:5:\"title\";s:9:\"Top Rated\";s:16:\"title_max_length\";i:30;s:10:\"show_posts\";i:1;s:16:\"show_posts_title\";i:0;s:11:\"posts_style\";s:14:\"compact_thumbs\";s:11:\"posts_title\";N;s:11:\"posts_count\";i:5;s:15:\"posts_min_votes\";i:1;s:13:\"posts_orderby\";s:7:\"avgrate\";s:11:\"posts_order\";s:4:\"DESC\";s:19:\"posts_since_created\";i:-1;s:10:\"show_pages\";i:0;s:16:\"show_pages_title\";i:0;s:11:\"pages_style\";s:14:\"compact_thumbs\";s:11:\"pages_title\";N;s:11:\"pages_count\";i:5;s:15:\"pages_min_votes\";i:1;s:13:\"pages_orderby\";s:7:\"avgrate\";s:11:\"pages_order\";s:4:\"DESC\";s:19:\"pages_since_created\";i:-1;s:13:\"show_comments\";i:0;s:19:\"show_comments_title\";i:0;s:14:\"comments_style\";N;s:14:\"comments_title\";N;s:14:\"comments_count\";i:5;s:18:\"comments_min_votes\";i:1;s:16:\"comments_orderby\";s:7:\"avgrate\";s:14:\"comments_order\";s:4:\"DESC\";s:22:\"comments_since_created\";i:-1;}s:12:\"_multiwidget\";i:1;}', 'yes'),
(417, '_site_transient_timeout_theme_roots', '1623473403', 'no'),
(418, '_site_transient_theme_roots', 'a:1:{s:4:\"lava\";s:7:\"/themes\";}', 'no'),
(420, 'postratings_image', 'stars_crystal', 'yes'),
(421, 'postratings_max', '5', 'yes'),
(422, 'postratings_template_vote', '%RATINGS_IMAGES_VOTE% (<strong>%RATINGS_USERS%</strong> votes, average: <strong>%RATINGS_AVERAGE%</strong> out of %RATINGS_MAX%)<br />%RATINGS_TEXT%', 'yes'),
(423, 'postratings_template_text', '%RATINGS_IMAGES% (<em><strong>%RATINGS_USERS%</strong> votes, average: <strong>%RATINGS_AVERAGE%</strong> out of %RATINGS_MAX%, <strong>rated</strong></em>)', 'yes'),
(424, 'postratings_template_none', '%RATINGS_IMAGES_VOTE% (No Ratings Yet)<br />%RATINGS_TEXT%', 'yes'),
(425, 'postratings_logging_method', '3', 'yes'),
(426, 'postratings_allowtorate', '2', 'yes'),
(427, 'postratings_ratingstext', 'a:5:{i:0;s:6:\"1 Star\";i:1;s:7:\"2 Stars\";i:2;s:7:\"3 Stars\";i:3;s:7:\"4 Stars\";i:4;s:7:\"5 Stars\";}', 'yes'),
(428, 'postratings_template_highestrated', '<li><a href=\"%POST_URL%\" title=\"%POST_TITLE%\">%POST_TITLE%</a> %RATINGS_IMAGES% (%RATINGS_AVERAGE% out of %RATINGS_MAX%)</li>', 'yes'),
(429, 'postratings_ajax_style', 'a:2:{s:7:\"loading\";i:1;s:6:\"fading\";i:1;}', 'yes'),
(430, 'postratings_ratingsvalue', 'a:5:{i:0;i:1;i:1;i:2;i:2;i:3;i:3;i:4;i:4;i:5;}', 'yes'),
(431, 'postratings_customrating', '0', 'yes'),
(432, 'postratings_template_permission', '%RATINGS_IMAGES% (<em><strong>%RATINGS_USERS%</strong> votes, average: <strong>%RATINGS_AVERAGE%</strong> out of %RATINGS_MAX%</em>)<br /><em>You need to be a registered member to rate this.</em>', 'yes'),
(433, 'postratings_template_mostrated', '<li><a href=\"%POST_URL%\" title=\"%POST_TITLE%\">%POST_TITLE%</a> - %RATINGS_USERS% votes</li>', 'yes'),
(434, 'widget_ratings-widget', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(435, 'postratings_options', 'a:2:{s:11:\"richsnippet\";i:1;s:19:\"richsnippet_ratings\";i:1;}', 'yes'),
(437, 'recovery_mode_email_last_sent', '1623480687', 'yes');

-- --------------------------------------------------------

--
-- Table structure for table `wp_postmeta`
--

CREATE TABLE `wp_postmeta` (
  `meta_id` bigint(20) UNSIGNED NOT NULL,
  `post_id` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_postmeta`
--

INSERT INTO `wp_postmeta` (`meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1, 2, '_wp_page_template', 'default'),
(2, 3, '_wp_page_template', 'default'),
(3, 3, '_edit_lock', '1623127312:1'),
(4, 2, '_wp_trash_meta_status', 'publish'),
(5, 2, '_wp_trash_meta_time', '1623127463'),
(6, 2, '_wp_desired_post_slug', 'sample-page'),
(7, 6, '_edit_last', '1'),
(8, 6, '_edit_lock', '1623127860:1'),
(9, 8, '_edit_last', '1'),
(10, 8, '_edit_lock', '1623127876:1'),
(11, 10, '_edit_last', '1'),
(12, 10, '_edit_lock', '1623129243:1'),
(13, 12, '_menu_item_type', 'custom'),
(14, 12, '_menu_item_menu_item_parent', '0'),
(15, 12, '_menu_item_object_id', '12'),
(16, 12, '_menu_item_object', 'custom'),
(17, 12, '_menu_item_target', ''),
(18, 12, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(19, 12, '_menu_item_xfn', ''),
(20, 12, '_menu_item_url', '#welcome'),
(22, 13, '_menu_item_type', 'custom'),
(23, 13, '_menu_item_menu_item_parent', '0'),
(24, 13, '_menu_item_object_id', '13'),
(25, 13, '_menu_item_object', 'custom'),
(26, 13, '_menu_item_target', ''),
(27, 13, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(28, 13, '_menu_item_xfn', ''),
(29, 13, '_menu_item_url', '#about'),
(31, 14, '_menu_item_type', 'custom'),
(32, 14, '_menu_item_menu_item_parent', '0'),
(33, 14, '_menu_item_object_id', '14'),
(34, 14, '_menu_item_object', 'custom'),
(35, 14, '_menu_item_target', ''),
(36, 14, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(37, 14, '_menu_item_xfn', ''),
(38, 14, '_menu_item_url', '#testimonials'),
(40, 15, '_menu_item_type', 'custom'),
(41, 15, '_menu_item_menu_item_parent', '0'),
(42, 15, '_menu_item_object_id', '15'),
(43, 15, '_menu_item_object', 'custom'),
(44, 15, '_menu_item_target', ''),
(45, 15, '_menu_item_classes', 'a:1:{i:0;s:7:\"submenu\";}'),
(46, 15, '_menu_item_xfn', ''),
(47, 15, '_menu_item_url', '#'),
(49, 16, '_menu_item_type', 'post_type'),
(50, 16, '_menu_item_menu_item_parent', '15'),
(51, 16, '_menu_item_object_id', '10'),
(52, 16, '_menu_item_object', 'page'),
(53, 16, '_menu_item_target', ''),
(54, 16, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(55, 16, '_menu_item_xfn', ''),
(56, 16, '_menu_item_url', ''),
(58, 17, '_menu_item_type', 'post_type'),
(59, 17, '_menu_item_menu_item_parent', '15'),
(60, 17, '_menu_item_object_id', '8'),
(61, 17, '_menu_item_object', 'page'),
(62, 17, '_menu_item_target', ''),
(63, 17, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(64, 17, '_menu_item_xfn', ''),
(65, 17, '_menu_item_url', ''),
(67, 18, '_menu_item_type', 'post_type'),
(68, 18, '_menu_item_menu_item_parent', '15'),
(69, 18, '_menu_item_object_id', '6'),
(70, 18, '_menu_item_object', 'page'),
(71, 18, '_menu_item_target', ''),
(72, 18, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(73, 18, '_menu_item_xfn', ''),
(74, 18, '_menu_item_url', ''),
(76, 19, '_edit_last', '1'),
(77, 19, '_edit_lock', '1623130853:1'),
(78, 21, '_menu_item_type', 'post_type'),
(79, 21, '_menu_item_menu_item_parent', '0'),
(80, 21, '_menu_item_object_id', '6'),
(81, 21, '_menu_item_object', 'page'),
(82, 21, '_menu_item_target', ''),
(83, 21, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(84, 21, '_menu_item_xfn', ''),
(85, 21, '_menu_item_url', ''),
(86, 21, '_menu_item_orphaned', '1623130923'),
(87, 22, '_menu_item_type', 'post_type'),
(88, 22, '_menu_item_menu_item_parent', '0'),
(89, 22, '_menu_item_object_id', '19'),
(90, 22, '_menu_item_object', 'page'),
(91, 22, '_menu_item_target', ''),
(92, 22, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(93, 22, '_menu_item_xfn', ''),
(94, 22, '_menu_item_url', ''),
(95, 22, '_menu_item_orphaned', '1623130986'),
(96, 19, '_wp_trash_meta_status', 'publish'),
(97, 19, '_wp_trash_meta_time', '1623130997'),
(98, 19, '_wp_desired_post_slug', 'contact-us'),
(99, 23, '_menu_item_type', 'custom'),
(100, 23, '_menu_item_menu_item_parent', '0'),
(101, 23, '_menu_item_object_id', '23'),
(102, 23, '_menu_item_object', 'custom'),
(103, 23, '_menu_item_target', ''),
(104, 23, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(105, 23, '_menu_item_xfn', ''),
(106, 23, '_menu_item_url', '#contact-us'),
(108, 24, '_wp_trash_meta_status', 'publish'),
(109, 24, '_wp_trash_meta_time', '1623131341'),
(110, 27, '_edit_lock', '1623132307:1'),
(111, 27, '_wp_trash_meta_status', 'publish'),
(112, 27, '_wp_trash_meta_time', '1623132322'),
(113, 28, '_form', '<label> Your name\n    [text* your-name] </label>\n\n<label> Your email\n    [email* your-email] </label>\n\n<label> Subject\n    [text* your-subject] </label>\n\n<label> Your message (optional)\n    [textarea your-message] </label>\n\n[submit \"Submit\"]'),
(114, 28, '_mail', 'a:9:{s:6:\"active\";b:1;s:7:\"subject\";s:30:\"[_site_title] \"[your-subject]\"\";s:6:\"sender\";s:48:\"[_site_title] <bilal.asghar.chuadhary@gmail.com>\";s:9:\"recipient\";s:19:\"[_site_admin_email]\";s:4:\"body\";s:163:\"From: [your-name] <[your-email]>\nSubject: [your-subject]\n\nMessage Body:\n[your-message]\n\n-- \nThis e-mail was sent from a contact form on [_site_title] ([_site_url])\";s:18:\"additional_headers\";s:22:\"Reply-To: [your-email]\";s:11:\"attachments\";s:0:\"\";s:8:\"use_html\";b:0;s:13:\"exclude_blank\";b:0;}'),
(115, 28, '_mail_2', 'a:9:{s:6:\"active\";b:0;s:7:\"subject\";s:30:\"[_site_title] \"[your-subject]\"\";s:6:\"sender\";s:48:\"[_site_title] <bilal.asghar.chuadhary@gmail.com>\";s:9:\"recipient\";s:12:\"[your-email]\";s:4:\"body\";s:105:\"Message Body:\n[your-message]\n\n-- \nThis e-mail was sent from a contact form on [_site_title] ([_site_url])\";s:18:\"additional_headers\";s:29:\"Reply-To: [_site_admin_email]\";s:11:\"attachments\";s:0:\"\";s:8:\"use_html\";b:0;s:13:\"exclude_blank\";b:0;}'),
(116, 28, '_messages', 'a:22:{s:12:\"mail_sent_ok\";s:45:\"Thank you for your message. It has been sent.\";s:12:\"mail_sent_ng\";s:71:\"There was an error trying to send your message. Please try again later.\";s:16:\"validation_error\";s:61:\"One or more fields have an error. Please check and try again.\";s:4:\"spam\";s:71:\"There was an error trying to send your message. Please try again later.\";s:12:\"accept_terms\";s:69:\"You must accept the terms and conditions before sending your message.\";s:16:\"invalid_required\";s:22:\"The field is required.\";s:16:\"invalid_too_long\";s:22:\"The field is too long.\";s:17:\"invalid_too_short\";s:23:\"The field is too short.\";s:13:\"upload_failed\";s:46:\"There was an unknown error uploading the file.\";s:24:\"upload_file_type_invalid\";s:49:\"You are not allowed to upload files of this type.\";s:21:\"upload_file_too_large\";s:20:\"The file is too big.\";s:23:\"upload_failed_php_error\";s:38:\"There was an error uploading the file.\";s:12:\"invalid_date\";s:29:\"The date format is incorrect.\";s:14:\"date_too_early\";s:44:\"The date is before the earliest one allowed.\";s:13:\"date_too_late\";s:41:\"The date is after the latest one allowed.\";s:14:\"invalid_number\";s:29:\"The number format is invalid.\";s:16:\"number_too_small\";s:47:\"The number is smaller than the minimum allowed.\";s:16:\"number_too_large\";s:46:\"The number is larger than the maximum allowed.\";s:23:\"quiz_answer_not_correct\";s:36:\"The answer to the quiz is incorrect.\";s:13:\"invalid_email\";s:38:\"The e-mail address entered is invalid.\";s:11:\"invalid_url\";s:19:\"The URL is invalid.\";s:11:\"invalid_tel\";s:32:\"The telephone number is invalid.\";}'),
(117, 28, '_additional_settings', ''),
(118, 28, '_locale', 'en_US'),
(121, 30, '_wp_trash_meta_status', 'publish'),
(122, 30, '_wp_trash_meta_time', '1623136810'),
(123, 31, '_wp_trash_meta_status', 'publish'),
(124, 31, '_wp_trash_meta_time', '1623137053'),
(125, 32, '_wp_attached_file', '2021/06/systemzones-resized-removebg-preview.png'),
(126, 32, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:190;s:6:\"height\";i:65;s:4:\"file\";s:48:\"2021/06/systemzones-resized-removebg-preview.png\";s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(127, 32, '_wp_attachment_image_alt', ''),
(128, 33, '_edit_lock', '1623137551:1'),
(129, 33, '_wp_trash_meta_status', 'publish'),
(130, 33, '_wp_trash_meta_time', '1623137559'),
(131, 34, '_edit_lock', '1623137591:1'),
(132, 34, '_wp_trash_meta_status', 'publish'),
(133, 34, '_wp_trash_meta_time', '1623137620'),
(134, 36, '_wp_trash_meta_status', 'publish'),
(135, 36, '_wp_trash_meta_time', '1623137662'),
(136, 38, '_edit_lock', '1623137778:1'),
(137, 38, '_wp_trash_meta_status', 'publish'),
(138, 38, '_wp_trash_meta_time', '1623137783'),
(139, 40, '_wp_trash_meta_status', 'publish'),
(140, 40, '_wp_trash_meta_time', '1623138143'),
(141, 42, '_wp_trash_meta_status', 'publish'),
(142, 42, '_wp_trash_meta_time', '1623138403'),
(143, 44, '_wp_trash_meta_status', 'publish'),
(144, 44, '_wp_trash_meta_time', '1623138538'),
(145, 46, '_wp_trash_meta_status', 'publish'),
(146, 46, '_wp_trash_meta_time', '1623138574'),
(147, 48, '_wp_trash_meta_status', 'publish'),
(148, 48, '_wp_trash_meta_time', '1623138624'),
(149, 50, '_edit_lock', '1623138779:1'),
(150, 50, '_wp_trash_meta_status', 'publish'),
(151, 50, '_wp_trash_meta_time', '1623138781'),
(152, 51, '_wp_trash_meta_status', 'publish'),
(153, 51, '_wp_trash_meta_time', '1623138969'),
(154, 53, '_wp_trash_meta_status', 'publish'),
(155, 53, '_wp_trash_meta_time', '1623139217'),
(156, 55, '_edit_lock', '1623139301:1'),
(157, 55, '_wp_trash_meta_status', 'publish'),
(158, 55, '_wp_trash_meta_time', '1623139302'),
(159, 57, '_form', '<div class=\"row\">\n	<div class=\"col-md-6 col-sm-12\">\n		<fieldset>\n			[text* your-name id:name placeholder \"Full Name\"]\n		</fieldset>\n	</div>\n	<div class=\"col-md-6 col-sm-12\">\n		<fieldset>\n			[email* email id:email placeholder \"E-Mail Address\"]\n		</fieldset>\n	</div>\n	<div class=\"col-lg-12\">\n		<fieldset>\n			[textarea* message id:message placeholder \"Your Message\"]\n		</fieldset>\n	</div>\n	<div class=\"col-lg-12\">\n		<fieldset>\n			[submit id:form-submit class:main-button \"Send Message\"]\n		</fieldset>\n	</div>\n</div>'),
(160, 57, '_mail', 'a:9:{s:6:\"active\";b:1;s:7:\"subject\";s:29:\"Message  from systemzones.com\";s:6:\"sender\";s:18:\"bilal@truishop.com\";s:9:\"recipient\";s:18:\"bilal@truishop.com\";s:4:\"body\";s:142:\"From: [your-name]\nEmail Address: [email]\n\nMessage Body:\n[message]\n\n-- \nThis e-mail was sent from a contact form on [_site_title] ([_site_url])\";s:18:\"additional_headers\";s:17:\"Reply-To: [email]\";s:11:\"attachments\";s:0:\"\";s:8:\"use_html\";b:0;s:13:\"exclude_blank\";b:0;}'),
(161, 57, '_mail_2', 'a:9:{s:6:\"active\";b:0;s:7:\"subject\";s:30:\"[_site_title] \"[your-subject]\"\";s:6:\"sender\";s:48:\"[_site_title] <bilal.asghar.chuadhary@gmail.com>\";s:9:\"recipient\";s:12:\"[your-email]\";s:4:\"body\";s:105:\"Message Body:\n[your-message]\n\n-- \nThis e-mail was sent from a contact form on [_site_title] ([_site_url])\";s:18:\"additional_headers\";s:29:\"Reply-To: [_site_admin_email]\";s:11:\"attachments\";s:0:\"\";s:8:\"use_html\";b:0;s:13:\"exclude_blank\";b:0;}'),
(162, 57, '_messages', 'a:22:{s:12:\"mail_sent_ok\";s:45:\"Thank you for your message. It has been sent.\";s:12:\"mail_sent_ng\";s:71:\"There was an error trying to send your message. Please try again later.\";s:16:\"validation_error\";s:61:\"One or more fields have an error. Please check and try again.\";s:4:\"spam\";s:71:\"There was an error trying to send your message. Please try again later.\";s:12:\"accept_terms\";s:69:\"You must accept the terms and conditions before sending your message.\";s:16:\"invalid_required\";s:22:\"The field is required.\";s:16:\"invalid_too_long\";s:22:\"The field is too long.\";s:17:\"invalid_too_short\";s:23:\"The field is too short.\";s:13:\"upload_failed\";s:46:\"There was an unknown error uploading the file.\";s:24:\"upload_file_type_invalid\";s:49:\"You are not allowed to upload files of this type.\";s:21:\"upload_file_too_large\";s:20:\"The file is too big.\";s:23:\"upload_failed_php_error\";s:38:\"There was an error uploading the file.\";s:12:\"invalid_date\";s:29:\"The date format is incorrect.\";s:14:\"date_too_early\";s:44:\"The date is before the earliest one allowed.\";s:13:\"date_too_late\";s:41:\"The date is after the latest one allowed.\";s:14:\"invalid_number\";s:29:\"The number format is invalid.\";s:16:\"number_too_small\";s:47:\"The number is smaller than the minimum allowed.\";s:16:\"number_too_large\";s:46:\"The number is larger than the maximum allowed.\";s:23:\"quiz_answer_not_correct\";s:36:\"The answer to the quiz is incorrect.\";s:13:\"invalid_email\";s:38:\"The e-mail address entered is invalid.\";s:11:\"invalid_url\";s:19:\"The URL is invalid.\";s:11:\"invalid_tel\";s:32:\"The telephone number is invalid.\";}'),
(163, 57, '_additional_settings', ''),
(164, 57, '_locale', 'en_US'),
(169, 58, '_edit_last', '1'),
(170, 58, '_edit_lock', '1623402921:1'),
(171, 63, '_edit_last', '1'),
(172, 63, '_edit_lock', '1623401140:1'),
(173, 63, '_wp_page_template', 'template.landing.php'),
(174, 63, 'heading', 'Simple App that we'),
(175, 63, '_heading', 'field_60c05b5904cde'),
(176, 63, 'banner_heading_em', 'CREATE'),
(177, 63, '_banner_heading_em', 'field_60c05c144cc3d'),
(178, 63, 'banner_desc', 'Lava HTML landing page template is provided by TemplateMo. You can modify and use it for your commercial websites for free of charge. This template is last updated on 29 Oct 2019.'),
(179, 63, '_banner_desc', 'field_60c05c384cc3e'),
(180, 63, 'banner_btn_link', ''),
(181, 63, '_banner_btn_link', 'field_60c05c6a4cc3f'),
(182, 65, 'heading', 'Simple App that we'),
(183, 65, '_heading', 'field_60c05b5904cde'),
(184, 65, 'banner_heading_em', 'CREATE'),
(185, 65, '_banner_heading_em', 'field_60c05c144cc3d'),
(186, 65, 'banner_desc', 'Lava HTML landing page template is provided by TemplateMo. You can modify and use it for your commercial websites for free of charge. This template is last updated on 29 Oct 2019.'),
(187, 65, '_banner_desc', 'field_60c05c384cc3e'),
(188, 65, 'banner_btn_link', ''),
(189, 65, '_banner_btn_link', 'field_60c05c6a4cc3f'),
(190, 63, 'banner_btn_link_id', '#about'),
(191, 63, '_banner_btn_link_id', 'field_60c05c6a4cc3f'),
(192, 66, 'heading', 'Simple App that we'),
(193, 66, '_heading', 'field_60c05b5904cde'),
(194, 66, 'banner_heading_em', 'CREATE'),
(195, 66, '_banner_heading_em', 'field_60c05c144cc3d'),
(196, 66, 'banner_desc', 'Lava HTML landing page template is provided by TemplateMo. You can modify and use it for your commercial websites for free of charge. This template is last updated on 29 Oct 2019.'),
(197, 66, '_banner_desc', 'field_60c05c384cc3e'),
(198, 66, 'banner_btn_link', ''),
(199, 66, '_banner_btn_link', 'field_60c05c6a4cc3f'),
(200, 66, 'banner_btn_link_id', '#about'),
(201, 66, '_banner_btn_link_id', 'field_60c05c6a4cc3f'),
(202, 63, 'banner_heading', 'Simple App that we'),
(203, 63, '_banner_heading', 'field_60c05b5904cde'),
(204, 67, 'heading', 'Simple App that we'),
(205, 67, '_heading', 'field_60c05b5904cde'),
(206, 67, 'banner_heading_em', 'CREATE'),
(207, 67, '_banner_heading_em', 'field_60c05c144cc3d'),
(208, 67, 'banner_desc', 'Lava HTML landing page template is provided by TemplateMo. You can modify and use it for your commercial websites for free of charge. This template is last updated on 29 Oct 2019.'),
(209, 67, '_banner_desc', 'field_60c05c384cc3e'),
(210, 67, 'banner_btn_link', ''),
(211, 67, '_banner_btn_link', 'field_60c05c6a4cc3f'),
(212, 67, 'banner_btn_link_id', '#about'),
(213, 67, '_banner_btn_link_id', 'field_60c05c6a4cc3f'),
(214, 67, 'banner_heading', 'Simple App that we'),
(215, 67, '_banner_heading', 'field_60c05b5904cde'),
(216, 63, 'banner_btn_text', 'KNOW US BETTER'),
(217, 63, '_banner_btn_text', 'field_60c064b2c2acc'),
(218, 69, 'heading', 'Simple App that we'),
(219, 69, '_heading', 'field_60c05b5904cde'),
(220, 69, 'banner_heading_em', 'CREATE'),
(221, 69, '_banner_heading_em', 'field_60c05c144cc3d'),
(222, 69, 'banner_desc', 'Lava HTML landing page template is provided by TemplateMo. You can modify and use it for your commercial websites for free of charge. This template is last updated on 29 Oct 2019.'),
(223, 69, '_banner_desc', 'field_60c05c384cc3e'),
(224, 69, 'banner_btn_link', ''),
(225, 69, '_banner_btn_link', 'field_60c05c6a4cc3f'),
(226, 69, 'banner_btn_link_id', '#about'),
(227, 69, '_banner_btn_link_id', 'field_60c05c6a4cc3f'),
(228, 69, 'banner_heading', 'Simple App that we'),
(229, 69, '_banner_heading', 'field_60c05b5904cde'),
(230, 69, 'banner_btn_text', 'KNOW US BETTER'),
(231, 69, '_banner_btn_text', 'field_60c064b2c2acc'),
(232, 70, '_menu_item_type', 'custom'),
(233, 70, '_menu_item_menu_item_parent', '0'),
(234, 70, '_menu_item_object_id', '70'),
(235, 70, '_menu_item_object', 'custom'),
(236, 70, '_menu_item_target', ''),
(237, 70, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(238, 70, '_menu_item_xfn', ''),
(239, 70, '_menu_item_url', '#promotion'),
(241, 12, '_wp_old_date', '2021-06-08'),
(242, 13, '_wp_old_date', '2021-06-08'),
(243, 14, '_wp_old_date', '2021-06-08'),
(244, 15, '_wp_old_date', '2021-06-08'),
(245, 17, '_wp_old_date', '2021-06-08'),
(246, 16, '_wp_old_date', '2021-06-08'),
(247, 18, '_wp_old_date', '2021-06-08'),
(248, 23, '_wp_old_date', '2021-06-08'),
(249, 72, '_wp_trash_meta_status', 'publish'),
(250, 72, '_wp_trash_meta_time', '1623311532'),
(251, 74, '_edit_lock', '1623311634:1'),
(252, 74, '_wp_trash_meta_status', 'publish'),
(253, 74, '_wp_trash_meta_time', '1623311642'),
(254, 76, '_edit_last', '1'),
(255, 76, '_edit_lock', '1623390560:1'),
(256, 82, '_edit_last', '1'),
(257, 82, 'service_no', '01'),
(258, 82, '_service_no', 'field_60c2e4a00b61a'),
(259, 82, 'service_icon', '<i class=\"fa fa-wordpress\"></i>'),
(260, 82, '_service_icon', 'field_60c2e61e0b61b'),
(261, 82, 'service_title', 'Customization'),
(262, 82, '_service_title', 'field_60c2e62d0b61c'),
(263, 82, 'service_desc', 'Curabitur pulvinar vel odio sed sagittis. Nam maximus ex diam, nec consectetur diam.'),
(264, 82, '_service_desc', 'field_60c2e63f0b61d'),
(265, 82, 'service_btn_text', 'Discover More'),
(266, 82, '_service_btn_text', 'field_60c2e6500b61e'),
(267, 82, '_edit_lock', '1623388575:1'),
(268, 83, '_edit_last', '1'),
(269, 83, '_edit_lock', '1623388722:1'),
(270, 83, 'service_no', '02'),
(271, 83, '_service_no', 'field_60c2e4a00b61a'),
(272, 83, 'service_icon', '<i class=\"fa fa-fire\"></i>'),
(273, 83, '_service_icon', 'field_60c2e61e0b61b'),
(274, 83, 'service_title', 'Site Optimization'),
(275, 83, '_service_title', 'field_60c2e62d0b61c'),
(276, 83, 'service_desc', 'Curabitur pulvinar vel odio sed sagittis. Nam maximus ex diam, nec consectetur diam.'),
(277, 83, '_service_desc', 'field_60c2e63f0b61d'),
(278, 83, 'service_btn_text', 'Discover More'),
(279, 83, '_service_btn_text', 'field_60c2e6500b61e'),
(280, 84, '_edit_last', '1'),
(281, 84, '_edit_lock', '1623388794:1'),
(282, 84, 'service_no', '03'),
(283, 84, '_service_no', 'field_60c2e4a00b61a'),
(284, 84, 'service_icon', '<i class=\"fa fa-pencil-square-o\"></i>'),
(285, 84, '_service_icon', 'field_60c2e61e0b61b'),
(286, 84, 'service_title', 'Email Design'),
(287, 84, '_service_title', 'field_60c2e62d0b61c'),
(288, 84, 'service_desc', 'Curabitur pulvinar vel odio sed sagittis. Nam maximus ex diam, nec consectetur diam.'),
(289, 84, '_service_desc', 'field_60c2e63f0b61d'),
(290, 84, 'service_btn_text', 'Discover More'),
(291, 84, '_service_btn_text', 'field_60c2e6500b61e'),
(292, 85, '_edit_last', '1'),
(293, 85, '_edit_lock', '1623388878:1'),
(294, 85, 'service_no', '04'),
(295, 85, '_service_no', 'field_60c2e4a00b61a'),
(296, 85, 'service_icon', '<i class=\"fa fa-line-chart\"></i>'),
(297, 85, '_service_icon', 'field_60c2e61e0b61b'),
(298, 85, 'service_title', 'Trend Analysis'),
(299, 85, '_service_title', 'field_60c2e62d0b61c'),
(300, 85, 'service_desc', 'Curabitur pulvinar vel odio sed sagittis. Nam maximus ex diam, nec consectetur diam.'),
(301, 85, '_service_desc', 'field_60c2e63f0b61d'),
(302, 85, 'service_btn_text', 'Discover More'),
(303, 85, '_service_btn_text', 'field_60c2e6500b61e'),
(304, 87, '_edit_last', '1'),
(305, 87, '_edit_lock', '1623388932:1'),
(306, 87, 'service_no', '05'),
(307, 87, '_service_no', 'field_60c2e4a00b61a'),
(308, 87, 'service_icon', '<i class=\"fa fa-search-minus\"></i>'),
(309, 87, '_service_icon', 'field_60c2e61e0b61b'),
(310, 87, 'service_title', 'SEO'),
(311, 87, '_service_title', 'field_60c2e62d0b61c'),
(312, 87, 'service_desc', 'Curabitur pulvinar vel odio sed sagittis. Nam maximus ex diam, nec consectetur diam.'),
(313, 87, '_service_desc', 'field_60c2e63f0b61d'),
(314, 87, 'service_btn_text', 'Discover More'),
(315, 87, '_service_btn_text', 'field_60c2e6500b61e'),
(316, 88, '_edit_last', '1'),
(317, 88, '_edit_lock', '1623390393:1'),
(318, 88, 'service_no', '06'),
(319, 88, '_service_no', 'field_60c2e4a00b61a'),
(320, 88, 'service_icon', '<i class=\"fa fa-tachometer\"></i>'),
(321, 88, '_service_icon', 'field_60c2e61e0b61b'),
(322, 88, 'service_title', 'Admin Dashboard'),
(323, 88, '_service_title', 'field_60c2e62d0b61c'),
(324, 88, 'service_desc', 'Curabitur pulvinar vel odio sed sagittis. Nam maximus ex diam, nec consectetur diam.'),
(325, 88, '_service_desc', 'field_60c2e63f0b61d'),
(326, 88, 'service_btn_text', 'Discover More'),
(327, 88, '_service_btn_text', 'field_60c2e6500b61e'),
(328, 89, '_edit_last', '1'),
(329, 89, '_edit_lock', '1623390785:1'),
(330, 90, '_edit_last', '1'),
(331, 90, '_edit_lock', '1623392948:1'),
(332, 89, 'promotion_icon', '<i class=\"fa fa-bullhorn\"></i>'),
(333, 89, '_promotion_icon', 'field_60c2fa723ed4a'),
(334, 92, '_edit_last', '1'),
(335, 92, '_edit_lock', '1623390889:1'),
(336, 92, 'promotion_icon', '<i class=\"fa fa-link\"></i>'),
(337, 92, '_promotion_icon', 'field_60c2fa723ed4a'),
(338, 93, '_edit_last', '1'),
(339, 93, '_edit_lock', '1623393420:1'),
(340, 93, 'promotion_icon', '<i class=\"fa fa-empire\"></i>'),
(341, 93, '_promotion_icon', 'field_60c2fa723ed4a'),
(342, 63, 'testimonial_main_title', 'What They Think'),
(343, 63, '_testimonial_main_title', 'field_60c1b2e56eb06'),
(344, 63, 'testimonial_main_title_emphasis', 'About Us'),
(345, 63, '_testimonial_main_title_emphasis', 'field_60c304dba9987'),
(346, 63, 'testimonial_short_desc', 'Suspendisse vitae laoreet mauris. Fusce a nisi dapibus, euismod purus non, convallis odio. Donec vitae magna ornare, pellentesque ex vitae, aliquet urna.'),
(347, 63, '_testimonial_short_desc', 'field_60c30374a9986'),
(348, 96, 'heading', 'Simple App that we'),
(349, 96, '_heading', 'field_60c05b5904cde'),
(350, 96, 'banner_heading_em', 'CREATE'),
(351, 96, '_banner_heading_em', 'field_60c05c144cc3d'),
(352, 96, 'banner_desc', 'Lava HTML landing page template is provided by TemplateMo. You can modify and use it for your commercial websites for free of charge. This template is last updated on 29 Oct 2019.'),
(353, 96, '_banner_desc', 'field_60c05c384cc3e'),
(354, 96, 'banner_btn_link', ''),
(355, 96, '_banner_btn_link', 'field_60c05c6a4cc3f'),
(356, 96, 'banner_btn_link_id', '#about'),
(357, 96, '_banner_btn_link_id', 'field_60c05c6a4cc3f'),
(358, 96, 'banner_heading', 'Simple App that we'),
(359, 96, '_banner_heading', 'field_60c05b5904cde'),
(360, 96, 'banner_btn_text', 'KNOW US BETTER'),
(361, 96, '_banner_btn_text', 'field_60c064b2c2acc'),
(362, 96, 'testimonial_main_title', 'What They Think'),
(363, 96, '_testimonial_main_title', 'field_60c1b2e56eb06'),
(364, 96, 'testimonial_main_title_emphasis', 'About Us'),
(365, 96, '_testimonial_main_title_emphasis', 'field_60c304dba9987'),
(366, 96, 'testimonial_short_desc', 'Suspendisse vitae laoreet mauris. Fusce a nisi dapibus, euismod purus non, convallis odio. Donec vitae magna ornare, pellentesque ex vitae, aliquet urna.'),
(367, 96, '_testimonial_short_desc', 'field_60c30374a9986'),
(368, 63, 'section_title_section_service', 'Services'),
(369, 63, '_section_title_section_service', 'field_60c306cee457f'),
(370, 63, 'section_title_section_promotion', 'Promotions'),
(371, 63, '_section_title_section_promotion', 'field_60c30717e4580'),
(372, 63, 'section_title_section_feedback', 'Feedback'),
(373, 63, '_section_title_section_feedback', 'field_60c30730e4581'),
(374, 63, 'section_title_section_contact', 'Conact Us'),
(375, 63, '_section_title_section_contact', 'field_60c30752e4582'),
(376, 63, 'section_title', ''),
(377, 63, '_section_title', 'field_60c306aae457e'),
(378, 102, 'heading', 'Simple App that we'),
(379, 102, '_heading', 'field_60c05b5904cde'),
(380, 102, 'banner_heading_em', 'CREATE'),
(381, 102, '_banner_heading_em', 'field_60c05c144cc3d'),
(382, 102, 'banner_desc', 'Lava HTML landing page template is provided by TemplateMo. You can modify and use it for your commercial websites for free of charge. This template is last updated on 29 Oct 2019.'),
(383, 102, '_banner_desc', 'field_60c05c384cc3e'),
(384, 102, 'banner_btn_link', ''),
(385, 102, '_banner_btn_link', 'field_60c05c6a4cc3f'),
(386, 102, 'banner_btn_link_id', '#about'),
(387, 102, '_banner_btn_link_id', 'field_60c05c6a4cc3f'),
(388, 102, 'banner_heading', 'Simple App that we'),
(389, 102, '_banner_heading', 'field_60c05b5904cde'),
(390, 102, 'banner_btn_text', 'KNOW US BETTER'),
(391, 102, '_banner_btn_text', 'field_60c064b2c2acc'),
(392, 102, 'testimonial_main_title', 'What They Think'),
(393, 102, '_testimonial_main_title', 'field_60c1b2e56eb06'),
(394, 102, 'testimonial_main_title_emphasis', 'About Us'),
(395, 102, '_testimonial_main_title_emphasis', 'field_60c304dba9987'),
(396, 102, 'testimonial_short_desc', 'Suspendisse vitae laoreet mauris. Fusce a nisi dapibus, euismod purus non, convallis odio. Donec vitae magna ornare, pellentesque ex vitae, aliquet urna.'),
(397, 102, '_testimonial_short_desc', 'field_60c30374a9986'),
(398, 102, 'section_title_section_service', 'Services'),
(399, 102, '_section_title_section_service', 'field_60c306cee457f'),
(400, 102, 'section_title_section_promotion', ''),
(401, 102, '_section_title_section_promotion', 'field_60c30717e4580'),
(402, 102, 'section_title_section_feedback', ''),
(403, 102, '_section_title_section_feedback', 'field_60c30730e4581'),
(404, 102, 'section_title_section_contact', ''),
(405, 102, '_section_title_section_contact', 'field_60c30752e4582'),
(406, 102, 'section_title', ''),
(407, 102, '_section_title', 'field_60c306aae457e'),
(408, 103, 'heading', 'Simple App that we'),
(409, 103, '_heading', 'field_60c05b5904cde'),
(410, 103, 'banner_heading_em', 'CREATE'),
(411, 103, '_banner_heading_em', 'field_60c05c144cc3d'),
(412, 103, 'banner_desc', 'Lava HTML landing page template is provided by TemplateMo. You can modify and use it for your commercial websites for free of charge. This template is last updated on 29 Oct 2019.'),
(413, 103, '_banner_desc', 'field_60c05c384cc3e'),
(414, 103, 'banner_btn_link', ''),
(415, 103, '_banner_btn_link', 'field_60c05c6a4cc3f'),
(416, 103, 'banner_btn_link_id', '#about'),
(417, 103, '_banner_btn_link_id', 'field_60c05c6a4cc3f'),
(418, 103, 'banner_heading', 'Simple App that we'),
(419, 103, '_banner_heading', 'field_60c05b5904cde'),
(420, 103, 'banner_btn_text', 'KNOW US BETTER'),
(421, 103, '_banner_btn_text', 'field_60c064b2c2acc'),
(422, 103, 'testimonial_main_title', 'What They Think'),
(423, 103, '_testimonial_main_title', 'field_60c1b2e56eb06'),
(424, 103, 'testimonial_main_title_emphasis', 'About Us'),
(425, 103, '_testimonial_main_title_emphasis', 'field_60c304dba9987'),
(426, 103, 'testimonial_short_desc', 'Suspendisse vitae laoreet mauris. Fusce a nisi dapibus, euismod purus non, convallis odio. Donec vitae magna ornare, pellentesque ex vitae, aliquet urna.'),
(427, 103, '_testimonial_short_desc', 'field_60c30374a9986'),
(428, 103, 'section_title_section_service', 'Services'),
(429, 103, '_section_title_section_service', 'field_60c306cee457f'),
(430, 103, 'section_title_section_promotion', 'Promotions'),
(431, 103, '_section_title_section_promotion', 'field_60c30717e4580'),
(432, 103, 'section_title_section_feedback', ''),
(433, 103, '_section_title_section_feedback', 'field_60c30730e4581'),
(434, 103, 'section_title_section_contact', ''),
(435, 103, '_section_title_section_contact', 'field_60c30752e4582'),
(436, 103, 'section_title', ''),
(437, 103, '_section_title', 'field_60c306aae457e'),
(438, 104, 'heading', 'Simple App that we'),
(439, 104, '_heading', 'field_60c05b5904cde'),
(440, 104, 'banner_heading_em', 'CREATE'),
(441, 104, '_banner_heading_em', 'field_60c05c144cc3d'),
(442, 104, 'banner_desc', 'Lava HTML landing page template is provided by TemplateMo. You can modify and use it for your commercial websites for free of charge. This template is last updated on 29 Oct 2019.'),
(443, 104, '_banner_desc', 'field_60c05c384cc3e'),
(444, 104, 'banner_btn_link', ''),
(445, 104, '_banner_btn_link', 'field_60c05c6a4cc3f'),
(446, 104, 'banner_btn_link_id', '#about'),
(447, 104, '_banner_btn_link_id', 'field_60c05c6a4cc3f'),
(448, 104, 'banner_heading', 'Simple App that we'),
(449, 104, '_banner_heading', 'field_60c05b5904cde'),
(450, 104, 'banner_btn_text', 'KNOW US BETTER'),
(451, 104, '_banner_btn_text', 'field_60c064b2c2acc'),
(452, 104, 'testimonial_main_title', 'What They Think'),
(453, 104, '_testimonial_main_title', 'field_60c1b2e56eb06'),
(454, 104, 'testimonial_main_title_emphasis', 'About Us'),
(455, 104, '_testimonial_main_title_emphasis', 'field_60c304dba9987'),
(456, 104, 'testimonial_short_desc', 'Suspendisse vitae laoreet mauris. Fusce a nisi dapibus, euismod purus non, convallis odio. Donec vitae magna ornare, pellentesque ex vitae, aliquet urna.'),
(457, 104, '_testimonial_short_desc', 'field_60c30374a9986'),
(458, 104, 'section_title_section_service', 'Services'),
(459, 104, '_section_title_section_service', 'field_60c306cee457f'),
(460, 104, 'section_title_section_promotion', 'Promotions'),
(461, 104, '_section_title_section_promotion', 'field_60c30717e4580'),
(462, 104, 'section_title_section_feedback', 'Feedback'),
(463, 104, '_section_title_section_feedback', 'field_60c30730e4581'),
(464, 104, 'section_title_section_contact', 'Conact Us'),
(465, 104, '_section_title_section_contact', 'field_60c30752e4582'),
(466, 104, 'section_title', ''),
(467, 104, '_section_title', 'field_60c306aae457e'),
(468, 105, '_edit_last', '1'),
(469, 105, '_edit_lock', '1623400695:1'),
(470, 63, 'contact_heading', 'More About'),
(471, 63, '_contact_heading', 'field_60c30c56d88ce'),
(472, 63, 'contact_heading_em', 'System Zones'),
(473, 63, '_contact_heading_em', 'field_60c30c5fd88cf'),
(474, 63, 'contact_desc', 'Phasellus dapibus urna vel lacus accumsan, iaculis eleifend leo auctor. Duis at finibus odio. Vivamus ut pharetra arcu, in porta metus. Suspendisse blandit pulvinar ligula ut elementum.\r\n\r\nIf you need this contact form to send email to your inbox, you may follow our contact page for more detail.'),
(475, 63, '_contact_desc', 'field_60c30c75d88d0'),
(476, 63, 'facebook_link', 'a:3:{s:5:\"title\";s:0:\"\";s:3:\"url\";s:25:\"https://www.facebook.com/\";s:6:\"target\";s:6:\"_blank\";}'),
(477, 63, '_facebook_link', 'field_60c30c98d88d1'),
(478, 63, 'twitter_link', 'a:3:{s:5:\"title\";s:0:\"\";s:3:\"url\";s:20:\"https://twitter.com/\";s:6:\"target\";s:6:\"_blank\";}'),
(479, 63, '_twitter_link', 'field_60c30cded88d2'),
(480, 63, 'linkedin_link', 'a:3:{s:5:\"title\";s:30:\"<i class=\"fa fa-linkedin\"></i>\";s:3:\"url\";s:51:\"https://www.linkedin.com/in/bilal-asghar-chuadhary/\";s:6:\"target\";s:6:\"_blank\";}'),
(481, 63, '_linkedin_link', 'field_60c30cf0d88d3'),
(482, 63, 'rss_link', ''),
(483, 63, '_rss_link', 'field_60c30d1ed88d4'),
(484, 104, 'contact_heading', ''),
(485, 104, '_contact_heading', 'field_60c30c56d88ce'),
(486, 104, 'contact_heading_em', ''),
(487, 104, '_contact_heading_em', 'field_60c30c5fd88cf'),
(488, 104, 'contact_desc', ''),
(489, 104, '_contact_desc', 'field_60c30c75d88d0'),
(490, 104, 'facebook_link', ''),
(491, 104, '_facebook_link', 'field_60c30c98d88d1'),
(492, 104, 'twitter_link', ''),
(493, 104, '_twitter_link', 'field_60c30cded88d2'),
(494, 104, 'linkedin_link', ''),
(495, 104, '_linkedin_link', 'field_60c30cf0d88d3'),
(496, 104, 'rss_link', ''),
(497, 104, '_rss_link', 'field_60c30d1ed88d4'),
(498, 113, 'heading', 'Simple App that we'),
(499, 113, '_heading', 'field_60c05b5904cde'),
(500, 113, 'banner_heading_em', 'CREATE'),
(501, 113, '_banner_heading_em', 'field_60c05c144cc3d'),
(502, 113, 'banner_desc', 'Lava HTML landing page template is provided by TemplateMo. You can modify and use it for your commercial websites for free of charge. This template is last updated on 29 Oct 2019.'),
(503, 113, '_banner_desc', 'field_60c05c384cc3e'),
(504, 113, 'banner_btn_link', ''),
(505, 113, '_banner_btn_link', 'field_60c05c6a4cc3f'),
(506, 113, 'banner_btn_link_id', '#about'),
(507, 113, '_banner_btn_link_id', 'field_60c05c6a4cc3f'),
(508, 113, 'banner_heading', 'Simple App that we'),
(509, 113, '_banner_heading', 'field_60c05b5904cde'),
(510, 113, 'banner_btn_text', 'KNOW US BETTER'),
(511, 113, '_banner_btn_text', 'field_60c064b2c2acc'),
(512, 113, 'testimonial_main_title', 'What They Think'),
(513, 113, '_testimonial_main_title', 'field_60c1b2e56eb06'),
(514, 113, 'testimonial_main_title_emphasis', 'About Us'),
(515, 113, '_testimonial_main_title_emphasis', 'field_60c304dba9987'),
(516, 113, 'testimonial_short_desc', 'Suspendisse vitae laoreet mauris. Fusce a nisi dapibus, euismod purus non, convallis odio. Donec vitae magna ornare, pellentesque ex vitae, aliquet urna.'),
(517, 113, '_testimonial_short_desc', 'field_60c30374a9986'),
(518, 113, 'section_title_section_service', 'Services'),
(519, 113, '_section_title_section_service', 'field_60c306cee457f'),
(520, 113, 'section_title_section_promotion', 'Promotions'),
(521, 113, '_section_title_section_promotion', 'field_60c30717e4580'),
(522, 113, 'section_title_section_feedback', 'Feedback'),
(523, 113, '_section_title_section_feedback', 'field_60c30730e4581'),
(524, 113, 'section_title_section_contact', 'Conact Us'),
(525, 113, '_section_title_section_contact', 'field_60c30752e4582'),
(526, 113, 'section_title', ''),
(527, 113, '_section_title', 'field_60c306aae457e'),
(528, 113, 'contact_heading', 'More About'),
(529, 113, '_contact_heading', 'field_60c30c56d88ce'),
(530, 113, 'contact_heading_em', '<?php bloginfo(\'name\'); ?>'),
(531, 113, '_contact_heading_em', 'field_60c30c5fd88cf'),
(532, 113, 'contact_desc', 'Phasellus dapibus urna vel lacus accumsan, iaculis eleifend leo auctor. Duis at finibus odio. Vivamus ut pharetra arcu, in porta metus. Suspendisse blandit pulvinar ligula ut elementum.\r\n\r\nIf you need this contact form to send email to your inbox, you may follow our contact page for more detail.'),
(533, 113, '_contact_desc', 'field_60c30c75d88d0'),
(534, 113, 'facebook_link', ''),
(535, 113, '_facebook_link', 'field_60c30c98d88d1'),
(536, 113, 'twitter_link', ''),
(537, 113, '_twitter_link', 'field_60c30cded88d2'),
(538, 113, 'linkedin_link', ''),
(539, 113, '_linkedin_link', 'field_60c30cf0d88d3'),
(540, 113, 'rss_link', ''),
(541, 113, '_rss_link', 'field_60c30d1ed88d4'),
(542, 114, 'heading', 'Simple App that we'),
(543, 114, '_heading', 'field_60c05b5904cde'),
(544, 114, 'banner_heading_em', 'CREATE'),
(545, 114, '_banner_heading_em', 'field_60c05c144cc3d'),
(546, 114, 'banner_desc', 'Lava HTML landing page template is provided by TemplateMo. You can modify and use it for your commercial websites for free of charge. This template is last updated on 29 Oct 2019.'),
(547, 114, '_banner_desc', 'field_60c05c384cc3e'),
(548, 114, 'banner_btn_link', ''),
(549, 114, '_banner_btn_link', 'field_60c05c6a4cc3f'),
(550, 114, 'banner_btn_link_id', '#about'),
(551, 114, '_banner_btn_link_id', 'field_60c05c6a4cc3f'),
(552, 114, 'banner_heading', 'Simple App that we'),
(553, 114, '_banner_heading', 'field_60c05b5904cde'),
(554, 114, 'banner_btn_text', 'KNOW US BETTER'),
(555, 114, '_banner_btn_text', 'field_60c064b2c2acc'),
(556, 114, 'testimonial_main_title', 'What They Think'),
(557, 114, '_testimonial_main_title', 'field_60c1b2e56eb06'),
(558, 114, 'testimonial_main_title_emphasis', 'About Us'),
(559, 114, '_testimonial_main_title_emphasis', 'field_60c304dba9987'),
(560, 114, 'testimonial_short_desc', 'Suspendisse vitae laoreet mauris. Fusce a nisi dapibus, euismod purus non, convallis odio. Donec vitae magna ornare, pellentesque ex vitae, aliquet urna.'),
(561, 114, '_testimonial_short_desc', 'field_60c30374a9986'),
(562, 114, 'section_title_section_service', 'Services'),
(563, 114, '_section_title_section_service', 'field_60c306cee457f'),
(564, 114, 'section_title_section_promotion', 'Promotions'),
(565, 114, '_section_title_section_promotion', 'field_60c30717e4580'),
(566, 114, 'section_title_section_feedback', 'Feedback'),
(567, 114, '_section_title_section_feedback', 'field_60c30730e4581'),
(568, 114, 'section_title_section_contact', 'Conact Us'),
(569, 114, '_section_title_section_contact', 'field_60c30752e4582'),
(570, 114, 'section_title', ''),
(571, 114, '_section_title', 'field_60c306aae457e'),
(572, 114, 'contact_heading', 'More About'),
(573, 114, '_contact_heading', 'field_60c30c56d88ce'),
(574, 114, 'contact_heading_em', 'System Zones'),
(575, 114, '_contact_heading_em', 'field_60c30c5fd88cf'),
(576, 114, 'contact_desc', 'Phasellus dapibus urna vel lacus accumsan, iaculis eleifend leo auctor. Duis at finibus odio. Vivamus ut pharetra arcu, in porta metus. Suspendisse blandit pulvinar ligula ut elementum.\r\n\r\nIf you need this contact form to send email to your inbox, you may follow our contact page for more detail.'),
(577, 114, '_contact_desc', 'field_60c30c75d88d0'),
(578, 114, 'facebook_link', ''),
(579, 114, '_facebook_link', 'field_60c30c98d88d1'),
(580, 114, 'twitter_link', ''),
(581, 114, '_twitter_link', 'field_60c30cded88d2'),
(582, 114, 'linkedin_link', ''),
(583, 114, '_linkedin_link', 'field_60c30cf0d88d3'),
(584, 114, 'rss_link', ''),
(585, 114, '_rss_link', 'field_60c30d1ed88d4'),
(586, 115, 'heading', 'Simple App that we'),
(587, 115, '_heading', 'field_60c05b5904cde'),
(588, 115, 'banner_heading_em', 'CREATE'),
(589, 115, '_banner_heading_em', 'field_60c05c144cc3d'),
(590, 115, 'banner_desc', 'Lava HTML landing page template is provided by TemplateMo. You can modify and use it for your commercial websites for free of charge. This template is last updated on 29 Oct 2019.'),
(591, 115, '_banner_desc', 'field_60c05c384cc3e'),
(592, 115, 'banner_btn_link', ''),
(593, 115, '_banner_btn_link', 'field_60c05c6a4cc3f'),
(594, 115, 'banner_btn_link_id', '#about'),
(595, 115, '_banner_btn_link_id', 'field_60c05c6a4cc3f'),
(596, 115, 'banner_heading', 'Simple App that we'),
(597, 115, '_banner_heading', 'field_60c05b5904cde'),
(598, 115, 'banner_btn_text', 'KNOW US BETTER'),
(599, 115, '_banner_btn_text', 'field_60c064b2c2acc'),
(600, 115, 'testimonial_main_title', 'What They Think'),
(601, 115, '_testimonial_main_title', 'field_60c1b2e56eb06'),
(602, 115, 'testimonial_main_title_emphasis', 'About Us'),
(603, 115, '_testimonial_main_title_emphasis', 'field_60c304dba9987'),
(604, 115, 'testimonial_short_desc', 'Suspendisse vitae laoreet mauris. Fusce a nisi dapibus, euismod purus non, convallis odio. Donec vitae magna ornare, pellentesque ex vitae, aliquet urna.'),
(605, 115, '_testimonial_short_desc', 'field_60c30374a9986'),
(606, 115, 'section_title_section_service', 'Services'),
(607, 115, '_section_title_section_service', 'field_60c306cee457f'),
(608, 115, 'section_title_section_promotion', 'Promotions'),
(609, 115, '_section_title_section_promotion', 'field_60c30717e4580'),
(610, 115, 'section_title_section_feedback', 'Feedback'),
(611, 115, '_section_title_section_feedback', 'field_60c30730e4581'),
(612, 115, 'section_title_section_contact', 'Conact Us'),
(613, 115, '_section_title_section_contact', 'field_60c30752e4582'),
(614, 115, 'section_title', ''),
(615, 115, '_section_title', 'field_60c306aae457e'),
(616, 115, 'contact_heading', 'More About'),
(617, 115, '_contact_heading', 'field_60c30c56d88ce'),
(618, 115, 'contact_heading_em', 'System Zones'),
(619, 115, '_contact_heading_em', 'field_60c30c5fd88cf'),
(620, 115, 'contact_desc', 'Phasellus dapibus urna vel lacus accumsan, iaculis eleifend leo auctor. Duis at finibus odio. Vivamus ut pharetra arcu, in porta metus. Suspendisse blandit pulvinar ligula ut elementum.\r\n\r\n&nbsp;\r\n\r\nIf you need this contact form to send email to your inbox, you may follow our contact page for more detail.'),
(621, 115, '_contact_desc', 'field_60c30c75d88d0'),
(622, 115, 'facebook_link', ''),
(623, 115, '_facebook_link', 'field_60c30c98d88d1'),
(624, 115, 'twitter_link', ''),
(625, 115, '_twitter_link', 'field_60c30cded88d2'),
(626, 115, 'linkedin_link', ''),
(627, 115, '_linkedin_link', 'field_60c30cf0d88d3'),
(628, 115, 'rss_link', ''),
(629, 115, '_rss_link', 'field_60c30d1ed88d4'),
(630, 116, 'heading', 'Simple App that we'),
(631, 116, '_heading', 'field_60c05b5904cde'),
(632, 116, 'banner_heading_em', 'CREATE'),
(633, 116, '_banner_heading_em', 'field_60c05c144cc3d'),
(634, 116, 'banner_desc', 'Lava HTML landing page template is provided by TemplateMo. You can modify and use it for your commercial websites for free of charge. This template is last updated on 29 Oct 2019.'),
(635, 116, '_banner_desc', 'field_60c05c384cc3e'),
(636, 116, 'banner_btn_link', ''),
(637, 116, '_banner_btn_link', 'field_60c05c6a4cc3f'),
(638, 116, 'banner_btn_link_id', '#about'),
(639, 116, '_banner_btn_link_id', 'field_60c05c6a4cc3f'),
(640, 116, 'banner_heading', 'Simple App that we'),
(641, 116, '_banner_heading', 'field_60c05b5904cde'),
(642, 116, 'banner_btn_text', 'KNOW US BETTER'),
(643, 116, '_banner_btn_text', 'field_60c064b2c2acc'),
(644, 116, 'testimonial_main_title', 'What They Think'),
(645, 116, '_testimonial_main_title', 'field_60c1b2e56eb06'),
(646, 116, 'testimonial_main_title_emphasis', 'About Us'),
(647, 116, '_testimonial_main_title_emphasis', 'field_60c304dba9987'),
(648, 116, 'testimonial_short_desc', 'Suspendisse vitae laoreet mauris. Fusce a nisi dapibus, euismod purus non, convallis odio. Donec vitae magna ornare, pellentesque ex vitae, aliquet urna.'),
(649, 116, '_testimonial_short_desc', 'field_60c30374a9986'),
(650, 116, 'section_title_section_service', 'Services'),
(651, 116, '_section_title_section_service', 'field_60c306cee457f'),
(652, 116, 'section_title_section_promotion', 'Promotions'),
(653, 116, '_section_title_section_promotion', 'field_60c30717e4580'),
(654, 116, 'section_title_section_feedback', 'Feedback'),
(655, 116, '_section_title_section_feedback', 'field_60c30730e4581'),
(656, 116, 'section_title_section_contact', 'Conact Us'),
(657, 116, '_section_title_section_contact', 'field_60c30752e4582'),
(658, 116, 'section_title', ''),
(659, 116, '_section_title', 'field_60c306aae457e'),
(660, 116, 'contact_heading', 'More About'),
(661, 116, '_contact_heading', 'field_60c30c56d88ce'),
(662, 116, 'contact_heading_em', 'S/Z'),
(663, 116, '_contact_heading_em', 'field_60c30c5fd88cf'),
(664, 116, 'contact_desc', 'Phasellus dapibus urna vel lacus accumsan, iaculis eleifend leo auctor. Duis at finibus odio. Vivamus ut pharetra arcu, in porta metus. Suspendisse blandit pulvinar ligula ut elementum.\r\n\r\nIf you need this contact form to send email to your inbox, you may follow our contact page for more detail.'),
(665, 116, '_contact_desc', 'field_60c30c75d88d0'),
(666, 116, 'facebook_link', ''),
(667, 116, '_facebook_link', 'field_60c30c98d88d1'),
(668, 116, 'twitter_link', ''),
(669, 116, '_twitter_link', 'field_60c30cded88d2'),
(670, 116, 'linkedin_link', ''),
(671, 116, '_linkedin_link', 'field_60c30cf0d88d3'),
(672, 116, 'rss_link', ''),
(673, 116, '_rss_link', 'field_60c30d1ed88d4'),
(674, 117, 'heading', 'Simple App that we'),
(675, 117, '_heading', 'field_60c05b5904cde'),
(676, 117, 'banner_heading_em', 'CREATE'),
(677, 117, '_banner_heading_em', 'field_60c05c144cc3d'),
(678, 117, 'banner_desc', 'Lava HTML landing page template is provided by TemplateMo. You can modify and use it for your commercial websites for free of charge. This template is last updated on 29 Oct 2019.'),
(679, 117, '_banner_desc', 'field_60c05c384cc3e'),
(680, 117, 'banner_btn_link', ''),
(681, 117, '_banner_btn_link', 'field_60c05c6a4cc3f'),
(682, 117, 'banner_btn_link_id', '#about'),
(683, 117, '_banner_btn_link_id', 'field_60c05c6a4cc3f'),
(684, 117, 'banner_heading', 'Simple App that we'),
(685, 117, '_banner_heading', 'field_60c05b5904cde'),
(686, 117, 'banner_btn_text', 'KNOW US BETTER'),
(687, 117, '_banner_btn_text', 'field_60c064b2c2acc'),
(688, 117, 'testimonial_main_title', 'What They Think'),
(689, 117, '_testimonial_main_title', 'field_60c1b2e56eb06'),
(690, 117, 'testimonial_main_title_emphasis', 'About Us'),
(691, 117, '_testimonial_main_title_emphasis', 'field_60c304dba9987'),
(692, 117, 'testimonial_short_desc', 'Suspendisse vitae laoreet mauris. Fusce a nisi dapibus, euismod purus non, convallis odio. Donec vitae magna ornare, pellentesque ex vitae, aliquet urna.'),
(693, 117, '_testimonial_short_desc', 'field_60c30374a9986'),
(694, 117, 'section_title_section_service', 'Services'),
(695, 117, '_section_title_section_service', 'field_60c306cee457f'),
(696, 117, 'section_title_section_promotion', 'Promotions'),
(697, 117, '_section_title_section_promotion', 'field_60c30717e4580'),
(698, 117, 'section_title_section_feedback', 'Feedback'),
(699, 117, '_section_title_section_feedback', 'field_60c30730e4581'),
(700, 117, 'section_title_section_contact', 'Conact Us'),
(701, 117, '_section_title_section_contact', 'field_60c30752e4582'),
(702, 117, 'section_title', ''),
(703, 117, '_section_title', 'field_60c306aae457e'),
(704, 117, 'contact_heading', 'More About'),
(705, 117, '_contact_heading', 'field_60c30c56d88ce'),
(706, 117, 'contact_heading_em', 'S/Z'),
(707, 117, '_contact_heading_em', 'field_60c30c5fd88cf'),
(708, 117, 'contact_desc', '<p>Phasellus dapibus urna vel lacus accumsan, iaculis eleifend leo auctor. Duis at finibus odio. Vivamus ut pharetra arcu, in porta metus. Suspendisse blandit pulvinar ligula ut elementum.</p>\r\n<br /><br />\r\n<p>If you need this contact form to send email to your inbox, you may follow our contact page for more detail.</p>'),
(709, 117, '_contact_desc', 'field_60c30c75d88d0'),
(710, 117, 'facebook_link', ''),
(711, 117, '_facebook_link', 'field_60c30c98d88d1'),
(712, 117, 'twitter_link', ''),
(713, 117, '_twitter_link', 'field_60c30cded88d2'),
(714, 117, 'linkedin_link', ''),
(715, 117, '_linkedin_link', 'field_60c30cf0d88d3'),
(716, 117, 'rss_link', ''),
(717, 117, '_rss_link', 'field_60c30d1ed88d4'),
(718, 118, 'heading', 'Simple App that we'),
(719, 118, '_heading', 'field_60c05b5904cde'),
(720, 118, 'banner_heading_em', 'CREATE'),
(721, 118, '_banner_heading_em', 'field_60c05c144cc3d'),
(722, 118, 'banner_desc', 'Lava HTML landing page template is provided by TemplateMo. You can modify and use it for your commercial websites for free of charge. This template is last updated on 29 Oct 2019.'),
(723, 118, '_banner_desc', 'field_60c05c384cc3e'),
(724, 118, 'banner_btn_link', ''),
(725, 118, '_banner_btn_link', 'field_60c05c6a4cc3f'),
(726, 118, 'banner_btn_link_id', '#about'),
(727, 118, '_banner_btn_link_id', 'field_60c05c6a4cc3f'),
(728, 118, 'banner_heading', 'Simple App that we'),
(729, 118, '_banner_heading', 'field_60c05b5904cde'),
(730, 118, 'banner_btn_text', 'KNOW US BETTER'),
(731, 118, '_banner_btn_text', 'field_60c064b2c2acc'),
(732, 118, 'testimonial_main_title', 'What They Think'),
(733, 118, '_testimonial_main_title', 'field_60c1b2e56eb06'),
(734, 118, 'testimonial_main_title_emphasis', 'About Us'),
(735, 118, '_testimonial_main_title_emphasis', 'field_60c304dba9987'),
(736, 118, 'testimonial_short_desc', 'Suspendisse vitae laoreet mauris. Fusce a nisi dapibus, euismod purus non, convallis odio. Donec vitae magna ornare, pellentesque ex vitae, aliquet urna.'),
(737, 118, '_testimonial_short_desc', 'field_60c30374a9986'),
(738, 118, 'section_title_section_service', 'Services'),
(739, 118, '_section_title_section_service', 'field_60c306cee457f'),
(740, 118, 'section_title_section_promotion', 'Promotions'),
(741, 118, '_section_title_section_promotion', 'field_60c30717e4580'),
(742, 118, 'section_title_section_feedback', 'Feedback'),
(743, 118, '_section_title_section_feedback', 'field_60c30730e4581'),
(744, 118, 'section_title_section_contact', 'Conact Us'),
(745, 118, '_section_title_section_contact', 'field_60c30752e4582'),
(746, 118, 'section_title', ''),
(747, 118, '_section_title', 'field_60c306aae457e'),
(748, 118, 'contact_heading', 'More About'),
(749, 118, '_contact_heading', 'field_60c30c56d88ce'),
(750, 118, 'contact_heading_em', 'S/Z'),
(751, 118, '_contact_heading_em', 'field_60c30c5fd88cf'),
(752, 118, 'contact_desc', 'Phasellus dapibus urna vel lacus accumsan, iaculis eleifend leo auctor. Duis at finibus odio. Vivamus ut pharetra arcu, in porta metus. Suspendisse blandit pulvinar ligula ut elementum.\r\n\r\n&nbsp;\r\n\r\nIf you need this contact form to send email to your inbox, you may follow our contact page for more detail.'),
(753, 118, '_contact_desc', 'field_60c30c75d88d0'),
(754, 118, 'facebook_link', ''),
(755, 118, '_facebook_link', 'field_60c30c98d88d1'),
(756, 118, 'twitter_link', ''),
(757, 118, '_twitter_link', 'field_60c30cded88d2'),
(758, 118, 'linkedin_link', ''),
(759, 118, '_linkedin_link', 'field_60c30cf0d88d3'),
(760, 118, 'rss_link', ''),
(761, 118, '_rss_link', 'field_60c30d1ed88d4'),
(762, 119, 'heading', 'Simple App that we'),
(763, 119, '_heading', 'field_60c05b5904cde'),
(764, 119, 'banner_heading_em', 'CREATE'),
(765, 119, '_banner_heading_em', 'field_60c05c144cc3d'),
(766, 119, 'banner_desc', 'Lava HTML landing page template is provided by TemplateMo. You can modify and use it for your commercial websites for free of charge. This template is last updated on 29 Oct 2019.'),
(767, 119, '_banner_desc', 'field_60c05c384cc3e'),
(768, 119, 'banner_btn_link', ''),
(769, 119, '_banner_btn_link', 'field_60c05c6a4cc3f'),
(770, 119, 'banner_btn_link_id', '#about'),
(771, 119, '_banner_btn_link_id', 'field_60c05c6a4cc3f'),
(772, 119, 'banner_heading', 'Simple App that we'),
(773, 119, '_banner_heading', 'field_60c05b5904cde'),
(774, 119, 'banner_btn_text', 'KNOW US BETTER'),
(775, 119, '_banner_btn_text', 'field_60c064b2c2acc'),
(776, 119, 'testimonial_main_title', 'What They Think'),
(777, 119, '_testimonial_main_title', 'field_60c1b2e56eb06'),
(778, 119, 'testimonial_main_title_emphasis', 'About Us'),
(779, 119, '_testimonial_main_title_emphasis', 'field_60c304dba9987'),
(780, 119, 'testimonial_short_desc', 'Suspendisse vitae laoreet mauris. Fusce a nisi dapibus, euismod purus non, convallis odio. Donec vitae magna ornare, pellentesque ex vitae, aliquet urna.'),
(781, 119, '_testimonial_short_desc', 'field_60c30374a9986'),
(782, 119, 'section_title_section_service', 'Services'),
(783, 119, '_section_title_section_service', 'field_60c306cee457f'),
(784, 119, 'section_title_section_promotion', 'Promotions'),
(785, 119, '_section_title_section_promotion', 'field_60c30717e4580'),
(786, 119, 'section_title_section_feedback', 'Feedback');
INSERT INTO `wp_postmeta` (`meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(787, 119, '_section_title_section_feedback', 'field_60c30730e4581'),
(788, 119, 'section_title_section_contact', 'Conact Us'),
(789, 119, '_section_title_section_contact', 'field_60c30752e4582'),
(790, 119, 'section_title', ''),
(791, 119, '_section_title', 'field_60c306aae457e'),
(792, 119, 'contact_heading', 'More About'),
(793, 119, '_contact_heading', 'field_60c30c56d88ce'),
(794, 119, 'contact_heading_em', 'S/Z'),
(795, 119, '_contact_heading_em', 'field_60c30c5fd88cf'),
(796, 119, 'contact_desc', 'Phasellus dapibus urna vel lacus accumsan, iaculis eleifend leo auctor. Duis at finibus odio. Vivamus ut pharetra arcu, in porta metus. Suspendisse blandit pulvinar ligula ut elementum.\r\n\r\nIf you need this contact form to send email to your inbox, you may follow our contact page for more detail.'),
(797, 119, '_contact_desc', 'field_60c30c75d88d0'),
(798, 119, 'facebook_link', 'a:3:{s:5:\"title\";s:42:\"&lt;i class=\"fa fa-facebook\"&gt;&lt;/i&gt;\";s:3:\"url\";s:25:\"https://www.facebook.com/\";s:6:\"target\";s:6:\"_blank\";}'),
(799, 119, '_facebook_link', 'field_60c30c98d88d1'),
(800, 119, 'twitter_link', 'a:3:{s:5:\"title\";s:41:\"&lt;i class=\"fa fa-twitter\"&gt;&lt;/i&gt;\";s:3:\"url\";s:20:\"https://twitter.com/\";s:6:\"target\";s:6:\"_blank\";}'),
(801, 119, '_twitter_link', 'field_60c30cded88d2'),
(802, 119, 'linkedin_link', 'a:3:{s:5:\"title\";s:42:\"&lt;i class=\"fa fa-linkedin\"&gt;&lt;/i&gt;\";s:3:\"url\";s:51:\"https://www.linkedin.com/in/bilal-asghar-chuadhary/\";s:6:\"target\";s:6:\"_blank\";}'),
(803, 119, '_linkedin_link', 'field_60c30cf0d88d3'),
(804, 119, 'rss_link', ''),
(805, 119, '_rss_link', 'field_60c30d1ed88d4'),
(806, 120, 'heading', 'Simple App that we'),
(807, 120, '_heading', 'field_60c05b5904cde'),
(808, 120, 'banner_heading_em', 'CREATE'),
(809, 120, '_banner_heading_em', 'field_60c05c144cc3d'),
(810, 120, 'banner_desc', 'Lava HTML landing page template is provided by TemplateMo. You can modify and use it for your commercial websites for free of charge. This template is last updated on 29 Oct 2019.'),
(811, 120, '_banner_desc', 'field_60c05c384cc3e'),
(812, 120, 'banner_btn_link', ''),
(813, 120, '_banner_btn_link', 'field_60c05c6a4cc3f'),
(814, 120, 'banner_btn_link_id', '#about'),
(815, 120, '_banner_btn_link_id', 'field_60c05c6a4cc3f'),
(816, 120, 'banner_heading', 'Simple App that we'),
(817, 120, '_banner_heading', 'field_60c05b5904cde'),
(818, 120, 'banner_btn_text', 'KNOW US BETTER'),
(819, 120, '_banner_btn_text', 'field_60c064b2c2acc'),
(820, 120, 'testimonial_main_title', 'What They Think'),
(821, 120, '_testimonial_main_title', 'field_60c1b2e56eb06'),
(822, 120, 'testimonial_main_title_emphasis', 'About Us'),
(823, 120, '_testimonial_main_title_emphasis', 'field_60c304dba9987'),
(824, 120, 'testimonial_short_desc', 'Suspendisse vitae laoreet mauris. Fusce a nisi dapibus, euismod purus non, convallis odio. Donec vitae magna ornare, pellentesque ex vitae, aliquet urna.'),
(825, 120, '_testimonial_short_desc', 'field_60c30374a9986'),
(826, 120, 'section_title_section_service', 'Services'),
(827, 120, '_section_title_section_service', 'field_60c306cee457f'),
(828, 120, 'section_title_section_promotion', 'Promotions'),
(829, 120, '_section_title_section_promotion', 'field_60c30717e4580'),
(830, 120, 'section_title_section_feedback', 'Feedback'),
(831, 120, '_section_title_section_feedback', 'field_60c30730e4581'),
(832, 120, 'section_title_section_contact', 'Conact Us'),
(833, 120, '_section_title_section_contact', 'field_60c30752e4582'),
(834, 120, 'section_title', ''),
(835, 120, '_section_title', 'field_60c306aae457e'),
(836, 120, 'contact_heading', 'More About'),
(837, 120, '_contact_heading', 'field_60c30c56d88ce'),
(838, 120, 'contact_heading_em', 'S/Z'),
(839, 120, '_contact_heading_em', 'field_60c30c5fd88cf'),
(840, 120, 'contact_desc', 'Phasellus dapibus urna vel lacus accumsan, iaculis eleifend leo auctor. Duis at finibus odio. Vivamus ut pharetra arcu, in porta metus. Suspendisse blandit pulvinar ligula ut elementum.\r\n\r\nIf you need this contact form to send email to your inbox, you may follow our contact page for more detail.'),
(841, 120, '_contact_desc', 'field_60c30c75d88d0'),
(842, 120, 'facebook_link', 'a:3:{s:5:\"title\";s:0:\"\";s:3:\"url\";s:25:\"https://www.facebook.com/\";s:6:\"target\";s:6:\"_blank\";}'),
(843, 120, '_facebook_link', 'field_60c30c98d88d1'),
(844, 120, 'twitter_link', 'a:3:{s:5:\"title\";s:0:\"\";s:3:\"url\";s:20:\"https://twitter.com/\";s:6:\"target\";s:6:\"_blank\";}'),
(845, 120, '_twitter_link', 'field_60c30cded88d2'),
(846, 120, 'linkedin_link', 'a:3:{s:5:\"title\";s:0:\"\";s:3:\"url\";s:51:\"https://www.linkedin.com/in/bilal-asghar-chuadhary/\";s:6:\"target\";s:6:\"_blank\";}'),
(847, 120, '_linkedin_link', 'field_60c30cf0d88d3'),
(848, 120, 'rss_link', ''),
(849, 120, '_rss_link', 'field_60c30d1ed88d4'),
(850, 121, 'heading', 'Simple App that we'),
(851, 121, '_heading', 'field_60c05b5904cde'),
(852, 121, 'banner_heading_em', 'CREATE'),
(853, 121, '_banner_heading_em', 'field_60c05c144cc3d'),
(854, 121, 'banner_desc', 'Lava HTML landing page template is provided by TemplateMo. You can modify and use it for your commercial websites for free of charge. This template is last updated on 29 Oct 2019.'),
(855, 121, '_banner_desc', 'field_60c05c384cc3e'),
(856, 121, 'banner_btn_link', ''),
(857, 121, '_banner_btn_link', 'field_60c05c6a4cc3f'),
(858, 121, 'banner_btn_link_id', '#about'),
(859, 121, '_banner_btn_link_id', 'field_60c05c6a4cc3f'),
(860, 121, 'banner_heading', 'Simple App that we'),
(861, 121, '_banner_heading', 'field_60c05b5904cde'),
(862, 121, 'banner_btn_text', 'KNOW US BETTER'),
(863, 121, '_banner_btn_text', 'field_60c064b2c2acc'),
(864, 121, 'testimonial_main_title', 'What They Think'),
(865, 121, '_testimonial_main_title', 'field_60c1b2e56eb06'),
(866, 121, 'testimonial_main_title_emphasis', 'About Us'),
(867, 121, '_testimonial_main_title_emphasis', 'field_60c304dba9987'),
(868, 121, 'testimonial_short_desc', 'Suspendisse vitae laoreet mauris. Fusce a nisi dapibus, euismod purus non, convallis odio. Donec vitae magna ornare, pellentesque ex vitae, aliquet urna.'),
(869, 121, '_testimonial_short_desc', 'field_60c30374a9986'),
(870, 121, 'section_title_section_service', 'Services'),
(871, 121, '_section_title_section_service', 'field_60c306cee457f'),
(872, 121, 'section_title_section_promotion', 'Promotions'),
(873, 121, '_section_title_section_promotion', 'field_60c30717e4580'),
(874, 121, 'section_title_section_feedback', 'Feedback'),
(875, 121, '_section_title_section_feedback', 'field_60c30730e4581'),
(876, 121, 'section_title_section_contact', 'Conact Us'),
(877, 121, '_section_title_section_contact', 'field_60c30752e4582'),
(878, 121, 'section_title', ''),
(879, 121, '_section_title', 'field_60c306aae457e'),
(880, 121, 'contact_heading', 'More About'),
(881, 121, '_contact_heading', 'field_60c30c56d88ce'),
(882, 121, 'contact_heading_em', 'S/Z'),
(883, 121, '_contact_heading_em', 'field_60c30c5fd88cf'),
(884, 121, 'contact_desc', 'Phasellus dapibus urna vel lacus accumsan, iaculis eleifend leo auctor. Duis at finibus odio. Vivamus ut pharetra arcu, in porta metus. Suspendisse blandit pulvinar ligula ut elementum.\r\n\r\nIf you need this contact form to send email to your inbox, you may follow our contact page for more detail.'),
(885, 121, '_contact_desc', 'field_60c30c75d88d0'),
(886, 121, 'facebook_link', 'a:3:{s:5:\"title\";s:0:\"\";s:3:\"url\";s:25:\"https://www.facebook.com/\";s:6:\"target\";s:6:\"_blank\";}'),
(887, 121, '_facebook_link', 'field_60c30c98d88d1'),
(888, 121, 'twitter_link', 'a:3:{s:5:\"title\";s:0:\"\";s:3:\"url\";s:20:\"https://twitter.com/\";s:6:\"target\";s:6:\"_blank\";}'),
(889, 121, '_twitter_link', 'field_60c30cded88d2'),
(890, 121, 'linkedin_link', 'a:3:{s:5:\"title\";s:42:\"&lt;i class=\"fa fa-linkedin\"&gt;&lt;/i&gt;\";s:3:\"url\";s:51:\"https://www.linkedin.com/in/bilal-asghar-chuadhary/\";s:6:\"target\";s:6:\"_blank\";}'),
(891, 121, '_linkedin_link', 'field_60c30cf0d88d3'),
(892, 121, 'rss_link', ''),
(893, 121, '_rss_link', 'field_60c30d1ed88d4'),
(894, 123, 'heading', 'Simple App that we'),
(895, 123, '_heading', 'field_60c05b5904cde'),
(896, 123, 'banner_heading_em', 'CREATE'),
(897, 123, '_banner_heading_em', 'field_60c05c144cc3d'),
(898, 123, 'banner_desc', 'Lava HTML landing page template is provided by TemplateMo. You can modify and use it for your commercial websites for free of charge. This template is last updated on 29 Oct 2019.'),
(899, 123, '_banner_desc', 'field_60c05c384cc3e'),
(900, 123, 'banner_btn_link', ''),
(901, 123, '_banner_btn_link', 'field_60c05c6a4cc3f'),
(902, 123, 'banner_btn_link_id', '#about'),
(903, 123, '_banner_btn_link_id', 'field_60c05c6a4cc3f'),
(904, 123, 'banner_heading', 'Simple App that we'),
(905, 123, '_banner_heading', 'field_60c05b5904cde'),
(906, 123, 'banner_btn_text', 'KNOW US BETTER'),
(907, 123, '_banner_btn_text', 'field_60c064b2c2acc'),
(908, 123, 'testimonial_main_title', 'What They Think'),
(909, 123, '_testimonial_main_title', 'field_60c1b2e56eb06'),
(910, 123, 'testimonial_main_title_emphasis', 'About Us'),
(911, 123, '_testimonial_main_title_emphasis', 'field_60c304dba9987'),
(912, 123, 'testimonial_short_desc', 'Suspendisse vitae laoreet mauris. Fusce a nisi dapibus, euismod purus non, convallis odio. Donec vitae magna ornare, pellentesque ex vitae, aliquet urna.'),
(913, 123, '_testimonial_short_desc', 'field_60c30374a9986'),
(914, 123, 'section_title_section_service', 'Services'),
(915, 123, '_section_title_section_service', 'field_60c306cee457f'),
(916, 123, 'section_title_section_promotion', 'Promotions'),
(917, 123, '_section_title_section_promotion', 'field_60c30717e4580'),
(918, 123, 'section_title_section_feedback', 'Feedback'),
(919, 123, '_section_title_section_feedback', 'field_60c30730e4581'),
(920, 123, 'section_title_section_contact', 'Conact Us'),
(921, 123, '_section_title_section_contact', 'field_60c30752e4582'),
(922, 123, 'section_title', ''),
(923, 123, '_section_title', 'field_60c306aae457e'),
(924, 123, 'contact_heading', 'More About'),
(925, 123, '_contact_heading', 'field_60c30c56d88ce'),
(926, 123, 'contact_heading_em', 'System Zones'),
(927, 123, '_contact_heading_em', 'field_60c30c5fd88cf'),
(928, 123, 'contact_desc', 'Phasellus dapibus urna vel lacus accumsan, iaculis eleifend leo auctor. Duis at finibus odio. Vivamus ut pharetra arcu, in porta metus. Suspendisse blandit pulvinar ligula ut elementum.\r\n\r\nIf you need this contact form to send email to your inbox, you may follow our contact page for more detail.'),
(929, 123, '_contact_desc', 'field_60c30c75d88d0'),
(930, 123, 'facebook_link', 'a:3:{s:5:\"title\";s:0:\"\";s:3:\"url\";s:25:\"https://www.facebook.com/\";s:6:\"target\";s:6:\"_blank\";}'),
(931, 123, '_facebook_link', 'field_60c30c98d88d1'),
(932, 123, 'twitter_link', 'a:3:{s:5:\"title\";s:0:\"\";s:3:\"url\";s:20:\"https://twitter.com/\";s:6:\"target\";s:6:\"_blank\";}'),
(933, 123, '_twitter_link', 'field_60c30cded88d2'),
(934, 123, 'linkedin_link', 'a:3:{s:5:\"title\";s:30:\"<i class=\"fa fa-linkedin\"></i>\";s:3:\"url\";s:51:\"https://www.linkedin.com/in/bilal-asghar-chuadhary/\";s:6:\"target\";s:6:\"_blank\";}'),
(935, 123, '_linkedin_link', 'field_60c30cf0d88d3'),
(936, 123, 'rss_link', ''),
(937, 123, '_rss_link', 'field_60c30d1ed88d4'),
(938, 124, '_wp_attached_file', '2021/06/left-image.png'),
(939, 124, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:470;s:6:\"height\";i:491;s:4:\"file\";s:22:\"2021/06/left-image.png\";s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(940, 124, '_wp_attachment_image_alt', 'Promotion of System Zones'),
(941, 63, 'promotion_image', '124'),
(942, 63, '_promotion_image', 'field_60c3218ff8c47'),
(943, 125, 'heading', 'Simple App that we'),
(944, 125, '_heading', 'field_60c05b5904cde'),
(945, 125, 'banner_heading_em', 'CREATE'),
(946, 125, '_banner_heading_em', 'field_60c05c144cc3d'),
(947, 125, 'banner_desc', 'Lava HTML landing page template is provided by TemplateMo. You can modify and use it for your commercial websites for free of charge. This template is last updated on 29 Oct 2019.'),
(948, 125, '_banner_desc', 'field_60c05c384cc3e'),
(949, 125, 'banner_btn_link', ''),
(950, 125, '_banner_btn_link', 'field_60c05c6a4cc3f'),
(951, 125, 'banner_btn_link_id', '#about'),
(952, 125, '_banner_btn_link_id', 'field_60c05c6a4cc3f'),
(953, 125, 'banner_heading', 'Simple App that we'),
(954, 125, '_banner_heading', 'field_60c05b5904cde'),
(955, 125, 'banner_btn_text', 'KNOW US BETTER'),
(956, 125, '_banner_btn_text', 'field_60c064b2c2acc'),
(957, 125, 'testimonial_main_title', 'What They Think'),
(958, 125, '_testimonial_main_title', 'field_60c1b2e56eb06'),
(959, 125, 'testimonial_main_title_emphasis', 'About Us'),
(960, 125, '_testimonial_main_title_emphasis', 'field_60c304dba9987'),
(961, 125, 'testimonial_short_desc', 'Suspendisse vitae laoreet mauris. Fusce a nisi dapibus, euismod purus non, convallis odio. Donec vitae magna ornare, pellentesque ex vitae, aliquet urna.'),
(962, 125, '_testimonial_short_desc', 'field_60c30374a9986'),
(963, 125, 'section_title_section_service', 'Services'),
(964, 125, '_section_title_section_service', 'field_60c306cee457f'),
(965, 125, 'section_title_section_promotion', 'Promotions'),
(966, 125, '_section_title_section_promotion', 'field_60c30717e4580'),
(967, 125, 'section_title_section_feedback', 'Feedback'),
(968, 125, '_section_title_section_feedback', 'field_60c30730e4581'),
(969, 125, 'section_title_section_contact', 'Conact Us'),
(970, 125, '_section_title_section_contact', 'field_60c30752e4582'),
(971, 125, 'section_title', ''),
(972, 125, '_section_title', 'field_60c306aae457e'),
(973, 125, 'contact_heading', 'More About'),
(974, 125, '_contact_heading', 'field_60c30c56d88ce'),
(975, 125, 'contact_heading_em', 'System Zones'),
(976, 125, '_contact_heading_em', 'field_60c30c5fd88cf'),
(977, 125, 'contact_desc', 'Phasellus dapibus urna vel lacus accumsan, iaculis eleifend leo auctor. Duis at finibus odio. Vivamus ut pharetra arcu, in porta metus. Suspendisse blandit pulvinar ligula ut elementum.\r\n\r\nIf you need this contact form to send email to your inbox, you may follow our contact page for more detail.'),
(978, 125, '_contact_desc', 'field_60c30c75d88d0'),
(979, 125, 'facebook_link', 'a:3:{s:5:\"title\";s:0:\"\";s:3:\"url\";s:25:\"https://www.facebook.com/\";s:6:\"target\";s:6:\"_blank\";}'),
(980, 125, '_facebook_link', 'field_60c30c98d88d1'),
(981, 125, 'twitter_link', 'a:3:{s:5:\"title\";s:0:\"\";s:3:\"url\";s:20:\"https://twitter.com/\";s:6:\"target\";s:6:\"_blank\";}'),
(982, 125, '_twitter_link', 'field_60c30cded88d2'),
(983, 125, 'linkedin_link', 'a:3:{s:5:\"title\";s:30:\"<i class=\"fa fa-linkedin\"></i>\";s:3:\"url\";s:51:\"https://www.linkedin.com/in/bilal-asghar-chuadhary/\";s:6:\"target\";s:6:\"_blank\";}'),
(984, 125, '_linkedin_link', 'field_60c30cf0d88d3'),
(985, 125, 'rss_link', ''),
(986, 125, '_rss_link', 'field_60c30d1ed88d4'),
(987, 125, 'promotion_image', '124'),
(988, 125, '_promotion_image', 'field_60c3218ff8c47'),
(989, 137, '_wp_attached_file', '2021/06/testimonial-author-1.png'),
(990, 137, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:130;s:6:\"height\";i:130;s:4:\"file\";s:32:\"2021/06/testimonial-author-1.png\";s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(991, 137, '_wp_attachment_image_alt', 'Author Three'),
(992, 136, '_edit_last', '1'),
(993, 136, '_edit_lock', '1623481683:1'),
(994, 136, '_thumbnail_id', '137'),
(995, 138, '_edit_last', '1'),
(996, 138, '_edit_lock', '1623481697:1'),
(1001, 140, '_wp_attached_file', '2021/06/jawad-pic-croped.jpg'),
(1002, 140, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:130;s:6:\"height\";i:130;s:4:\"file\";s:28:\"2021/06/jawad-pic-croped.jpg\";s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:10:\"1611523455\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}'),
(1003, 140, '_wp_attachment_image_alt', 'Author Two'),
(1004, 138, '_thumbnail_id', '140'),
(1005, 141, '_edit_last', '1'),
(1006, 141, '_edit_lock', '1623481718:1'),
(1007, 141, '_thumbnail_id', '137'),
(1008, 142, '_edit_last', '1'),
(1009, 142, '_edit_lock', '1623481872:1'),
(1010, 142, '_thumbnail_id', '140'),
(1011, 148, '_edit_last', '1'),
(1012, 148, '_edit_lock', '1623481743:1'),
(1013, 136, 'star_rating', '5'),
(1014, 136, '_star_rating', 'field_60c45bb82cdba'),
(1015, 138, 'star_rating', '5'),
(1016, 138, '_star_rating', 'field_60c45bb82cdba'),
(1017, 141, 'star_rating', '4'),
(1018, 141, '_star_rating', 'field_60c45bb82cdba'),
(1019, 142, 'star_rating', '5'),
(1020, 142, '_star_rating', 'field_60c45bb82cdba');

-- --------------------------------------------------------

--
-- Table structure for table `wp_posts`
--

CREATE TABLE `wp_posts` (
  `ID` bigint(20) UNSIGNED NOT NULL,
  `post_author` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_title` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_excerpt` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `to_ping` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `pinged` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_parent` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `guid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT 0,
  `post_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_posts`
--

INSERT INTO `wp_posts` (`ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(1, 1, '2021-06-05 16:18:30', '2021-06-05 16:18:30', '<!-- wp:paragraph -->\n<p>Welcome to WordPress. This is your first post. Edit or delete it, then start writing!</p>\n<!-- /wp:paragraph -->', 'Hello world!', '', 'publish', 'open', 'open', '', 'hello-world', '', '', '2021-06-05 16:18:30', '2021-06-05 16:18:30', '', 0, 'http://localhost/lava/?p=1', 0, 'post', '', 1),
(2, 1, '2021-06-05 16:18:30', '2021-06-05 16:18:30', '<!-- wp:paragraph -->\n<p>This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class=\"wp-block-quote\"><p>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my website. I live in Los Angeles, have a great dog named Jack, and I like pi&#241;a coladas. (And gettin\' caught in the rain.)</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>...or something like this:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class=\"wp-block-quote\"><p>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>As a new WordPress user, you should go to <a href=\"http://localhost/lava/wp-admin/\">your dashboard</a> to delete this page and create new pages for your content. Have fun!</p>\n<!-- /wp:paragraph -->', 'Sample Page', '', 'trash', 'closed', 'open', '', 'sample-page__trashed', '', '', '2021-06-08 04:44:23', '2021-06-08 04:44:23', '', 0, 'http://localhost/lava/?page_id=2', 0, 'page', '', 0),
(3, 1, '2021-06-05 16:18:30', '2021-06-05 16:18:30', '<!-- wp:heading --><h2>Who we are</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>Our website address is: http://localhost/lava.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Comments</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>When visitors leave comments on the site we collect the data shown in the comments form, and also the visitor&#8217;s IP address and browser user agent string to help spam detection.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>An anonymized string created from your email address (also called a hash) may be provided to the Gravatar service to see if you are using it. The Gravatar service privacy policy is available here: https://automattic.com/privacy/. After approval of your comment, your profile picture is visible to the public in the context of your comment.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Media</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>If you upload images to the website, you should avoid uploading images with embedded location data (EXIF GPS) included. Visitors to the website can download and extract any location data from images on the website.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Cookies</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>If you leave a comment on our site you may opt-in to saving your name, email address and website in cookies. These are for your convenience so that you do not have to fill in your details again when you leave another comment. These cookies will last for one year.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>If you visit our login page, we will set a temporary cookie to determine if your browser accepts cookies. This cookie contains no personal data and is discarded when you close your browser.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>When you log in, we will also set up several cookies to save your login information and your screen display choices. Login cookies last for two days, and screen options cookies last for a year. If you select &quot;Remember Me&quot;, your login will persist for two weeks. If you log out of your account, the login cookies will be removed.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>If you edit or publish an article, an additional cookie will be saved in your browser. This cookie includes no personal data and simply indicates the post ID of the article you just edited. It expires after 1 day.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Embedded content from other websites</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>Articles on this site may include embedded content (e.g. videos, images, articles, etc.). Embedded content from other websites behaves in the exact same way as if the visitor has visited the other website.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>These websites may collect data about you, use cookies, embed additional third-party tracking, and monitor your interaction with that embedded content, including tracking your interaction with the embedded content if you have an account and are logged in to that website.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Who we share your data with</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>If you request a password reset, your IP address will be included in the reset email.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>How long we retain your data</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>If you leave a comment, the comment and its metadata are retained indefinitely. This is so we can recognize and approve any follow-up comments automatically instead of holding them in a moderation queue.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>For users that register on our website (if any), we also store the personal information they provide in their user profile. All users can see, edit, or delete their personal information at any time (except they cannot change their username). Website administrators can also see and edit that information.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>What rights you have over your data</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>If you have an account on this site, or have left comments, you can request to receive an exported file of the personal data we hold about you, including any data you have provided to us. You can also request that we erase any personal data we hold about you. This does not include any data we are obliged to keep for administrative, legal, or security purposes.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Where we send your data</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>Visitor comments may be checked through an automated spam detection service.</p><!-- /wp:paragraph -->', 'Privacy Policy', '', 'draft', 'closed', 'open', '', 'privacy-policy', '', '', '2021-06-05 16:18:30', '2021-06-05 16:18:30', '', 0, 'http://localhost/lava/?page_id=3', 0, 'page', '', 0),
(4, 1, '2021-06-05 16:18:58', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2021-06-05 16:18:58', '0000-00-00 00:00:00', '', 0, 'http://localhost/lava/?p=4', 0, 'post', '', 0),
(5, 1, '2021-06-08 04:44:23', '2021-06-08 04:44:23', '<!-- wp:paragraph -->\n<p>This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class=\"wp-block-quote\"><p>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my website. I live in Los Angeles, have a great dog named Jack, and I like pi&#241;a coladas. (And gettin\' caught in the rain.)</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>...or something like this:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class=\"wp-block-quote\"><p>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>As a new WordPress user, you should go to <a href=\"http://localhost/lava/wp-admin/\">your dashboard</a> to delete this page and create new pages for your content. Have fun!</p>\n<!-- /wp:paragraph -->', 'Sample Page', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2021-06-08 04:44:23', '2021-06-08 04:44:23', '', 2, 'http://localhost/lava/?p=5', 0, 'revision', '', 0),
(6, 1, '2021-06-08 04:53:09', '2021-06-08 04:53:09', '', 'Career', '', 'publish', 'closed', 'closed', '', 'career', '', '', '2021-06-08 04:53:09', '2021-06-08 04:53:09', '', 0, 'http://localhost/lava/?page_id=6', 0, 'page', '', 0),
(7, 1, '2021-06-08 04:53:09', '2021-06-08 04:53:09', '', 'Career', '', 'inherit', 'closed', 'closed', '', '6-revision-v1', '', '', '2021-06-08 04:53:09', '2021-06-08 04:53:09', '', 6, 'http://localhost/lava/?p=7', 0, 'revision', '', 0),
(8, 1, '2021-06-08 04:53:29', '2021-06-08 04:53:29', '', 'FAQ\'s', '', 'publish', 'closed', 'closed', '', 'faqs', '', '', '2021-06-08 04:53:29', '2021-06-08 04:53:29', '', 0, 'http://localhost/lava/?page_id=8', 0, 'page', '', 0),
(9, 1, '2021-06-08 04:53:29', '2021-06-08 04:53:29', '', 'FAQ\'s', '', 'inherit', 'closed', 'closed', '', '8-revision-v1', '', '', '2021-06-08 04:53:29', '2021-06-08 04:53:29', '', 8, 'http://localhost/lava/?p=9', 0, 'revision', '', 0),
(10, 1, '2021-06-08 04:53:44', '2021-06-08 04:53:44', '', 'News', '', 'publish', 'closed', 'closed', '', 'news', '', '', '2021-06-08 04:53:44', '2021-06-08 04:53:44', '', 0, 'http://localhost/lava/?page_id=10', 0, 'page', '', 0),
(11, 1, '2021-06-08 04:53:44', '2021-06-08 04:53:44', '', 'News', '', 'inherit', 'closed', 'closed', '', '10-revision-v1', '', '', '2021-06-08 04:53:44', '2021-06-08 04:53:44', '', 10, 'http://localhost/lava/?p=11', 0, 'revision', '', 0),
(12, 1, '2021-06-09 08:20:43', '2021-06-08 04:57:42', '', 'Home', '', 'publish', 'closed', 'closed', '', 'home', '', '', '2021-06-09 08:20:43', '2021-06-09 08:20:43', '', 0, 'http://localhost/lava/?p=12', 1, 'nav_menu_item', '', 0),
(13, 1, '2021-06-09 08:20:43', '2021-06-08 04:57:42', '', 'Services', '', 'publish', 'closed', 'closed', '', 'about', '', '', '2021-06-09 08:20:43', '2021-06-09 08:20:43', '', 0, 'http://localhost/lava/?p=13', 2, 'nav_menu_item', '', 0),
(14, 1, '2021-06-09 08:20:43', '2021-06-08 04:57:42', '', 'Feedback', '', 'publish', 'closed', 'closed', '', 'feedback', '', '', '2021-06-09 08:20:43', '2021-06-09 08:20:43', '', 0, 'http://localhost/lava/?p=14', 4, 'nav_menu_item', '', 0),
(15, 1, '2021-06-09 08:20:43', '2021-06-08 04:57:42', '', 'More', '', 'publish', 'closed', 'closed', '', 'more', '', '', '2021-06-09 08:20:43', '2021-06-09 08:20:43', '', 0, 'http://localhost/lava/?p=15', 5, 'nav_menu_item', '', 0),
(16, 1, '2021-06-09 08:20:43', '2021-06-08 04:57:42', ' ', '', '', 'publish', 'closed', 'closed', '', '16', '', '', '2021-06-09 08:20:43', '2021-06-09 08:20:43', '', 0, 'http://localhost/lava/?p=16', 7, 'nav_menu_item', '', 0),
(17, 1, '2021-06-09 08:20:43', '2021-06-08 04:57:42', '', 'FAQ’s', '', 'publish', 'closed', 'closed', '', 'faqs', '', '', '2021-06-09 08:20:43', '2021-06-09 08:20:43', '', 0, 'http://localhost/lava/?p=17', 6, 'nav_menu_item', '', 0),
(18, 1, '2021-06-09 08:20:43', '2021-06-08 04:57:42', ' ', '', '', 'publish', 'closed', 'closed', '', '18', '', '', '2021-06-09 08:20:43', '2021-06-09 08:20:43', '', 0, 'http://localhost/lava/?p=18', 8, 'nav_menu_item', '', 0),
(19, 1, '2021-06-08 05:41:53', '2021-06-08 05:41:53', '', 'Contact Us', '', 'trash', 'closed', 'closed', '', 'contact-us__trashed', '', '', '2021-06-08 05:43:17', '2021-06-08 05:43:17', '', 0, 'http://localhost/lava/?page_id=19', 0, 'page', '', 0),
(20, 1, '2021-06-08 05:41:53', '2021-06-08 05:41:53', '', 'Contact Us', '', 'inherit', 'closed', 'closed', '', '19-revision-v1', '', '', '2021-06-08 05:41:53', '2021-06-08 05:41:53', '', 19, 'http://localhost/lava/?p=20', 0, 'revision', '', 0),
(21, 1, '2021-06-08 05:42:03', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2021-06-08 05:42:03', '0000-00-00 00:00:00', '', 0, 'http://localhost/lava/?p=21', 1, 'nav_menu_item', '', 0),
(22, 1, '2021-06-08 05:43:06', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2021-06-08 05:43:06', '0000-00-00 00:00:00', '', 0, 'http://localhost/lava/?p=22', 1, 'nav_menu_item', '', 0),
(23, 1, '2021-06-09 08:20:43', '2021-06-08 05:43:39', '', 'Contact Us', '', 'publish', 'closed', 'closed', '', 'contact-us', '', '', '2021-06-09 08:20:43', '2021-06-09 08:20:43', '', 0, 'http://localhost/lava/?p=23', 9, 'nav_menu_item', '', 0),
(24, 1, '2021-06-08 05:49:01', '2021-06-08 05:49:01', '{\n    \"custom_css[lava]\": {\n        \"value\": \".footer-content .right-content a {\\n    padding-top: 13px;\\n}\",\n        \"type\": \"custom_css\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-06-08 05:49:01\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', '655eff45-8c25-46c1-9ae6-af9c949c3976', '', '', '2021-06-08 05:49:01', '2021-06-08 05:49:01', '', 0, 'http://localhost/lava/2021/06/08/655eff45-8c25-46c1-9ae6-af9c949c3976/', 0, 'customize_changeset', '', 0),
(25, 1, '2021-06-08 05:49:01', '2021-06-08 05:49:01', '', 'lava', '', 'publish', 'closed', 'closed', '', 'lava', '', '', '2021-06-10 07:54:02', '2021-06-10 07:54:02', '', 0, 'http://localhost/lava/2021/06/08/lava/', 0, 'custom_css', '', 0),
(26, 1, '2021-06-08 05:49:01', '2021-06-08 05:49:01', '.footer-content .right-content a {\n    padding-top: 13px;\n}', 'lava', '', 'inherit', 'closed', 'closed', '', '25-revision-v1', '', '', '2021-06-08 05:49:01', '2021-06-08 05:49:01', '', 25, 'http://localhost/lava/?p=26', 0, 'revision', '', 0),
(27, 1, '2021-06-08 06:05:22', '2021-06-08 06:05:22', '{\n    \"custom_js\": {\n        \"value\": \"$( document ).ready(function() {\\n    console.log( \\\"ready!\\\" );\\n});\",\n        \"type\": \"option\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-06-08 06:05:22\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', '51c930c9-b9cb-43a8-918c-71a768f8c0ab', '', '', '2021-06-08 06:05:22', '2021-06-08 06:05:22', '', 0, 'http://localhost/lava/?p=27', 0, 'customize_changeset', '', 0),
(28, 1, '2021-06-08 06:38:24', '2021-06-08 06:38:24', '<label> Your name\r\n    [text* your-name] </label>\r\n\r\n<label> Your email\r\n    [email* your-email] </label>\r\n\r\n<label> Subject\r\n    [text* your-subject] </label>\r\n\r\n<label> Your message (optional)\r\n    [textarea your-message] </label>\r\n\r\n[submit \"Submit\"]\n1\n[_site_title] \"[your-subject]\"\n[_site_title] <bilal.asghar.chuadhary@gmail.com>\n[_site_admin_email]\nFrom: [your-name] <[your-email]>\r\nSubject: [your-subject]\r\n\r\nMessage Body:\r\n[your-message]\r\n\r\n-- \r\nThis e-mail was sent from a contact form on [_site_title] ([_site_url])\nReply-To: [your-email]\n\n\n\n\n[_site_title] \"[your-subject]\"\n[_site_title] <bilal.asghar.chuadhary@gmail.com>\n[your-email]\nMessage Body:\r\n[your-message]\r\n\r\n-- \r\nThis e-mail was sent from a contact form on [_site_title] ([_site_url])\nReply-To: [_site_admin_email]\n\n\n\nThank you for your message. It has been sent.\nThere was an error trying to send your message. Please try again later.\nOne or more fields have an error. Please check and try again.\nThere was an error trying to send your message. Please try again later.\nYou must accept the terms and conditions before sending your message.\nThe field is required.\nThe field is too long.\nThe field is too short.\nThere was an unknown error uploading the file.\nYou are not allowed to upload files of this type.\nThe file is too big.\nThere was an error uploading the file.\nThe date format is incorrect.\nThe date is before the earliest one allowed.\nThe date is after the latest one allowed.\nThe number format is invalid.\nThe number is smaller than the minimum allowed.\nThe number is larger than the maximum allowed.\nThe answer to the quiz is incorrect.\nThe e-mail address entered is invalid.\nThe URL is invalid.\nThe telephone number is invalid.', 'Contact form 1', '', 'publish', 'closed', 'closed', '', 'contact-form-1', '', '', '2021-06-09 06:08:10', '2021-06-09 06:08:10', '', 0, 'http://localhost/lava/?post_type=wpcf7_contact_form&#038;p=28', 0, 'wpcf7_contact_form', '', 0),
(30, 1, '2021-06-08 07:20:10', '2021-06-08 07:20:10', '{\n    \"lava::custom_logo\": {\n        \"value\": 29,\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-06-08 07:20:10\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', '71f4731c-c6e2-4bf0-a22b-896052a3ee48', '', '', '2021-06-08 07:20:10', '2021-06-08 07:20:10', '', 0, 'http://localhost/lava/2021/06/08/71f4731c-c6e2-4bf0-a22b-896052a3ee48/', 0, 'customize_changeset', '', 0),
(31, 1, '2021-06-08 07:24:13', '2021-06-08 07:24:13', '{\n    \"lava::custom_logo\": {\n        \"value\": 29,\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-06-08 07:24:13\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', '3f8e7a58-f0ac-4e03-9942-dcceed3baee1', '', '', '2021-06-08 07:24:13', '2021-06-08 07:24:13', '', 0, 'http://localhost/lava/2021/06/08/3f8e7a58-f0ac-4e03-9942-dcceed3baee1/', 0, 'customize_changeset', '', 0),
(32, 1, '2021-06-08 07:32:12', '2021-06-08 07:32:12', '', 'systemzones', '', 'inherit', 'open', 'closed', '', 'systemzones-resized-removebg-preview', '', '', '2021-06-08 07:32:31', '2021-06-08 07:32:31', '', 0, 'http://localhost/lava/wp-content/uploads/2021/06/systemzones-resized-removebg-preview.png', 0, 'attachment', 'image/png', 0),
(33, 1, '2021-06-08 07:32:39', '2021-06-08 07:32:39', '{\n    \"lava::custom_logo\": {\n        \"value\": 32,\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-06-08 07:32:39\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', '5afb8404-813b-4d3d-98cb-52e70f8aa37e', '', '', '2021-06-08 07:32:39', '2021-06-08 07:32:39', '', 0, 'http://localhost/lava/?p=33', 0, 'customize_changeset', '', 0),
(34, 1, '2021-06-08 07:33:40', '2021-06-08 07:33:40', '{\n    \"custom_css[lava]\": {\n        \"value\": \"/* .footer-content .right-content a {\\n    padding-top: 13px;\\n} */\\n\\nnav.main-nav img {\\n    float: left;\\n}\",\n        \"type\": \"custom_css\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-06-08 07:33:40\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', 'be17fa5e-3638-4579-ab50-93d8d34546c1', '', '', '2021-06-08 07:33:40', '2021-06-08 07:33:40', '', 0, 'http://localhost/lava/?p=34', 0, 'customize_changeset', '', 0),
(35, 1, '2021-06-08 07:33:40', '2021-06-08 07:33:40', '/* .footer-content .right-content a {\n    padding-top: 13px;\n} */\n\nnav.main-nav img {\n    float: left;\n}', 'lava', '', 'inherit', 'closed', 'closed', '', '25-revision-v1', '', '', '2021-06-08 07:33:40', '2021-06-08 07:33:40', '', 25, 'http://localhost/lava/?p=35', 0, 'revision', '', 0),
(36, 1, '2021-06-08 07:34:22', '2021-06-08 07:34:22', '{\n    \"custom_css[lava]\": {\n        \"value\": \"/* .footer-content .right-content a {\\n    padding-top: 13px;\\n} */\\n\\nnav.main-nav img {\\n    float: left;\\n\\tmargin-top: 10px;\\n}\",\n        \"type\": \"custom_css\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-06-08 07:34:22\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', 'd4e97ed2-73a1-4d2b-bbf8-c8366f2723e9', '', '', '2021-06-08 07:34:22', '2021-06-08 07:34:22', '', 0, 'http://localhost/lava/2021/06/08/d4e97ed2-73a1-4d2b-bbf8-c8366f2723e9/', 0, 'customize_changeset', '', 0),
(37, 1, '2021-06-08 07:34:22', '2021-06-08 07:34:22', '/* .footer-content .right-content a {\n    padding-top: 13px;\n} */\n\nnav.main-nav img {\n    float: left;\n	margin-top: 10px;\n}', 'lava', '', 'inherit', 'closed', 'closed', '', '25-revision-v1', '', '', '2021-06-08 07:34:22', '2021-06-08 07:34:22', '', 25, 'http://localhost/lava/?p=37', 0, 'revision', '', 0),
(38, 1, '2021-06-08 07:36:23', '2021-06-08 07:36:23', '{\n    \"custom_css[lava]\": {\n        \"value\": \"/* .footer-content .right-content a {\\n    padding-top: 13px;\\n} */\\n\\nnav.main-nav img {\\n    float: left;\\n}\\n\\nnav.main-nav {\\n    margin-top: 10px;\\n}\",\n        \"type\": \"custom_css\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-06-08 07:36:23\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', '4111fa61-193f-42ac-8693-42c8de523baf', '', '', '2021-06-08 07:36:23', '2021-06-08 07:36:23', '', 0, 'http://localhost/lava/?p=38', 0, 'customize_changeset', '', 0),
(39, 1, '2021-06-08 07:36:23', '2021-06-08 07:36:23', '/* .footer-content .right-content a {\n    padding-top: 13px;\n} */\n\nnav.main-nav img {\n    float: left;\n}\n\nnav.main-nav {\n    margin-top: 10px;\n}', 'lava', '', 'inherit', 'closed', 'closed', '', '25-revision-v1', '', '', '2021-06-08 07:36:23', '2021-06-08 07:36:23', '', 25, 'http://localhost/lava/?p=39', 0, 'revision', '', 0),
(40, 1, '2021-06-08 07:42:23', '2021-06-08 07:42:23', '{\n    \"custom_css[lava]\": {\n        \"value\": \"/* .footer-content .right-content a {\\n    padding-top: 13px;\\n} */\\n/* \\nnav.main-nav img {\\n    float: left;\\n} */\\n\\nnav.main-nav {\\n    margin-top: 10px;\\n}\",\n        \"type\": \"custom_css\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-06-08 07:42:23\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', '4885e8b6-a9be-4900-9a03-2e76e28a6fd7', '', '', '2021-06-08 07:42:23', '2021-06-08 07:42:23', '', 0, 'http://localhost/lava/2021/06/08/4885e8b6-a9be-4900-9a03-2e76e28a6fd7/', 0, 'customize_changeset', '', 0),
(41, 1, '2021-06-08 07:42:23', '2021-06-08 07:42:23', '/* .footer-content .right-content a {\n    padding-top: 13px;\n} */\n/* \nnav.main-nav img {\n    float: left;\n} */\n\nnav.main-nav {\n    margin-top: 10px;\n}', 'lava', '', 'inherit', 'closed', 'closed', '', '25-revision-v1', '', '', '2021-06-08 07:42:23', '2021-06-08 07:42:23', '', 25, 'http://localhost/lava/?p=41', 0, 'revision', '', 0),
(42, 1, '2021-06-08 07:46:42', '2021-06-08 07:46:42', '{\n    \"custom_css[lava]\": {\n        \"value\": \"/* .footer-content .right-content a {\\n    padding-top: 13px;\\n} */\\n/* \\nnav.main-nav img {\\n    float: left;\\n} */\\n\\n/* nav.main-nav {\\n    margin-top: 10px;\\n} */\",\n        \"type\": \"custom_css\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-06-08 07:46:42\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', '156357dd-b0c5-4d8c-95dc-ea1031caf142', '', '', '2021-06-08 07:46:42', '2021-06-08 07:46:42', '', 0, 'http://localhost/lava/2021/06/08/156357dd-b0c5-4d8c-95dc-ea1031caf142/', 0, 'customize_changeset', '', 0),
(43, 1, '2021-06-08 07:46:42', '2021-06-08 07:46:42', '/* .footer-content .right-content a {\n    padding-top: 13px;\n} */\n/* \nnav.main-nav img {\n    float: left;\n} */\n\n/* nav.main-nav {\n    margin-top: 10px;\n} */', 'lava', '', 'inherit', 'closed', 'closed', '', '25-revision-v1', '', '', '2021-06-08 07:46:42', '2021-06-08 07:46:42', '', 25, 'http://localhost/lava/?p=43', 0, 'revision', '', 0),
(44, 1, '2021-06-08 07:48:57', '2021-06-08 07:48:57', '{\n    \"custom_css[lava]\": {\n        \"value\": \"/* .footer-content .right-content a {\\n    padding-top: 13px;\\n} */\\n \\nnav.main-nav img {\\n    float: left;\\n}\\n\\n/* nav.main-nav {\\n    margin-top: 10px;\\n} */\",\n        \"type\": \"custom_css\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-06-08 07:48:57\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', 'd20f068f-a889-4632-8338-e05fe7845553', '', '', '2021-06-08 07:48:57', '2021-06-08 07:48:57', '', 0, 'http://localhost/lava/2021/06/08/d20f068f-a889-4632-8338-e05fe7845553/', 0, 'customize_changeset', '', 0),
(45, 1, '2021-06-08 07:48:58', '2021-06-08 07:48:58', '/* .footer-content .right-content a {\n    padding-top: 13px;\n} */\n \nnav.main-nav img {\n    float: left;\n}\n\n/* nav.main-nav {\n    margin-top: 10px;\n} */', 'lava', '', 'inherit', 'closed', 'closed', '', '25-revision-v1', '', '', '2021-06-08 07:48:58', '2021-06-08 07:48:58', '', 25, 'http://localhost/lava/?p=45', 0, 'revision', '', 0),
(46, 1, '2021-06-08 07:49:34', '2021-06-08 07:49:34', '{\n    \"custom_css[lava]\": {\n        \"value\": \"/* .footer-content .right-content a {\\n    padding-top: 13px;\\n} */\\n \\n nav.main-nav {\\n    margin-top: 10px;\\n}\",\n        \"type\": \"custom_css\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-06-08 07:49:34\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', '0d28c6ab-0003-4fda-9648-bb232627ab37', '', '', '2021-06-08 07:49:34', '2021-06-08 07:49:34', '', 0, 'http://localhost/lava/2021/06/08/0d28c6ab-0003-4fda-9648-bb232627ab37/', 0, 'customize_changeset', '', 0),
(47, 1, '2021-06-08 07:49:34', '2021-06-08 07:49:34', '/* .footer-content .right-content a {\n    padding-top: 13px;\n} */\n \n nav.main-nav {\n    margin-top: 10px;\n}', 'lava', '', 'inherit', 'closed', 'closed', '', '25-revision-v1', '', '', '2021-06-08 07:49:34', '2021-06-08 07:49:34', '', 25, 'http://localhost/lava/?p=47', 0, 'revision', '', 0),
(48, 1, '2021-06-08 07:50:24', '2021-06-08 07:50:24', '{\n    \"custom_css[lava]\": {\n        \"value\": \"/* .footer-content .right-content a {\\n    padding-top: 13px;\\n} */\\n \\n\",\n        \"type\": \"custom_css\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-06-08 07:50:24\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', '66904bff-5f62-427a-9386-3d54af267077', '', '', '2021-06-08 07:50:24', '2021-06-08 07:50:24', '', 0, 'http://localhost/lava/2021/06/08/66904bff-5f62-427a-9386-3d54af267077/', 0, 'customize_changeset', '', 0),
(49, 1, '2021-06-08 07:50:24', '2021-06-08 07:50:24', '/* .footer-content .right-content a {\n    padding-top: 13px;\n} */\n \n', 'lava', '', 'inherit', 'closed', 'closed', '', '25-revision-v1', '', '', '2021-06-08 07:50:24', '2021-06-08 07:50:24', '', 25, 'http://localhost/lava/?p=49', 0, 'revision', '', 0),
(50, 1, '2021-06-08 07:53:01', '2021-06-08 07:53:01', '{\n    \"custom_css[lava]\": {\n        \"value\": \"/* .footer-content .right-content a {\\n    padding-top: 13px;\\n} */\\n \\n \",\n        \"type\": \"custom_css\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-06-08 07:51:08\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', '2b57b433-fbac-441b-a4bb-14c37f2d3303', '', '', '2021-06-08 07:53:01', '2021-06-08 07:53:01', '', 0, 'http://localhost/lava/?p=50', 0, 'customize_changeset', '', 0),
(51, 1, '2021-06-08 07:56:09', '2021-06-08 07:56:09', '{\n    \"custom_css[lava]\": {\n        \"value\": \"/* .footer-content .right-content a {\\n    padding-top: 13px;\\n} */\\n \\n ul#menu-header-menu {\\n    float: right;\\n    position: relative;\\n    top: -57px;\\n}\",\n        \"type\": \"custom_css\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-06-08 07:56:09\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', '8eae1cbd-aba4-499e-b296-07207a5a9cfd', '', '', '2021-06-08 07:56:09', '2021-06-08 07:56:09', '', 0, 'http://localhost/lava/2021/06/08/8eae1cbd-aba4-499e-b296-07207a5a9cfd/', 0, 'customize_changeset', '', 0),
(52, 1, '2021-06-08 07:56:09', '2021-06-08 07:56:09', '/* .footer-content .right-content a {\n    padding-top: 13px;\n} */\n \n ul#menu-header-menu {\n    float: right;\n    position: relative;\n    top: -57px;\n}', 'lava', '', 'inherit', 'closed', 'closed', '', '25-revision-v1', '', '', '2021-06-08 07:56:09', '2021-06-08 07:56:09', '', 25, 'http://localhost/lava/?p=52', 0, 'revision', '', 0),
(53, 1, '2021-06-08 08:00:17', '2021-06-08 08:00:17', '{\n    \"custom_css[lava]\": {\n        \"value\": \"/* .footer-content .right-content a {\\n    padding-top: 13px;\\n} */\\n \\n ul#menu-header-menu {\\n    float: right;\\n    position: relative;\\n    top: -68px;\\n}\",\n        \"type\": \"custom_css\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-06-08 08:00:17\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', '6f6f7926-8091-4e26-94a4-680a36dedd7e', '', '', '2021-06-08 08:00:17', '2021-06-08 08:00:17', '', 0, 'http://localhost/lava/2021/06/08/6f6f7926-8091-4e26-94a4-680a36dedd7e/', 0, 'customize_changeset', '', 0),
(54, 1, '2021-06-08 08:00:17', '2021-06-08 08:00:17', '/* .footer-content .right-content a {\n    padding-top: 13px;\n} */\n \n ul#menu-header-menu {\n    float: right;\n    position: relative;\n    top: -68px;\n}', 'lava', '', 'inherit', 'closed', 'closed', '', '25-revision-v1', '', '', '2021-06-08 08:00:17', '2021-06-08 08:00:17', '', 25, 'http://localhost/lava/?p=54', 0, 'revision', '', 0),
(55, 1, '2021-06-08 08:01:42', '2021-06-08 08:01:42', '{\n    \"custom_css[lava]\": {\n        \"value\": \"/* .footer-content .right-content a {\\n    padding-top: 13px;\\n} */\\n \\n ul#menu-header-menu {\\n    float: right;\\n    position: relative;\\n    top: -68px;\\n}\\n.header-area .main-nav {\\n\\tmargin-top: 10px;\\n}\",\n        \"type\": \"custom_css\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-06-08 08:01:41\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', 'c20df723-bd65-4551-92ee-200cb7d7087f', '', '', '2021-06-08 08:01:42', '2021-06-08 08:01:42', '', 0, 'http://localhost/lava/?p=55', 0, 'customize_changeset', '', 0),
(56, 1, '2021-06-08 08:01:42', '2021-06-08 08:01:42', '/* .footer-content .right-content a {\n    padding-top: 13px;\n} */\n \n ul#menu-header-menu {\n    float: right;\n    position: relative;\n    top: -68px;\n}\n.header-area .main-nav {\n	margin-top: 10px;\n}', 'lava', '', 'inherit', 'closed', 'closed', '', '25-revision-v1', '', '', '2021-06-08 08:01:42', '2021-06-08 08:01:42', '', 25, 'http://localhost/lava/?p=56', 0, 'revision', '', 0),
(57, 1, '2021-06-08 08:15:24', '2021-06-08 08:15:24', '<div class=\"row\">\r\n	<div class=\"col-md-6 col-sm-12\">\r\n		<fieldset>\r\n			[text* your-name id:name placeholder \"Full Name\"]\r\n		</fieldset>\r\n	</div>\r\n	<div class=\"col-md-6 col-sm-12\">\r\n		<fieldset>\r\n			[email* email id:email placeholder \"E-Mail Address\"]\r\n		</fieldset>\r\n	</div>\r\n	<div class=\"col-lg-12\">\r\n		<fieldset>\r\n			[textarea* message id:message placeholder \"Your Message\"]\r\n		</fieldset>\r\n	</div>\r\n	<div class=\"col-lg-12\">\r\n		<fieldset>\r\n			[submit id:form-submit class:main-button \"Send Message\"]\r\n		</fieldset>\r\n	</div>\r\n</div>\n1\nMessage  from systemzones.com\nbilal@truishop.com\nbilal@truishop.com\nFrom: [your-name]\r\nEmail Address: [email]\r\n\r\nMessage Body:\r\n[message]\r\n\r\n-- \r\nThis e-mail was sent from a contact form on [_site_title] ([_site_url])\nReply-To: [email]\n\n\n\n\n[_site_title] \"[your-subject]\"\n[_site_title] <bilal.asghar.chuadhary@gmail.com>\n[your-email]\nMessage Body:\r\n[your-message]\r\n\r\n-- \r\nThis e-mail was sent from a contact form on [_site_title] ([_site_url])\nReply-To: [_site_admin_email]\n\n\n\nThank you for your message. It has been sent.\nThere was an error trying to send your message. Please try again later.\nOne or more fields have an error. Please check and try again.\nThere was an error trying to send your message. Please try again later.\nYou must accept the terms and conditions before sending your message.\nThe field is required.\nThe field is too long.\nThe field is too short.\nThere was an unknown error uploading the file.\nYou are not allowed to upload files of this type.\nThe file is too big.\nThere was an error uploading the file.\nThe date format is incorrect.\nThe date is before the earliest one allowed.\nThe date is after the latest one allowed.\nThe number format is invalid.\nThe number is smaller than the minimum allowed.\nThe number is larger than the maximum allowed.\nThe answer to the quiz is incorrect.\nThe e-mail address entered is invalid.\nThe URL is invalid.\nThe telephone number is invalid.', 'Contact to system', '', 'publish', 'closed', 'closed', '', 'contact-to-system', '', '', '2021-06-09 04:46:22', '2021-06-09 04:46:22', '', 0, 'http://localhost/lava/?post_type=wpcf7_contact_form&#038;p=57', 0, 'wpcf7_contact_form', '', 0),
(58, 1, '2021-06-09 06:13:35', '2021-06-09 06:13:35', 'a:7:{s:8:\"location\";a:1:{i:0;a:1:{i:0;a:3:{s:5:\"param\";s:13:\"page_template\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:20:\"template.landing.php\";}}}s:8:\"position\";s:6:\"normal\";s:5:\"style\";s:7:\"default\";s:15:\"label_placement\";s:3:\"top\";s:21:\"instruction_placement\";s:5:\"label\";s:14:\"hide_on_screen\";s:0:\"\";s:11:\"description\";s:0:\"\";}', 'Landing Page', 'landing-page', 'publish', 'closed', 'closed', '', 'group_60c0579231568', '', '', '2021-06-11 08:42:44', '2021-06-11 08:42:44', '', 0, 'http://localhost/lava/?post_type=acf-field-group&#038;p=58', 0, 'acf-field-group', '', 0),
(59, 1, '2021-06-09 06:13:35', '2021-06-09 06:13:35', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'banner heading', 'banner_heading', 'publish', 'closed', 'closed', '', 'field_60c05b5904cde', '', '', '2021-06-09 06:35:34', '2021-06-09 06:35:34', '', 58, 'http://localhost/lava/?post_type=acf-field&#038;p=59', 0, 'acf-field', '', 0),
(60, 1, '2021-06-09 06:27:00', '2021-06-09 06:27:00', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'banner heading em', 'banner_heading_em', 'publish', 'closed', 'closed', '', 'field_60c05c144cc3d', '', '', '2021-06-09 06:27:00', '2021-06-09 06:27:00', '', 58, 'http://localhost/lava/?post_type=acf-field&p=60', 1, 'acf-field', '', 0),
(61, 1, '2021-06-09 06:27:00', '2021-06-09 06:27:00', 'a:10:{s:4:\"type\";s:8:\"textarea\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";s:4:\"rows\";s:0:\"\";s:9:\"new_lines\";s:0:\"\";}', 'banner desc', 'banner_desc', 'publish', 'closed', 'closed', '', 'field_60c05c384cc3e', '', '', '2021-06-10 06:37:34', '2021-06-10 06:37:34', '', 58, 'http://localhost/lava/?post_type=acf-field&#038;p=61', 2, 'acf-field', '', 0),
(62, 1, '2021-06-09 06:27:00', '2021-06-09 06:27:00', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'banner btn link id', 'banner_btn_link_id', 'publish', 'closed', 'closed', '', 'field_60c05c6a4cc3f', '', '', '2021-06-09 06:32:25', '2021-06-09 06:32:25', '', 58, 'http://localhost/lava/?post_type=acf-field&#038;p=62', 3, 'acf-field', '', 0),
(63, 1, '2021-06-09 06:29:28', '2021-06-09 06:29:28', '', 'LandingPage', '', 'publish', 'closed', 'closed', '', 'landingpage', '', '', '2021-06-11 08:45:40', '2021-06-11 08:45:40', '', 0, 'http://localhost/lava/?page_id=63', 0, 'page', '', 0),
(64, 1, '2021-06-09 06:29:28', '2021-06-09 06:29:28', '', 'LandingPage', '', 'inherit', 'closed', 'closed', '', '63-revision-v1', '', '', '2021-06-09 06:29:28', '2021-06-09 06:29:28', '', 63, 'http://localhost/lava/?p=64', 0, 'revision', '', 0),
(65, 1, '2021-06-09 06:31:55', '2021-06-09 06:31:55', '', 'LandingPage', '', 'inherit', 'closed', 'closed', '', '63-revision-v1', '', '', '2021-06-09 06:31:55', '2021-06-09 06:31:55', '', 63, 'http://localhost/lava/?p=65', 0, 'revision', '', 0),
(66, 1, '2021-06-09 06:32:40', '2021-06-09 06:32:40', '', 'LandingPage', '', 'inherit', 'closed', 'closed', '', '63-revision-v1', '', '', '2021-06-09 06:32:40', '2021-06-09 06:32:40', '', 63, 'http://localhost/lava/?p=66', 0, 'revision', '', 0),
(67, 1, '2021-06-09 06:48:02', '2021-06-09 06:48:02', '', 'LandingPage', '', 'inherit', 'closed', 'closed', '', '63-revision-v1', '', '', '2021-06-09 06:48:02', '2021-06-09 06:48:02', '', 63, 'http://localhost/lava/?p=67', 0, 'revision', '', 0),
(68, 1, '2021-06-09 06:50:43', '2021-06-09 06:50:43', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'banner btn text', 'banner_btn_text', 'publish', 'closed', 'closed', '', 'field_60c064b2c2acc', '', '', '2021-06-09 06:50:43', '2021-06-09 06:50:43', '', 58, 'http://localhost/lava/?post_type=acf-field&p=68', 4, 'acf-field', '', 0),
(69, 1, '2021-06-09 06:51:11', '2021-06-09 06:51:11', '', 'LandingPage', '', 'inherit', 'closed', 'closed', '', '63-revision-v1', '', '', '2021-06-09 06:51:11', '2021-06-09 06:51:11', '', 63, 'http://localhost/lava/?p=69', 0, 'revision', '', 0),
(70, 1, '2021-06-09 08:20:43', '2021-06-09 08:20:43', '', 'Promotions', '', 'publish', 'closed', 'closed', '', 'promotions', '', '', '2021-06-09 08:20:43', '2021-06-09 08:20:43', '', 0, 'http://localhost/lava/?p=70', 3, 'nav_menu_item', '', 0),
(71, 1, '2021-06-10 06:37:34', '2021-06-10 06:37:34', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'testimonial main title', 'testimonial_main_title', 'publish', 'closed', 'closed', '', 'field_60c1b2e56eb06', '', '', '2021-06-11 06:39:13', '2021-06-11 06:39:13', '', 58, 'http://localhost/lava/?post_type=acf-field&#038;p=71', 5, 'acf-field', '', 0),
(72, 1, '2021-06-10 07:52:12', '2021-06-10 07:52:12', '{\n    \"custom_css[lava]\": {\n        \"value\": \"/* .footer-content .right-content a {\\n    padding-top: 13px;\\n} */\\n \\n ul#menu-header-menu {\\n    float: right;\\n    position: relative;\\n    top: -74px;\\n}\\n.header-area .main-nav {\\n\\tpadding-top: 10px;\\n}\",\n        \"type\": \"custom_css\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-06-10 07:52:12\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', 'e9d9954f-bc9e-49aa-9517-57bf16397566', '', '', '2021-06-10 07:52:12', '2021-06-10 07:52:12', '', 0, 'http://localhost/lava/2021/06/10/e9d9954f-bc9e-49aa-9517-57bf16397566/', 0, 'customize_changeset', '', 0),
(73, 1, '2021-06-10 07:52:12', '2021-06-10 07:52:12', '/* .footer-content .right-content a {\n    padding-top: 13px;\n} */\n \n ul#menu-header-menu {\n    float: right;\n    position: relative;\n    top: -74px;\n}\n.header-area .main-nav {\n	padding-top: 10px;\n}', 'lava', '', 'inherit', 'closed', 'closed', '', '25-revision-v1', '', '', '2021-06-10 07:52:12', '2021-06-10 07:52:12', '', 25, 'http://localhost/lava/?p=73', 0, 'revision', '', 0),
(74, 1, '2021-06-10 07:54:02', '2021-06-10 07:54:02', '{\n    \"custom_css[lava]\": {\n        \"value\": \"\",\n        \"type\": \"custom_css\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-06-10 07:54:02\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', '830581dc-9f6f-411c-a9e8-65fdd209edd1', '', '', '2021-06-10 07:54:02', '2021-06-10 07:54:02', '', 0, 'http://localhost/lava/?p=74', 0, 'customize_changeset', '', 0),
(75, 1, '2021-06-10 07:54:02', '2021-06-10 07:54:02', '', 'lava', '', 'inherit', 'closed', 'closed', '', '25-revision-v1', '', '', '2021-06-10 07:54:02', '2021-06-10 07:54:02', '', 25, 'http://localhost/lava/?p=75', 0, 'revision', '', 0),
(76, 1, '2021-06-11 04:28:19', '2021-06-11 04:28:19', 'a:7:{s:8:\"location\";a:1:{i:0;a:1:{i:0;a:3:{s:5:\"param\";s:9:\"post_type\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:7:\"service\";}}}s:8:\"position\";s:6:\"normal\";s:5:\"style\";s:7:\"default\";s:15:\"label_placement\";s:3:\"top\";s:21:\"instruction_placement\";s:5:\"label\";s:14:\"hide_on_screen\";s:0:\"\";s:11:\"description\";s:0:\"\";}', 'CPT Services', 'cpt-services', 'publish', 'closed', 'closed', '', 'group_60c2e48e60192', '', '', '2021-06-11 04:28:19', '2021-06-11 04:28:19', '', 0, 'http://localhost/lava/?post_type=acf-field-group&#038;p=76', 0, 'acf-field-group', '', 0),
(77, 1, '2021-06-11 04:28:19', '2021-06-11 04:28:19', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'service no', 'service_no', 'publish', 'closed', 'closed', '', 'field_60c2e4a00b61a', '', '', '2021-06-11 04:28:19', '2021-06-11 04:28:19', '', 76, 'http://localhost/lava/?post_type=acf-field&p=77', 0, 'acf-field', '', 0),
(78, 1, '2021-06-11 04:28:19', '2021-06-11 04:28:19', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'service icon', 'service_icon', 'publish', 'closed', 'closed', '', 'field_60c2e61e0b61b', '', '', '2021-06-11 04:28:19', '2021-06-11 04:28:19', '', 76, 'http://localhost/lava/?post_type=acf-field&p=78', 1, 'acf-field', '', 0),
(79, 1, '2021-06-11 04:28:19', '2021-06-11 04:28:19', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'service title', 'service_title', 'publish', 'closed', 'closed', '', 'field_60c2e62d0b61c', '', '', '2021-06-11 04:28:19', '2021-06-11 04:28:19', '', 76, 'http://localhost/lava/?post_type=acf-field&p=79', 2, 'acf-field', '', 0),
(80, 1, '2021-06-11 04:28:19', '2021-06-11 04:28:19', 'a:10:{s:4:\"type\";s:8:\"textarea\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";s:4:\"rows\";s:0:\"\";s:9:\"new_lines\";s:0:\"\";}', 'service desc', 'service_desc', 'publish', 'closed', 'closed', '', 'field_60c2e63f0b61d', '', '', '2021-06-11 04:28:19', '2021-06-11 04:28:19', '', 76, 'http://localhost/lava/?post_type=acf-field&p=80', 3, 'acf-field', '', 0),
(81, 1, '2021-06-11 04:28:19', '2021-06-11 04:28:19', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'service btn text', 'service_btn_text', 'publish', 'closed', 'closed', '', 'field_60c2e6500b61e', '', '', '2021-06-11 04:28:19', '2021-06-11 04:28:19', '', 76, 'http://localhost/lava/?post_type=acf-field&p=81', 4, 'acf-field', '', 0),
(82, 1, '2021-06-11 04:32:51', '2021-06-11 04:32:51', '', 'Service one', '', 'publish', 'open', 'closed', '', '82', '', '', '2021-06-11 05:18:25', '2021-06-11 05:18:25', '', 0, 'http://localhost/lava/?post_type=service&#038;p=82', 0, 'service', '', 0),
(83, 1, '2021-06-11 05:19:47', '2021-06-11 05:19:47', '', 'Service two', '', 'publish', 'open', 'closed', '', 'service-two', '', '', '2021-06-11 05:19:47', '2021-06-11 05:19:47', '', 0, 'http://localhost/lava/?post_type=service&#038;p=83', 0, 'service', '', 0),
(84, 1, '2021-06-11 05:22:15', '2021-06-11 05:22:15', '', 'Service three', '', 'publish', 'open', 'closed', '', 'service-three', '', '', '2021-06-11 05:22:15', '2021-06-11 05:22:15', '', 0, 'http://localhost/lava/?post_type=service&#038;p=84', 0, 'service', '', 0),
(85, 1, '2021-06-11 05:23:29', '2021-06-11 05:23:29', '', 'Service four', '', 'publish', 'open', 'closed', '', 'service-four', '', '', '2021-06-11 05:23:29', '2021-06-11 05:23:29', '', 0, 'http://localhost/lava/?post_type=service&#038;p=85', 0, 'service', '', 0),
(86, 1, '2021-06-11 05:23:30', '2021-06-11 05:23:30', '', 'Service four', '', 'inherit', 'closed', 'closed', '', '85-autosave-v1', '', '', '2021-06-11 05:23:30', '2021-06-11 05:23:30', '', 85, 'http://localhost/lava/?p=86', 0, 'revision', '', 0),
(87, 1, '2021-06-11 05:24:32', '2021-06-11 05:24:32', '', 'Service five', '', 'publish', 'open', 'closed', '', 'service-five', '', '', '2021-06-11 05:24:32', '2021-06-11 05:24:32', '', 0, 'http://localhost/lava/?post_type=service&#038;p=87', 0, 'service', '', 0),
(88, 1, '2021-06-11 05:26:04', '2021-06-11 05:26:04', '', 'Service six', '', 'publish', 'open', 'closed', '', 'service-six', '', '', '2021-06-11 05:28:54', '2021-06-11 05:28:54', '', 0, 'http://localhost/lava/?post_type=service&#038;p=88', 0, 'service', '', 0),
(89, 1, '2021-06-11 05:55:06', '2021-06-11 05:55:06', 'Please do not redistribute this template ZIP file for a download purpose. You may contact us for additional licensing of our template or to get a PSD file.', 'Vestibulum pulvinar rhoncus', '', 'publish', 'open', 'closed', '', 'vestibulum-pulvinar-rhoncus', '', '', '2021-06-11 05:55:26', '2021-06-11 05:55:26', '', 0, 'http://localhost/lava/?post_type=promotion&#038;p=89', 0, 'promotion', '', 0),
(90, 1, '2021-06-11 05:54:06', '2021-06-11 05:54:06', 'a:7:{s:8:\"location\";a:1:{i:0;a:1:{i:0;a:3:{s:5:\"param\";s:9:\"post_type\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:9:\"promotion\";}}}s:8:\"position\";s:6:\"normal\";s:5:\"style\";s:7:\"default\";s:15:\"label_placement\";s:3:\"top\";s:21:\"instruction_placement\";s:5:\"label\";s:14:\"hide_on_screen\";s:0:\"\";s:11:\"description\";s:0:\"\";}', 'Promotion', 'promotion', 'publish', 'closed', 'closed', '', 'group_60c2f9f0e8f36', '', '', '2021-06-11 05:54:06', '2021-06-11 05:54:06', '', 0, 'http://localhost/lava/?post_type=acf-field-group&#038;p=90', 0, 'acf-field-group', '', 0),
(91, 1, '2021-06-11 05:54:06', '2021-06-11 05:54:06', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'promotion icon', 'promotion_icon', 'publish', 'closed', 'closed', '', 'field_60c2fa723ed4a', '', '', '2021-06-11 05:54:06', '2021-06-11 05:54:06', '', 90, 'http://localhost/lava/?post_type=acf-field&p=91', 0, 'acf-field', '', 0),
(92, 1, '2021-06-11 05:56:43', '2021-06-11 05:56:43', 'You can download Lava Template from our website. Duis viverra, ipsum et scelerisque placerat, orci magna consequat ligula.', 'Sed blandit quam in velit', '', 'publish', 'open', 'closed', '', 'sed-blandit-quam-in-velit', '', '', '2021-06-11 05:56:43', '2021-06-11 05:56:43', '', 0, 'http://localhost/lava/?post_type=promotion&#038;p=92', 0, 'promotion', '', 0),
(93, 1, '2021-06-11 05:58:28', '2021-06-11 05:58:28', 'Phasellus in imperdiet felis, eget vestibulum nulla. Aliquam nec dui nec augue maximus porta. Curabitur tristique lacus.', 'Aenean faucibus venenatis', '', 'publish', 'open', 'closed', '', 'aenean-faucibus-venenatis', '', '', '2021-06-11 05:58:28', '2021-06-11 05:58:28', '', 0, 'http://localhost/lava/?post_type=promotion&#038;p=93', 0, 'promotion', '', 0),
(94, 1, '2021-06-11 06:39:13', '2021-06-11 06:39:13', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'testimonial main title emphasis', 'testimonial_main_title_emphasis', 'publish', 'closed', 'closed', '', 'field_60c304dba9987', '', '', '2021-06-11 06:39:13', '2021-06-11 06:39:13', '', 58, 'http://localhost/lava/?post_type=acf-field&p=94', 6, 'acf-field', '', 0);
INSERT INTO `wp_posts` (`ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(95, 1, '2021-06-11 06:39:13', '2021-06-11 06:39:13', 'a:10:{s:4:\"type\";s:8:\"textarea\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";s:4:\"rows\";s:0:\"\";s:9:\"new_lines\";s:0:\"\";}', 'testimonial short desc', 'testimonial_short_desc', 'publish', 'closed', 'closed', '', 'field_60c30374a9986', '', '', '2021-06-11 06:39:13', '2021-06-11 06:39:13', '', 58, 'http://localhost/lava/?post_type=acf-field&p=95', 7, 'acf-field', '', 0),
(96, 1, '2021-06-11 06:40:06', '2021-06-11 06:40:06', '', 'LandingPage', '', 'inherit', 'closed', 'closed', '', '63-revision-v1', '', '', '2021-06-11 06:40:06', '2021-06-11 06:40:06', '', 63, 'http://localhost/lava/?p=96', 0, 'revision', '', 0),
(97, 1, '2021-06-11 06:49:07', '2021-06-11 06:49:07', 'a:7:{s:4:\"type\";s:5:\"group\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:6:\"layout\";s:5:\"block\";s:10:\"sub_fields\";a:0:{}}', 'Section Title', 'section_title', 'publish', 'closed', 'closed', '', 'field_60c306aae457e', '', '', '2021-06-11 06:49:07', '2021-06-11 06:49:07', '', 58, 'http://localhost/lava/?post_type=acf-field&p=97', 8, 'acf-field', '', 0),
(98, 1, '2021-06-11 06:49:07', '2021-06-11 06:49:07', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Section Service', 'section_service', 'publish', 'closed', 'closed', '', 'field_60c306cee457f', '', '', '2021-06-11 06:49:07', '2021-06-11 06:49:07', '', 97, 'http://localhost/lava/?post_type=acf-field&p=98', 0, 'acf-field', '', 0),
(99, 1, '2021-06-11 06:49:07', '2021-06-11 06:49:07', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Section Promotion', 'section_promotion', 'publish', 'closed', 'closed', '', 'field_60c30717e4580', '', '', '2021-06-11 06:49:07', '2021-06-11 06:49:07', '', 97, 'http://localhost/lava/?post_type=acf-field&p=99', 1, 'acf-field', '', 0),
(100, 1, '2021-06-11 06:49:07', '2021-06-11 06:49:07', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Section Feedback', 'section_feedback', 'publish', 'closed', 'closed', '', 'field_60c30730e4581', '', '', '2021-06-11 06:49:07', '2021-06-11 06:49:07', '', 97, 'http://localhost/lava/?post_type=acf-field&p=100', 2, 'acf-field', '', 0),
(101, 1, '2021-06-11 06:49:07', '2021-06-11 06:49:07', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Section Contact', 'section_contact', 'publish', 'closed', 'closed', '', 'field_60c30752e4582', '', '', '2021-06-11 06:49:07', '2021-06-11 06:49:07', '', 97, 'http://localhost/lava/?post_type=acf-field&p=101', 3, 'acf-field', '', 0),
(102, 1, '2021-06-11 06:56:05', '2021-06-11 06:56:05', '', 'LandingPage', '', 'inherit', 'closed', 'closed', '', '63-revision-v1', '', '', '2021-06-11 06:56:05', '2021-06-11 06:56:05', '', 63, 'http://localhost/lava/?p=102', 0, 'revision', '', 0),
(103, 1, '2021-06-11 07:01:34', '2021-06-11 07:01:34', '', 'LandingPage', '', 'inherit', 'closed', 'closed', '', '63-revision-v1', '', '', '2021-06-11 07:01:34', '2021-06-11 07:01:34', '', 63, 'http://localhost/lava/?p=103', 0, 'revision', '', 0),
(104, 1, '2021-06-11 07:03:33', '2021-06-11 07:03:33', '', 'LandingPage', '', 'inherit', 'closed', 'closed', '', '63-revision-v1', '', '', '2021-06-11 07:03:33', '2021-06-11 07:03:33', '', 63, 'http://localhost/lava/?p=104', 0, 'revision', '', 0),
(105, 1, '2021-06-11 07:13:55', '2021-06-11 07:13:55', 'a:7:{s:8:\"location\";a:1:{i:0;a:1:{i:0;a:3:{s:5:\"param\";s:13:\"page_template\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:20:\"template.landing.php\";}}}s:8:\"position\";s:6:\"normal\";s:5:\"style\";s:7:\"default\";s:15:\"label_placement\";s:3:\"top\";s:21:\"instruction_placement\";s:5:\"label\";s:14:\"hide_on_screen\";s:0:\"\";s:11:\"description\";s:0:\"\";}', 'Landing Page Contact Us', 'landing-page-contact-us', 'publish', 'closed', 'closed', '', 'group_60c30c32b8d3a', '', '', '2021-06-11 07:45:22', '2021-06-11 07:45:22', '', 0, 'http://localhost/lava/?post_type=acf-field-group&#038;p=105', 0, 'acf-field-group', '', 0),
(106, 1, '2021-06-11 07:13:55', '2021-06-11 07:13:55', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'contact heading', 'contact_heading', 'publish', 'closed', 'closed', '', 'field_60c30c56d88ce', '', '', '2021-06-11 07:13:55', '2021-06-11 07:13:55', '', 105, 'http://localhost/lava/?post_type=acf-field&p=106', 0, 'acf-field', '', 0),
(107, 1, '2021-06-11 07:13:55', '2021-06-11 07:13:55', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'contact heading em', 'contact_heading_em', 'publish', 'closed', 'closed', '', 'field_60c30c5fd88cf', '', '', '2021-06-11 07:13:55', '2021-06-11 07:13:55', '', 105, 'http://localhost/lava/?post_type=acf-field&p=107', 1, 'acf-field', '', 0),
(108, 1, '2021-06-11 07:13:55', '2021-06-11 07:13:55', 'a:10:{s:4:\"type\";s:7:\"wysiwyg\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:4:\"tabs\";s:3:\"all\";s:7:\"toolbar\";s:4:\"full\";s:12:\"media_upload\";i:1;s:5:\"delay\";i:0;}', 'contact desc', 'contact_desc', 'publish', 'closed', 'closed', '', 'field_60c30c75d88d0', '', '', '2021-06-11 07:13:55', '2021-06-11 07:13:55', '', 105, 'http://localhost/lava/?post_type=acf-field&p=108', 2, 'acf-field', '', 0),
(109, 1, '2021-06-11 07:13:55', '2021-06-11 07:13:55', 'a:6:{s:4:\"type\";s:4:\"link\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"return_format\";s:5:\"array\";}', 'facebook link', 'facebook_link', 'publish', 'closed', 'closed', '', 'field_60c30c98d88d1', '', '', '2021-06-11 07:42:01', '2021-06-11 07:42:01', '', 105, 'http://localhost/lava/?post_type=acf-field&#038;p=109', 3, 'acf-field', '', 0),
(110, 1, '2021-06-11 07:13:55', '2021-06-11 07:13:55', 'a:6:{s:4:\"type\";s:4:\"link\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"return_format\";s:5:\"array\";}', 'twitter link', 'twitter_link', 'publish', 'closed', 'closed', '', 'field_60c30cded88d2', '', '', '2021-06-11 07:45:22', '2021-06-11 07:45:22', '', 105, 'http://localhost/lava/?post_type=acf-field&#038;p=110', 4, 'acf-field', '', 0),
(111, 1, '2021-06-11 07:13:55', '2021-06-11 07:13:55', 'a:6:{s:4:\"type\";s:4:\"link\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"return_format\";s:5:\"array\";}', 'LinkedIn link', 'linkedin_link', 'publish', 'closed', 'closed', '', 'field_60c30cf0d88d3', '', '', '2021-06-11 07:45:22', '2021-06-11 07:45:22', '', 105, 'http://localhost/lava/?post_type=acf-field&#038;p=111', 5, 'acf-field', '', 0),
(113, 1, '2021-06-11 07:16:44', '2021-06-11 07:16:44', '', 'LandingPage', '', 'inherit', 'closed', 'closed', '', '63-revision-v1', '', '', '2021-06-11 07:16:44', '2021-06-11 07:16:44', '', 63, 'http://localhost/lava/?p=113', 0, 'revision', '', 0),
(114, 1, '2021-06-11 07:19:13', '2021-06-11 07:19:13', '', 'LandingPage', '', 'inherit', 'closed', 'closed', '', '63-revision-v1', '', '', '2021-06-11 07:19:13', '2021-06-11 07:19:13', '', 63, 'http://localhost/lava/?p=114', 0, 'revision', '', 0),
(115, 1, '2021-06-11 07:20:49', '2021-06-11 07:20:49', '', 'LandingPage', '', 'inherit', 'closed', 'closed', '', '63-revision-v1', '', '', '2021-06-11 07:20:49', '2021-06-11 07:20:49', '', 63, 'http://localhost/lava/?p=115', 0, 'revision', '', 0),
(116, 1, '2021-06-11 07:21:19', '2021-06-11 07:21:19', '', 'LandingPage', '', 'inherit', 'closed', 'closed', '', '63-revision-v1', '', '', '2021-06-11 07:21:19', '2021-06-11 07:21:19', '', 63, 'http://localhost/lava/?p=116', 0, 'revision', '', 0),
(117, 1, '2021-06-11 07:23:54', '2021-06-11 07:23:54', '', 'LandingPage', '', 'inherit', 'closed', 'closed', '', '63-revision-v1', '', '', '2021-06-11 07:23:54', '2021-06-11 07:23:54', '', 63, 'http://localhost/lava/?p=117', 0, 'revision', '', 0),
(118, 1, '2021-06-11 07:24:31', '2021-06-11 07:24:31', '', 'LandingPage', '', 'inherit', 'closed', 'closed', '', '63-revision-v1', '', '', '2021-06-11 07:24:31', '2021-06-11 07:24:31', '', 63, 'http://localhost/lava/?p=118', 0, 'revision', '', 0),
(119, 1, '2021-06-11 07:38:18', '2021-06-11 07:38:18', '', 'LandingPage', '', 'inherit', 'closed', 'closed', '', '63-revision-v1', '', '', '2021-06-11 07:38:18', '2021-06-11 07:38:18', '', 63, 'http://localhost/lava/?p=119', 0, 'revision', '', 0),
(120, 1, '2021-06-11 08:23:19', '2021-06-11 08:23:19', '', 'LandingPage', '', 'inherit', 'closed', 'closed', '', '63-revision-v1', '', '', '2021-06-11 08:23:19', '2021-06-11 08:23:19', '', 63, 'http://localhost/lava/?p=120', 0, 'revision', '', 0),
(121, 1, '2021-06-11 08:34:00', '2021-06-11 08:34:00', '', 'LandingPage', '', 'inherit', 'closed', 'closed', '', '63-revision-v1', '', '', '2021-06-11 08:34:00', '2021-06-11 08:34:00', '', 63, 'http://localhost/lava/?p=121', 0, 'revision', '', 0),
(122, 1, '2021-06-11 08:42:44', '2021-06-11 08:42:44', 'a:15:{s:4:\"type\";s:5:\"image\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"return_format\";s:5:\"array\";s:12:\"preview_size\";s:4:\"full\";s:7:\"library\";s:3:\"all\";s:9:\"min_width\";s:0:\"\";s:10:\"min_height\";s:0:\"\";s:8:\"min_size\";s:0:\"\";s:9:\"max_width\";s:0:\"\";s:10:\"max_height\";s:0:\"\";s:8:\"max_size\";s:0:\"\";s:10:\"mime_types\";s:0:\"\";}', 'Promotion Image', 'promotion_image', 'publish', 'closed', 'closed', '', 'field_60c3218ff8c47', '', '', '2021-06-11 08:42:44', '2021-06-11 08:42:44', '', 58, 'http://localhost/lava/?post_type=acf-field&p=122', 9, 'acf-field', '', 0),
(123, 1, '2021-06-11 08:43:08', '2021-06-11 08:43:08', '', 'LandingPage', '', 'inherit', 'closed', 'closed', '', '63-revision-v1', '', '', '2021-06-11 08:43:08', '2021-06-11 08:43:08', '', 63, 'http://localhost/lava/?p=123', 0, 'revision', '', 0),
(124, 1, '2021-06-11 08:44:56', '2021-06-11 08:44:56', '', 'left image', '', 'inherit', 'open', 'closed', '', 'left-image', '', '', '2021-06-11 08:45:31', '2021-06-11 08:45:31', '', 63, 'http://localhost/lava/wp-content/uploads/2021/06/left-image.png', 0, 'attachment', 'image/png', 0),
(125, 1, '2021-06-11 08:45:40', '2021-06-11 08:45:40', '', 'LandingPage', '', 'inherit', 'closed', 'closed', '', '63-revision-v1', '', '', '2021-06-11 08:45:40', '2021-06-11 08:45:40', '', 63, 'http://localhost/lava/?p=125', 0, 'revision', '', 0),
(126, 1, '2021-06-12 03:40:44', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2021-06-12 03:40:44', '0000-00-00 00:00:00', '', 0, 'http://localhost/lava/?p=126', 0, 'post', '', 0),
(127, 1, '2021-06-12 03:41:00', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2021-06-12 03:41:00', '0000-00-00 00:00:00', '', 0, 'http://localhost/lava/?p=127', 0, 'post', '', 0),
(128, 1, '2021-06-12 03:42:39', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2021-06-12 03:42:39', '0000-00-00 00:00:00', '', 0, 'http://localhost/lava/?page_id=128', 0, 'page', '', 0),
(129, 1, '2021-06-12 03:46:17', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2021-06-12 03:46:17', '0000-00-00 00:00:00', '', 0, 'http://localhost/lava/?p=129', 0, 'post', '', 0),
(130, 1, '2021-06-12 03:46:40', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2021-06-12 03:46:40', '0000-00-00 00:00:00', '', 0, 'http://localhost/lava/?p=130', 0, 'post', '', 0),
(131, 1, '2021-06-12 03:47:06', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2021-06-12 03:47:06', '0000-00-00 00:00:00', '', 0, 'http://localhost/lava/?p=131', 0, 'post', '', 0),
(132, 1, '2021-06-12 03:48:40', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2021-06-12 03:48:40', '0000-00-00 00:00:00', '', 0, 'http://localhost/lava/?p=132', 0, 'post', '', 0),
(133, 1, '2021-06-12 03:50:58', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2021-06-12 03:50:58', '0000-00-00 00:00:00', '', 0, 'http://localhost/lava/?p=133', 0, 'post', '', 0),
(134, 1, '2021-06-12 05:31:13', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2021-06-12 05:31:13', '0000-00-00 00:00:00', '', 0, 'http://localhost/lava/?p=134', 0, 'post', '', 0),
(135, 1, '2021-06-12 05:35:27', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2021-06-12 05:35:27', '0000-00-00 00:00:00', '', 0, 'http://localhost/lava/?p=135', 0, 'post', '', 0),
(136, 1, '2021-06-12 06:02:08', '2021-06-12 06:02:08', 'Nullam hendrerit, elit a semper pharetra, ipsum nibh tristique tortor, in tempus urna elit in mauris.', 'Jonathan Smart', 'Besta CTO', 'publish', 'open', 'closed', '', 'jonathan-smart', '', '', '2021-06-12 07:02:42', '2021-06-12 07:02:42', '', 0, 'http://localhost/lava/?post_type=testimonial&#038;p=136', 0, 'testimonial', '', 0),
(137, 1, '2021-06-12 06:01:19', '2021-06-12 06:01:19', '', 'testimonial-author-1', '', 'inherit', 'open', 'closed', '', 'testimonial-author-1', '', '', '2021-06-12 06:36:28', '2021-06-12 06:36:28', '', 136, 'http://localhost/lava/wp-content/uploads/2021/06/testimonial-author-1.png', 0, 'attachment', 'image/png', 0),
(138, 1, '2021-06-12 06:11:47', '2021-06-12 06:11:47', '“Morbi non mi luctus felis molestie scelerisque. In ac libero viverra, placerat est interdum, rhoncus leo.”', 'Martino Tino', 'Web Analyst', 'publish', 'open', 'closed', '', 'martino-tino', '', '', '2021-06-12 07:10:38', '2021-06-12 07:10:38', '', 0, 'http://localhost/lava/?post_type=testimonial&#038;p=138', 0, 'testimonial', '', 0),
(140, 1, '2021-06-12 06:20:17', '2021-06-12 06:20:17', '', 'jawad-pic-croped', '', 'inherit', 'open', 'closed', '', 'jawad-pic-croped', '', '', '2021-06-12 06:20:25', '2021-06-12 06:20:25', '', 138, 'http://localhost/lava/wp-content/uploads/2021/06/jawad-pic-croped.jpg', 0, 'attachment', 'image/jpeg', 0),
(141, 1, '2021-06-12 06:37:20', '2021-06-12 06:37:20', '“Morbi non mi luctus felis molestie scelerisque. In ac libero viverra, placerat est interdum, rhoncus leo.”', 'George Tasa', 'System Admin', 'publish', 'open', 'closed', '', 'george-tasa', '', '', '2021-06-12 07:10:55', '2021-06-12 07:10:55', '', 0, 'http://localhost/lava/?post_type=testimonial&#038;p=141', 0, 'testimonial', '', 0),
(142, 1, '2021-06-12 06:38:31', '2021-06-12 06:38:31', '“Morbi non mi luctus felis molestie scelerisque. In ac libero viverra, placerat est interdum, rhoncus leo.”', 'Sir James', 'New Villager', 'publish', 'open', 'closed', '', 'sir-james', '', '', '2021-06-12 07:11:12', '2021-06-12 07:11:12', '', 0, 'http://localhost/lava/?post_type=testimonial&#038;p=142', 0, 'testimonial', '', 0),
(143, 1, '2021-06-12 06:54:00', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2021-06-12 06:54:00', '0000-00-00 00:00:00', '', 0, 'http://localhost/lava/?p=143', 0, 'post', '', 0),
(144, 1, '2021-06-12 06:58:46', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2021-06-12 06:58:46', '0000-00-00 00:00:00', '', 0, 'http://localhost/lava/?p=144', 0, 'post', '', 0),
(145, 1, '2021-06-12 06:59:13', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2021-06-12 06:59:13', '0000-00-00 00:00:00', '', 0, 'http://localhost/lava/?p=145', 0, 'post', '', 0),
(146, 1, '2021-06-12 06:59:24', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2021-06-12 06:59:24', '0000-00-00 00:00:00', '', 0, 'http://localhost/lava/?page_id=146', 0, 'page', '', 0),
(147, 1, '2021-06-12 06:59:30', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'closed', '', '', '', '', '2021-06-12 06:59:30', '0000-00-00 00:00:00', '', 0, 'http://localhost/lava/?post_type=testimonial&p=147', 0, 'testimonial', '', 0),
(148, 1, '2021-06-12 07:01:56', '2021-06-12 07:01:56', 'a:7:{s:8:\"location\";a:1:{i:0;a:1:{i:0;a:3:{s:5:\"param\";s:9:\"post_type\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:11:\"testimonial\";}}}s:8:\"position\";s:6:\"normal\";s:5:\"style\";s:7:\"default\";s:15:\"label_placement\";s:3:\"top\";s:21:\"instruction_placement\";s:5:\"label\";s:14:\"hide_on_screen\";s:0:\"\";s:11:\"description\";s:0:\"\";}', 'Testimonial', 'testimonial', 'publish', 'closed', 'closed', '', 'group_60c45bae2d319', '', '', '2021-06-12 07:09:02', '2021-06-12 07:09:02', '', 0, 'http://localhost/lava/?post_type=acf-field-group&#038;p=148', 0, 'acf-field-group', '', 0),
(149, 1, '2021-06-12 07:01:56', '2021-06-12 07:01:56', 'a:9:{s:4:\"type\";s:17:\"star_rating_field\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:9:\"max_stars\";i:5;s:11:\"return_type\";i:2;s:10:\"allow_half\";i:0;s:5:\"theme\";s:7:\"default\";}', 'Star Rating', 'star_rating', 'publish', 'closed', 'closed', '', 'field_60c45bb82cdba', '', '', '2021-06-12 07:09:02', '2021-06-12 07:09:02', '', 148, 'http://localhost/lava/?post_type=acf-field&#038;p=149', 0, 'acf-field', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `wp_ratings`
--

CREATE TABLE `wp_ratings` (
  `rating_id` int(11) NOT NULL,
  `rating_postid` int(11) NOT NULL,
  `rating_posttitle` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `rating_rating` int(2) NOT NULL,
  `rating_timestamp` varchar(15) COLLATE utf8mb4_unicode_ci NOT NULL,
  `rating_ip` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `rating_host` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `rating_username` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `rating_userid` int(10) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_termmeta`
--

CREATE TABLE `wp_termmeta` (
  `meta_id` bigint(20) UNSIGNED NOT NULL,
  `term_id` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_terms`
--

CREATE TABLE `wp_terms` (
  `term_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_terms`
--

INSERT INTO `wp_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES
(1, 'Uncategorized', 'uncategorized', 0),
(2, 'header menu', 'header-menu', 0);

-- --------------------------------------------------------

--
-- Table structure for table `wp_term_relationships`
--

CREATE TABLE `wp_term_relationships` (
  `object_id` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `term_taxonomy_id` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `term_order` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_term_relationships`
--

INSERT INTO `wp_term_relationships` (`object_id`, `term_taxonomy_id`, `term_order`) VALUES
(1, 1, 0),
(12, 2, 0),
(13, 2, 0),
(14, 2, 0),
(15, 2, 0),
(16, 2, 0),
(17, 2, 0),
(18, 2, 0),
(23, 2, 0),
(70, 2, 0);

-- --------------------------------------------------------

--
-- Table structure for table `wp_term_taxonomy`
--

CREATE TABLE `wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) UNSIGNED NOT NULL,
  `term_id` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `count` bigint(20) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_term_taxonomy`
--

INSERT INTO `wp_term_taxonomy` (`term_taxonomy_id`, `term_id`, `taxonomy`, `description`, `parent`, `count`) VALUES
(1, 1, 'category', '', 0, 1),
(2, 2, 'nav_menu', '', 0, 9);

-- --------------------------------------------------------

--
-- Table structure for table `wp_usermeta`
--

CREATE TABLE `wp_usermeta` (
  `umeta_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_usermeta`
--

INSERT INTO `wp_usermeta` (`umeta_id`, `user_id`, `meta_key`, `meta_value`) VALUES
(1, 1, 'nickname', 'admin'),
(2, 1, 'first_name', ''),
(3, 1, 'last_name', ''),
(4, 1, 'description', ''),
(5, 1, 'rich_editing', 'true'),
(6, 1, 'syntax_highlighting', 'true'),
(7, 1, 'comment_shortcuts', 'false'),
(8, 1, 'admin_color', 'fresh'),
(9, 1, 'use_ssl', '0'),
(10, 1, 'show_admin_bar_front', 'true'),
(11, 1, 'locale', ''),
(12, 1, 'wp_capabilities', 'a:1:{s:13:\"administrator\";b:1;}'),
(13, 1, 'wp_user_level', '10'),
(14, 1, 'dismissed_wp_pointers', ''),
(15, 1, 'show_welcome_panel', '0'),
(16, 1, 'session_tokens', 'a:3:{s:64:\"e85d4143943f7b2aec8c606020a64d1bd9a07abfa40b8aed3cdccaf5c3842fa3\";a:4:{s:10:\"expiration\";i:1624257838;s:2:\"ip\";s:3:\"::1\";s:2:\"ua\";s:114:\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.77 Safari/537.36\";s:5:\"login\";i:1623048238;}s:64:\"4ec15637b807f6f395d43b5e5875c108b555bc39c85efb11127e030accb4ccd9\";a:4:{s:10:\"expiration\";i:1623556921;s:2:\"ip\";s:3:\"::1\";s:2:\"ua\";s:114:\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.77 Safari/537.36\";s:5:\"login\";i:1623384121;}s:64:\"bf43833547bb1ebc8997d90e46f3637890097fd61c82cc4c49fc4dd5b3c120e2\";a:4:{s:10:\"expiration\";i:1623576052;s:2:\"ip\";s:3:\"::1\";s:2:\"ua\";s:114:\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.77 Safari/537.36\";s:5:\"login\";i:1623403252;}}'),
(17, 1, 'wp_dashboard_quick_press_last_post_id', '4'),
(18, 1, 'managenav-menuscolumnshidden', 'a:4:{i:0;s:11:\"link-target\";i:1;s:15:\"title-attribute\";i:2;s:3:\"xfn\";i:3;s:11:\"description\";}'),
(19, 1, 'metaboxhidden_nav-menus', 'a:1:{i:0;s:12:\"add-post_tag\";}'),
(20, 1, 'closedpostboxes_dashboard', 'a:5:{i:0;s:21:\"dashboard_site_health\";i:1;s:19:\"dashboard_right_now\";i:2;s:18:\"dashboard_activity\";i:3;s:21:\"dashboard_quick_press\";i:4;s:17:\"dashboard_primary\";}'),
(21, 1, 'metaboxhidden_dashboard', 'a:0:{}'),
(22, 1, 'nav_menu_recently_edited', '2'),
(23, 1, 'wp_user-settings', 'libraryContent=browse&editor=html'),
(24, 1, 'wp_user-settings-time', '1623478007'),
(25, 1, 'closedpostboxes_service', 'a:0:{}'),
(26, 1, 'metaboxhidden_service', 'a:2:{i:0;s:16:\"commentstatusdiv\";i:1;s:7:\"slugdiv\";}'),
(27, 1, 'closedpostboxes_page', 'a:1:{i:0;s:23:\"acf-group_60c30c32b8d3a\";}'),
(28, 1, 'metaboxhidden_page', 'a:5:{i:0;s:12:\"revisionsdiv\";i:1;s:16:\"commentstatusdiv\";i:2;s:11:\"commentsdiv\";i:3;s:7:\"slugdiv\";i:4;s:9:\"authordiv\";}'),
(29, 1, 'meta-box-order_page', 'a:4:{s:15:\"acf_after_title\";s:0:\"\";s:4:\"side\";s:36:\"submitdiv,pageparentdiv,postimagediv\";s:6:\"normal\";s:83:\"acf-group_60c0579231568,revisionsdiv,commentstatusdiv,commentsdiv,slugdiv,authordiv\";s:8:\"advanced\";s:23:\"acf-group_60c30c32b8d3a\";}'),
(30, 1, 'screen_layout_page', '2'),
(31, 1, 'closedpostboxes_post', 'a:0:{}'),
(32, 1, 'metaboxhidden_post', 'a:4:{i:0;s:13:\"trackbacksdiv\";i:1;s:16:\"commentstatusdiv\";i:2;s:7:\"slugdiv\";i:3;s:9:\"authordiv\";}'),
(33, 1, 'closedpostboxes_testimonial', 'a:0:{}'),
(34, 1, 'metaboxhidden_testimonial', 'a:2:{i:0;s:16:\"commentstatusdiv\";i:1;s:7:\"slugdiv\";}');

-- --------------------------------------------------------

--
-- Table structure for table `wp_users`
--

CREATE TABLE `wp_users` (
  `ID` bigint(20) UNSIGNED NOT NULL,
  `user_login` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT 0,
  `display_name` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_users`
--

INSERT INTO `wp_users` (`ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`) VALUES
(1, 'admin', '$P$B4tb1ZeWEGcejAVnWlkiwBDdFZb1Yy0', 'admin', 'bilal.asghar.chuadhary@gmail.com', 'http://localhost/lava', '2021-06-05 16:18:30', '', 0, 'admin');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `wp_commentmeta`
--
ALTER TABLE `wp_commentmeta`
  ADD PRIMARY KEY (`meta_id`),
  ADD KEY `comment_id` (`comment_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Indexes for table `wp_comments`
--
ALTER TABLE `wp_comments`
  ADD PRIMARY KEY (`comment_ID`),
  ADD KEY `comment_post_ID` (`comment_post_ID`),
  ADD KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  ADD KEY `comment_date_gmt` (`comment_date_gmt`),
  ADD KEY `comment_parent` (`comment_parent`),
  ADD KEY `comment_author_email` (`comment_author_email`(10));

--
-- Indexes for table `wp_links`
--
ALTER TABLE `wp_links`
  ADD PRIMARY KEY (`link_id`),
  ADD KEY `link_visible` (`link_visible`);

--
-- Indexes for table `wp_options`
--
ALTER TABLE `wp_options`
  ADD PRIMARY KEY (`option_id`),
  ADD UNIQUE KEY `option_name` (`option_name`),
  ADD KEY `autoload` (`autoload`);

--
-- Indexes for table `wp_postmeta`
--
ALTER TABLE `wp_postmeta`
  ADD PRIMARY KEY (`meta_id`),
  ADD KEY `post_id` (`post_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Indexes for table `wp_posts`
--
ALTER TABLE `wp_posts`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `post_name` (`post_name`(191)),
  ADD KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  ADD KEY `post_parent` (`post_parent`),
  ADD KEY `post_author` (`post_author`);

--
-- Indexes for table `wp_ratings`
--
ALTER TABLE `wp_ratings`
  ADD PRIMARY KEY (`rating_id`),
  ADD KEY `rating_userid` (`rating_userid`),
  ADD KEY `rating_postid_ip` (`rating_postid`,`rating_ip`);

--
-- Indexes for table `wp_termmeta`
--
ALTER TABLE `wp_termmeta`
  ADD PRIMARY KEY (`meta_id`),
  ADD KEY `term_id` (`term_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Indexes for table `wp_terms`
--
ALTER TABLE `wp_terms`
  ADD PRIMARY KEY (`term_id`),
  ADD KEY `slug` (`slug`(191)),
  ADD KEY `name` (`name`(191));

--
-- Indexes for table `wp_term_relationships`
--
ALTER TABLE `wp_term_relationships`
  ADD PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  ADD KEY `term_taxonomy_id` (`term_taxonomy_id`);

--
-- Indexes for table `wp_term_taxonomy`
--
ALTER TABLE `wp_term_taxonomy`
  ADD PRIMARY KEY (`term_taxonomy_id`),
  ADD UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  ADD KEY `taxonomy` (`taxonomy`);

--
-- Indexes for table `wp_usermeta`
--
ALTER TABLE `wp_usermeta`
  ADD PRIMARY KEY (`umeta_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Indexes for table `wp_users`
--
ALTER TABLE `wp_users`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `user_login_key` (`user_login`),
  ADD KEY `user_nicename` (`user_nicename`),
  ADD KEY `user_email` (`user_email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `wp_commentmeta`
--
ALTER TABLE `wp_commentmeta`
  MODIFY `meta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_comments`
--
ALTER TABLE `wp_comments`
  MODIFY `comment_ID` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `wp_links`
--
ALTER TABLE `wp_links`
  MODIFY `link_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_options`
--
ALTER TABLE `wp_options`
  MODIFY `option_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=439;

--
-- AUTO_INCREMENT for table `wp_postmeta`
--
ALTER TABLE `wp_postmeta`
  MODIFY `meta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1021;

--
-- AUTO_INCREMENT for table `wp_posts`
--
ALTER TABLE `wp_posts`
  MODIFY `ID` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=150;

--
-- AUTO_INCREMENT for table `wp_ratings`
--
ALTER TABLE `wp_ratings`
  MODIFY `rating_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_termmeta`
--
ALTER TABLE `wp_termmeta`
  MODIFY `meta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_terms`
--
ALTER TABLE `wp_terms`
  MODIFY `term_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `wp_term_taxonomy`
--
ALTER TABLE `wp_term_taxonomy`
  MODIFY `term_taxonomy_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `wp_usermeta`
--
ALTER TABLE `wp_usermeta`
  MODIFY `umeta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;

--
-- AUTO_INCREMENT for table `wp_users`
--
ALTER TABLE `wp_users`
  MODIFY `ID` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
