<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'lava' );

/** MySQL database username */
define( 'DB_USER', 'root' );

/** MySQL database password */
define( 'DB_PASSWORD', '' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         '#+_@|_,?d{c^TB^p3hYu*twA6yw ~utGi,4I]5p-[-M^{tL6N<UYX:M}; Kj5[^k');
define('SECURE_AUTH_KEY',  's++,R5+G_++0R+3O3kL?FY%Y$%AA?`Qf0Rs!S},o{Y~-!+)}y)tvN`pvFVn Uu(M');
define('LOGGED_IN_KEY',    'FcRXWV@3tY5/eaJ-]ykG}-+0`b^e&^X/)`,k>zNZ!D`>viMwPYg<@`&EF+95-pM)');
define('NONCE_KEY',        'h,r)#j$7lmE<]bfJpT3`wL^+7c{ mHGH+Q+1KCp%zWHumY #>0b 9e >6Wj#!Xgn');
define('AUTH_SALT',        'Y1`<T+-p6}K)C_f>*4$)S8O+B7wQG%|$Q*+CFAaqNH`j{G*{< R!:1u?a7&A-0.f');
define('SECURE_AUTH_SALT', '4$OOV.dF+{qnwt+q]2B}{j+2HMYK(+AWQAX2b9|W-caD,rMZ.M5wFkt_-u+&v,sV');
define('LOGGED_IN_SALT',   '#^#h]jYVx&ms]o?<#K$@nps=U4oy/) s-+Y&vBrpah|1.~ey.P@5cN<H!SMd;N$W');
define('NONCE_SALT',       'k&k)`L7e-nT[Rt<XV.]``+&N.H|[i(ohOS._d<baI-`,UP&*mXJYtv|-kl-0il:{');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', true );

define( 'WPCF7_VALIDATE_CONFIGURATION', true );

// define( 'SMTP_HOST', 'mail.truishop.com' );
// define( 'SMTP_AUTH', true );
// define( 'SMTP_PORT', '465' );
// define( 'SMTP_USERNAME', 'bilal@truishop.com' );
// define( 'SMTP_PASSWORD', 'gUBFYRbU^jFl' );
// define( 'SMTP_FROM',     'bilal@truishop.com' );



/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
